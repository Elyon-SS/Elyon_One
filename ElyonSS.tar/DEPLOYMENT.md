# Deployment Guide - Elyon Smart Solutions

This guide covers deployment across all major hosting providers.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Variables](#environment-variables)
3. [Vercel Deployment](#vercel-deployment)
4. [Netlify Deployment](#netlify-deployment)
5. [Docker Deployment](#docker-deployment)
6. [AWS Deployment](#aws-deployment)
7. [Google Cloud Deployment](#google-cloud-deployment)
8. [DigitalOcean Deployment](#digitalocean-deployment)
9. [Self-Hosted / VPS Deployment](#self-hosted--vps-deployment)
10. [Database Configuration](#database-configuration)
11. [Post-Deployment Checklist](#post-deployment-checklist)

---

## Prerequisites

Before deploying, ensure you have:

- Node.js 18.17+ installed
- A PostgreSQL database (recommended for production) or SQLite
- Domain name (optional but recommended)
- SSL certificate (handled automatically by most providers)

---

## Environment Variables

Copy `.env.example` to `.env.production` and configure:

```bash
cp .env.example .env.production
```

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Database connection string | `postgresql://user:pass@host:5432/db` |
| `NEXTAUTH_SECRET` | Secret for authentication | Generate with `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Your domain URL | `https://elyon.one` |

### Optional Variables

| Variable | Description |
|----------|-------------|
| `NEXT_PUBLIC_GA_ID` | Google Analytics ID |
| `SMTP_HOST` | Email SMTP server |
| `SMTP_USER` | SMTP username |
| `SMTP_PASS` | SMTP password |

---

## Vercel Deployment

### Option 1: Via Vercel Dashboard (Recommended)

1. Go to [vercel.com](https://vercel.com)
2. Click "Add New" → "Project"
3. Import your GitHub/GitLab repository
4. Configure project:
   - **Framework Preset**: Next.js (auto-detected)
   - **Root Directory**: `./`
   - **Build Command**: `npm run build`
   - **Output Directory**: `.next`
5. Add environment variables
6. Click "Deploy"

### Option 2: Via CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy to production
npm run vercel:deploy

# Or preview deployment
npm run vercel:preview
```

### Vercel-Specific Features

- Automatic SSL/HTTPS
- Edge Functions
- Image Optimization
- Analytics & Speed Insights
- Preview deployments for pull requests

---

## Netlify Deployment

### Option 1: Via Netlify Dashboard

1. Go to [netlify.com](https://netlify.com)
2. Click "Add new site" → "Import an existing project"
3. Connect your Git provider
4. Configure:
   - **Build Command**: `npm run build`
   - **Publish Directory**: `.next`
5. Add environment variables
6. Click "Deploy site"

### Option 2: Via CLI

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Login
netlify login

# Deploy to production
npm run netlify:deploy

# Or preview deployment
npm run netlify:preview
```

### Netlify-Specific Features

- Automatic form handling
- Edge Functions
- Split testing
- Analytics

---

## Docker Deployment

### Build and Run Locally

```bash
# Build the image
docker build -t elyon-smart-solutions .

# Run the container
docker run -p 3000:3000 \
  -e DATABASE_URL="your-database-url" \
  -e NEXTAUTH_SECRET="your-secret" \
  elyon-smart-solutions
```

### Using Docker Compose

```bash
# Start all services (app + PostgreSQL)
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Deploy to Container Services

Works with:
- AWS ECS/Fargate
- Google Cloud Run
- Azure Container Instances
- DigitalOcean App Platform
- Railway
- Render

---

## AWS Deployment

### Option 1: AWS Amplify

1. Go to AWS Amplify Console
2. Click "New app" → "Host web app"
3. Connect your repository
4. Configure build settings (auto-detected for Next.js)
5. Add environment variables
6. Deploy

### Option 2: AWS Elastic Beanstalk

```bash
# Install EB CLI
pip install awsebcli

# Initialize
eb init

# Create environment
eb create production

# Deploy
eb deploy
```

### Option 3: AWS ECS with Fargate

```bash
# Build and push to ECR
docker build -t elyon-smart-solutions .
docker tag elyon-smart-solutions:latest <account>.dkr.ecr.<region>.amazonaws.com/elyon
docker push <account>.dkr.ecr.<region>.amazonaws.com/elyon

# Deploy to ECS
# (Configure task definitions and services via AWS Console or CLI)
```

---

## Google Cloud Deployment

### Option 1: Google Cloud Run

```bash
# Build and deploy in one command
gcloud run deploy elyon-smart-solutions \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

### Option 2: Google App Engine

1. Create `app.yaml`:

```yaml
runtime: nodejs20
env: standard
instance_class: F2

env_variables:
  DATABASE_URL: "your-database-url"
  NEXTAUTH_SECRET: "your-secret"

automatic_scaling:
  min_idle_instances: 1
  max_instances: 10
```

2. Deploy:

```bash
gcloud app deploy
```

---

## DigitalOcean Deployment

### Option 1: App Platform

1. Go to DigitalOcean App Platform
2. Click "Create App"
3. Connect your repository
4. Configure:
   - **Type**: Web Service
   - **Build Command**: `npm run build`
   - **Run Command**: `npm run start`
5. Add environment variables
6. Deploy

### Option 2: Droplet (VPS)

```bash
# SSH into your droplet
ssh root@your-droplet-ip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone repository
git clone https://github.com/your-repo/elyon-smart-solutions.git
cd elyon-smart-solutions

# Install dependencies
npm ci

# Build
npm run build

# Start with PM2
npm i -g pm2
pm2 start npm --name "elyon" -- start
pm2 save
pm2 startup
```

---

## Self-Hosted / VPS Deployment

### Using PM2

```bash
# Install PM2
npm i -g pm2

# Build the application
npm ci
npm run build

# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save
pm2 startup
```

### Create `ecosystem.config.js`:

```javascript
module.exports = {
  apps: [{
    name: 'elyon-smart-solutions',
    script: 'node_modules/next/dist/bin/next',
    args: 'start',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      DATABASE_URL: process.env.DATABASE_URL,
      NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,
    }
  }]
}
```

### Using Nginx Reverse Proxy

```nginx
server {
    listen 80;
    server_name elyon.one www.elyon.one;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## Database Configuration

### SQLite (Development)

```env
DATABASE_URL="file:./dev.db"
```

### PostgreSQL (Recommended for Production)

```env
DATABASE_URL="postgresql://username:password@host:5432/database?schema=public"
```

Popular PostgreSQL providers:
- [Supabase](https://supabase.com) - Free tier available
- [Neon](https://neon.tech) - Serverless PostgreSQL
- [Railway](https://railway.app) - Free tier available
- [PlanetScale](https://planetscale.com) - Serverless
- [AWS RDS](https://aws.amazon.com/rds/)
- [Google Cloud SQL](https://cloud.google.com/sql)

### Run Migrations

```bash
# Generate Prisma client
npm run db:generate

# Push schema to database
npm run db:push

# Or run migrations (production)
npm run db:migrate:deploy
```

---

## Post-Deployment Checklist

- [ ] Verify all environment variables are set
- [ ] Run database migrations
- [ ] Test all pages and functionality
- [ ] Verify SSL/HTTPS is working
- [ ] Check image optimization
- [ ] Test contact form submissions
- [ ] Set up error monitoring (Sentry, etc.)
- [ ] Configure analytics (Google Analytics, etc.)
- [ ] Set up uptime monitoring (UptimeRobot, etc.)
- [ ] Configure CDN if needed
- [ ] Review security headers
- [ ] Set up backup for database
- [ ] Configure custom domain

---

## Troubleshooting

### Build Errors

```bash
# Clear Next.js cache
rm -rf .next

# Clear node_modules
rm -rf node_modules
npm ci

# Rebuild
npm run build
```

### Database Connection Issues

```bash
# Test connection
npx prisma db pull

# Check database URL format
echo $DATABASE_URL
```

### Memory Issues

Increase Node.js memory:
```bash
NODE_OPTIONS="--max-old-space-size=4096" npm run build
```

---

## Support

For deployment issues, check:
1. Build logs for errors
2. Environment variables are correctly set
3. Database connectivity
4. Network/firewall settings

---

**Happy Deploying! 🚀**
