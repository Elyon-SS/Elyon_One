**PRD: Elyon Smart Solutions Website (Multi-page, SEO-first, no
database)**

**1) Goal & positioning**

**Goal:** Build a fast, multi-page, SEO-friendly marketing website for
**Elyon Smart Solutions** that clearly explains offerings, proves
credibility (case studies/testimonials), captures leads, and ranks for
"smart solutions" + industry keywords.

**Inspiration reference:** WeThinkApp-style structure (hero + proof
metrics + services cards + industries + use cases + tech stack +
insights + FAQ + strong CTA).

**Non-goals**

-   No user accounts, dashboards, portals, or data-heavy features.

-   No database (no PostgreSQL/MySQL/Firebase, etc.).

-   No complex backend beyond a simple contact form handler.

**2) Target users**

1.  **Enterprise / Government decision makers** (need trust, compliance
    comfort, clear outcomes)

2.  **Operations / IT leaders** (need "what exactly will you deliver" +
    integration reality)

3.  **SME owners** (need simple packages and quick start)

4.  **Partners** (system integrators, contractors)

**3) Success metrics**

-   Conversion: contact submissions, "book a call" clicks, WhatsApp
    clicks

-   SEO: indexed pages, organic traffic to solution/industry landing
    pages, ranking improvements

-   Performance: Core Web Vitals passing (LCP/CLS/INP), \<2s LCP on
    typical mobile

-   Content velocity: new insight posts/case studies added without
    developer work (markdown)

**4) Recommended minimal tech stack (no database)**

**Option A (recommended):**

-   **Next.js** (App Router) + **Static Site Generation** (SSG) / ISR
    where needed

-   **Tailwind CSS**

-   Content stored as **MDX/Markdown** in the repo (Insights + Case
    Studies)

-   Deployment: **Vercel** or **Cloudflare Pages**

-   Contact form: serverless endpoint (Next route handler) that emails
    via **Resend** / SendGrid

**Option B (even simpler):**

-   Astro + Tailwind + Markdown + Netlify/Cloudflare Pages

-   Contact form via Netlify Forms or serverless function

**Notes on "non database driven":**

-   Content lives in Git (MDX). No CMS required. If later needed, a
    headless CMS can be added, but PRD assumes **no DB**.

**5) Information architecture (Sitemap tree)**

Below is the **sitemap tree structure**. "Page" = route. Under each
page, sections are listed as **S#**.

**5.1 Global (all pages)**

-   **Header / Navbar**

    -   Logo

    -   Solutions (dropdown)

    -   Industries (dropdown)

    -   Case Studies

    -   Insights

    -   About

    -   Contact / Book Call (primary CTA)

-   **Footer**

    -   Quick links

    -   Solutions

    -   Industries

    -   Legal (Privacy, Terms)

    -   Contact info + social

    -   Newsletter (optional)

**5.2 Pages**

1.  **/** (Home)

2.  **/solutions** (Solutions overview)

3.  **/solutions/\[solution\]** (Solution detail template; multiple
    pages)

4.  **/industries** (Industries overview)

5.  **/industries/\[industry\]** (Industry detail template; multiple
    pages)

6.  **/use-cases** (Use cases overview)

7.  **/use-cases/\[usecase\]** (Use case detail template; multiple
    pages)

8.  **/case-studies** (Listing)

9.  **/case-studies/\[slug\]** (Case study detail; MDX)

10. **/insights** (Blog listing)

11. **/insights/\[slug\]** (Blog post; MDX)

12. **/about** (Company)

13. **/contact** (Lead capture)

14. **/privacy**

15. **/terms**

16. **/thank-you** (post-form submission)

**6) Page-by-page PRD (sections, content, SEO requirements)**

**Page 1: Home (/)**

**Purpose:** Fast understanding + credibility + clear paths to
Solutions/Industries + lead capture.

**S1 Hero**

-   Headline: "Smart Solutions that reduce cost, improve visibility, and
    automate operations"

-   Subtext: 1--2 lines clarifying what Elyon does

-   CTAs: "Book a call" + "Explore solutions"

-   Trust indicators: review count / client logos / partner badges (if
    available)

**S2 Proof / Metrics strip**

-   3--5 metrics (projects delivered, response time, % efficiency gains,
    etc.)

-   Must be factual (no invented numbers)

**S3 Core solutions (cards)**

-   4--6 solution cards with:

    -   1-liner value

    -   3 bullet outcomes

    -   Link to /solutions/\[solution\]

**S4 Industry entry points**

-   6--10 industries grid linking to /industries/\[industry\]

**S5 "Use cases in action"**

-   Short list of use cases (like "Agent management", "Dashboards",
    "Process automation" style) with links to /use-cases/\[usecase\]

**S6 How Elyon works**

-   4 steps: Discover → Design → Deliver → Support

-   Clear deliverables per step

**S7 Featured case studies**

-   3 cards: challenge, approach, measurable result

**S8 FAQ**

-   6--10 FAQs (schema-enabled)

**S9 Final CTA**

-   Strong CTA block (book call, WhatsApp, email)

**SEO**

-   Title: "Elyon Smart Solutions \| Smart Automation, IoT, AI & Systems
    Integration"

-   Meta description 150--160 chars

-   Organization schema + FAQ schema

-   Internal links to top solutions/industries

**Page 2: Solutions Overview (/solutions)**

**Purpose:** Search landing page for "smart solutions" + navigation hub.

**S1 Hero**

-   "Solutions" headline + 1-liner

**S2 Filters (client-side only)**

-   Filter by outcome: automation / monitoring / analytics / security /
    energy

-   Filter by industry

**S3 Solutions grid**

-   Each card: problem → outcome → link

**S4 Comparison / "When to choose what"**

-   Simple matrix (no heavy graphics needed)

**S5 CTA**

**SEO**

-   Target keywords: "smart solutions company", "smart automation
    services", "IoT solutions provider" (adapt to your market)

-   Add breadcrumbs schema

**Page Template 3: Solution Detail (/solutions/\[solution\])**

Create 6--10 solution pages. Example slugs:

-   /solutions/smart-automation

-   /solutions/iot-monitoring

-   /solutions/ai-ops-dashboards

-   /solutions/energy-optimization

-   /solutions/security-surveillance-integration

-   /solutions/smart-building-management

**S1 Hero**

-   Solution name + "who it's for" + primary outcomes

-   CTA: Book call

**S2 The problem**

-   3--5 pain points (specific, operational)

**S3 What Elyon delivers**

-   Bulleted deliverables (hardware + software + integration + training)

**S4 How it works**

-   Architecture diagram (static SVG/PNG)

-   "Inputs → Processing → Outputs"

**S5 Key features**

-   6--10 features, written for SEO and clarity

**S6 Integrations**

-   List supported tools/protocols (e.g., MQTT, Modbus, REST, ONVIF)
    where applicable

-   Keep honest: "Supported upon assessment" if needed

**S7 Security & reliability**

-   Data handling, access control, uptime approach

**S8 Outcomes / ROI examples**

-   "Typical results" with ranges only if real

-   Otherwise qualitative + explain measurement approach

**S9 Relevant case studies**

-   1--3 links

**S10 FAQ**

-   Solution-specific FAQs

**SEO**

-   Unique title/description per solution

-   FAQ schema

-   Internal links to related use cases + industries

**Page 4: Industries Overview (/industries)**

**Purpose:** SEO hub for "smart solutions for X industry".

**S1 Hero**\
**S2 Industry tiles**

-   Each tile includes "Top 3 outcomes" and links to detail pages\
    **S3 CTA**

**Page Template 5: Industry Detail (/industries/\[industry\])**

Create 6--12 industry pages. Example:

-   /industries/real-estate-facilities

-   /industries/retail

-   /industries/logistics-warehousing

-   /industries/healthcare

-   /industries/manufacturing

-   /industries/hospitality

**S1 Hero**

-   "Smart solutions for {Industry}"

-   3 main outcomes + CTA

**S2 Common challenges in this industry**\
**S3 Recommended solutions**

-   Cards linking to solution pages

**S4 Typical deployments**

-   2--4 scenarios (e.g., "multi-site monitoring", "energy cost
    control")

**S5 Compliance / standards (only if applicable)**

-   If unsure, keep generic and non-legal

**S6 Case studies**\
**S7 FAQ**\
**SEO**

-   Industry keyword focus + internal linking

**Page 6: Use Cases Overview (/use-cases)**

**Purpose:** Mid-funnel SEO and navigation.

**S1 Hero**\
**S2 Use case list**

-   Each with "trigger → workflow → outcome"\
    **S3 CTA**

**Page Template 7: Use Case Detail (/use-cases/\[usecase\])**

**S1 Hero**\
**S2 Workflow**

-   Step-by-step (works great for SEO)\
    **S3 Data/Inputs needed**\
    **S4 Outputs**\
    **S5 Recommended solutions**\
    **S6 FAQ**\
    **SEO**

-   Long-tail keywords ("automated incident reporting", "predictive
    maintenance monitoring", etc.)

**Page 8: Case Studies Listing (/case-studies)**

**S1 Hero**\
**S2 Filters**

-   Industry / solution / outcome\
    **S3 Cards**

-   Each shows: problem, approach, result\
    **S4 CTA**

**SEO**

-   Indexable listing with proper pagination

**Page 9: Case Study Detail (/case-studies/\[slug\]) (MDX)**

**Structure (repeatable):**

-   Summary (industry, timeline, services)

-   Challenge

-   Approach

-   Implementation

-   Results (numbers only if real)

-   Tech used (optional)

-   Next steps

-   CTA

**SEO**

-   Article schema

-   OG image per case study (generated template)

**Page 10--11: Insights (/insights, /insights/\[slug\]) (MDX)**

**Purpose:** SEO engine.

**Insights categories**

-   Smart automation

-   IoT & monitoring

-   Energy optimization

-   Security integration

-   Operations analytics

-   Project delivery guides

**Post template**

-   TL;DR

-   Problem

-   Framework / checklist

-   Examples

-   FAQ

-   CTA

**SEO**

-   Article schema + author + publish date

-   Related posts block

**Page 12: About (/about)**

**S1 Mission**\
**S2 What Elyon does (clear, specific)**\
**S3 Team / leadership**\
**S4 Approach & values**\
**S5 Partners**\
**S6 CTA**

**SEO**

-   Organization schema (same as home, but richer)

**Page 13: Contact (/contact)**

**S1 Contact hero**\
**S2 Contact form**

-   Fields: Name, Company, Email, Phone, Industry, What you need, Budget
    range (optional), Timeline

-   Spam protection: honeypot + rate limit + optional Turnstile\
    **S3 Direct channels**

-   Email, phone, WhatsApp, address (if any)\
    **S4 "What happens next"**

-   Response time promise (only if you can meet it)

**No DB requirement**

-   Form submissions emailed to you; optionally also posted to Slack via
    webhook (still no DB).

**Legal pages (/privacy, /terms)**

Keep simple and compliant for your jurisdiction.

**7) SEO requirements (must-have)**

1.  **Clean URLs**: lowercase, hyphenated slugs

2.  **Metadata per page**: title, meta description, canonical

3.  **Open Graph / Twitter cards**: per page with dynamic OG images
    (simple template)

4.  **Structured data**

    -   Organization schema (sitewide)

    -   Breadcrumb schema (detail pages)

    -   FAQ schema (FAQ sections)

    -   Article schema (Insights + Case studies)

5.  **Sitemap.xml + robots.txt**

6.  **Internal linking strategy**

    -   Every Solution links to 2--3 Industries and 2--3 Use Cases

    -   Every Industry links to 3--6 Solutions + relevant case studies

    -   Insights link to the relevant solution page

7.  **Performance**

    -   Image optimization (next/image), lazy-load below fold

    -   Font loading: self-host or optimized provider loading

8.  **Accessibility**

    -   Proper H1 (one per page), semantic headings, alt text

9.  **Content**

    -   Each Solution/Industry page: target 700--1200 words (real value,
        not fluff)

    -   FAQs: 6--10 per important page

**8) Design & UX requirements**

-   Modern dark or light theme (your choice), but readability first

-   Consistent CTA placement: top hero + end of page

-   Sticky header on desktop

-   Mobile nav: full-screen drawer

-   Components:

    -   Service cards

    -   Logo wall

    -   Testimonial carousel (optional)

    -   Comparison table component

    -   FAQ accordion

    -   "Related content" block

**9) Content management (no CMS / no DB)**

**MDX collections:**

-   /content/insights/\*.mdx

-   /content/case-studies/\*.mdx

-   Optional: /content/pages/\*.mdx for long pages

**Frontmatter fields**

-   title, description, slug, publishDate, updatedDate, tags, heroImage,
    ogImage, canonical (optional)

**10) Analytics & tracking (minimal)**

-   Plausible / Umami / GA4 (choose one)

-   Track:

    -   Form submits

    -   Book-call clicks

    -   WhatsApp clicks

    -   Top landing pages and conversions

**11) Security & compliance (basic)**

-   Contact form: rate limit + honeypot + server-side validation

-   CSP headers (basic)

-   No sensitive data collection on forms (avoid national IDs, etc.)

-   Privacy page includes analytics disclosure

**12) Delivery plan (milestones)**

1.  **IA + wireframe** (sitemap final + section layout)

2.  **Design system** (typography, buttons, cards, spacing)

3.  **Core pages build**: Home, Solutions, Industries, Contact

4.  **Templates**: Solution detail, Industry detail, Use case detail

5.  **Content population** (at least 6 solutions + 6 industries + 6 use
    cases)

6.  **Insights + case studies** (minimum 6 posts + 3 case studies to
    start)

7.  **SEO + performance pass**

8.  **Launch**

**13) Acceptance criteria checklist**

-   All sitemap pages exist and are indexable (except thank-you if you
    prefer noindex)

-   Lighthouse (mobile): strong scores, Core Web Vitals passing

-   Sitemap.xml generated and submitted

-   Each page has unique title + meta description

-   Contact form works end-to-end without storing submissions in a
    database

-   MDX content can be added by editing files and redeploying

-   No broken links, consistent header/footer across pages
