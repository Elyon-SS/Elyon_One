import { FileText, TrendingUp, Award } from "lucide-react";

export interface CaseStudy {
  slug: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
  benefits: string[];
  client: string;
  industry: string;
  challenge: string;
  solution: string;
  results: {
    metric: string;
    value: string;
    description: string;
  }[];
  testimonial?: {
    quote: string;
    author: string;
    position: string;
  };
  timeline?: string;
  technologies?: string[];
}

export const caseStudies: CaseStudy[] = [
  {
    slug: "smart-facility-management",
    title: "Smart Facility Management Transformation",
    description:
      "How a major real estate company reduced operational costs by 35% through integrated smart building solutions.",
    icon: "Building2",
    features: [
      "Integrated BMS platform deployment",
      "IoT sensor network installation",
      "Real-time monitoring dashboard",
      "Predictive maintenance implementation",
      "Energy optimization algorithms",
      "Mobile facility management app",
    ],
    benefits: [
      "35% reduction in operational costs",
      "50% faster incident response time",
      "25% improvement in tenant satisfaction",
      "40% reduction in energy consumption",
      "60% decrease in equipment downtime",
    ],
    client: "Premier Properties Group",
    industry: "Real Estate & Facilities",
    challenge:
      "Premier Properties Group managed a portfolio of 15 commercial buildings with outdated building management systems. The fragmented infrastructure led to high operational costs, frequent equipment failures, and tenant complaints about comfort and response times.",
    solution:
      "Elyon Smart Solutions deployed an integrated smart building platform that unified all building systems under a single management interface. We installed IoT sensors throughout the facilities for real-time monitoring, implemented AI-driven predictive maintenance, and created automated workflows for facility management tasks.",
    results: [
      {
        metric: "Operational Cost Reduction",
        value: "35%",
        description: "Annual savings in facility management operations",
      },
      {
        metric: "Energy Savings",
        value: "40%",
        description: "Reduction in energy consumption across portfolio",
      },
      {
        metric: "Equipment Downtime",
        value: "-60%",
        description: "Decrease in unplanned equipment failures",
      },
      {
        metric: "Tenant Satisfaction",
        value: "+25%",
        description: "Improvement in tenant satisfaction scores",
      },
    ],
    testimonial: {
      quote:
        "Elyon transformed how we manage our properties. The visibility and control we now have is unprecedented, and our tenants have noticed the difference.",
      author: "Rajesh Kumar",
      position: "Director of Operations, Premier Properties Group",
    },
    timeline: "6 months",
    technologies: [
      "IoT Sensors",
      "BMS Integration",
      "AI Analytics",
      "Mobile App",
      "Cloud Platform",
    ],
  },
  {
    slug: "retail-analytics",
    title: "Retail Analytics & Operations Optimization",
    description:
      "A leading retail chain increases sales and reduces costs with data-driven store operations.",
    icon: "ShoppingBag",
    features: [
      "Customer traffic analytics deployment",
      "Heat mapping and dwell time analysis",
      "Staff scheduling optimization",
      "Inventory prediction systems",
      "Energy management integration",
      "Real-time store performance dashboards",
    ],
    benefits: [
      "22% increase in sales conversion",
      "30% reduction in energy costs",
      "45% improvement in staff efficiency",
      "20% reduction in inventory carrying costs",
      "35% faster stock replenishment",
    ],
    client: "Fashion Forward Retail",
    industry: "Retail",
    challenge:
      "Fashion Forward Retail operated 50+ stores across India but lacked visibility into customer behavior and store performance. Manual processes for staffing, inventory, and energy management resulted in missed opportunities and unnecessary costs.",
    solution:
      "Elyon implemented a comprehensive retail analytics platform that tracked customer movement, optimized staff schedules based on traffic patterns, and automated inventory predictions. We also deployed smart energy management systems that adjusted lighting and HVAC based on occupancy and store hours.",
    results: [
      {
        metric: "Sales Conversion Rate",
        value: "+22%",
        description: "Improvement in customer-to-purchase conversion",
      },
      {
        metric: "Energy Cost Savings",
        value: "30%",
        description: "Reduction in store energy consumption",
      },
      {
        metric: "Staff Efficiency",
        value: "+45%",
        description: "Improvement in staff productivity metrics",
      },
      {
        metric: "Inventory Optimization",
        value: "-20%",
        description: "Reduction in excess inventory holding",
      },
    ],
    testimonial: {
      quote:
        "The insights we gained from Elyon's analytics platform changed how we run our stores. We're making smarter decisions and our customers are happier.",
      author: "Priya Sharma",
      position: "VP of Operations, Fashion Forward Retail",
    },
    timeline: "4 months",
    technologies: [
      "People Counting Sensors",
      "Video Analytics",
      "Machine Learning",
      "Cloud Analytics",
      "Mobile Dashboard",
    ],
  },
  {
    slug: "manufacturing-automation",
    title: "Manufacturing Automation Excellence",
    description:
      "A manufacturing company achieves Industry 4.0 transformation with predictive maintenance and process automation.",
    icon: "Factory",
    features: [
      "Production line IoT deployment",
      "Predictive maintenance system",
      "Quality control automation",
      "Energy monitoring integration",
      "Production scheduling optimization",
      "Safety monitoring systems",
    ],
    benefits: [
      "50% reduction in unplanned downtime",
      "28% increase in overall equipment effectiveness",
      "35% reduction in maintenance costs",
      "25% improvement in product quality",
      "40% faster production cycles",
    ],
    client: "TechForge Industries",
    industry: "Manufacturing",
    challenge:
      "TechForge Industries, a precision components manufacturer, faced frequent equipment breakdowns that disrupted production schedules. Manual quality inspection was slow and inconsistent, and the lack of real-time visibility made it difficult to optimize production efficiency.",
    solution:
      "Elyon deployed a comprehensive Industry 4.0 solution including IoT sensors on all critical equipment, AI-powered predictive maintenance, and automated quality inspection systems. We integrated these with the existing ERP system for seamless production planning and scheduling.",
    results: [
      {
        metric: "Unplanned Downtime",
        value: "-50%",
        description: "Reduction in unexpected equipment failures",
      },
      {
        metric: "OEE Improvement",
        value: "+28%",
        description: "Increase in Overall Equipment Effectiveness",
      },
      {
        metric: "Maintenance Costs",
        value: "-35%",
        description: "Reduction in total maintenance expenditure",
      },
      {
        metric: "Quality Improvement",
        value: "+25%",
        description: "Reduction in defect rates",
      },
    ],
    testimonial: {
      quote:
        "Moving from reactive to predictive maintenance has transformed our operations. We now anticipate issues before they happen and our production line runs like clockwork.",
      author: "Amit Patel",
      position: "Plant Director, TechForge Industries",
    },
    timeline: "8 months",
    technologies: [
      "Industrial IoT",
      "Machine Learning",
      "Computer Vision",
      "Edge Computing",
      "MES Integration",
    ],
  },
];

export const getCaseStudyBySlug = (slug: string): CaseStudy | undefined => {
  return caseStudies.find((study) => study.slug === slug);
};

export const getIconComponent = (iconName: string) => {
  const icons: Record<string, typeof FileText> = {
    FileText,
    TrendingUp,
    Award,
    Building2: FileText,
    ShoppingBag: TrendingUp,
    Factory: Award,
  };
  return icons[iconName];
};
