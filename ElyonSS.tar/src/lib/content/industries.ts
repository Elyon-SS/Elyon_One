import {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
} from "lucide-react";

export interface Industry {
  slug: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
  benefits: string[];
  challenges?: string[];
  solutions?: string[];
}

export const industries: Industry[] = [
  {
    slug: "real-estate-facilities",
    title: "Real Estate & Facilities",
    description:
      "Transform property management with smart building solutions that enhance tenant experience and optimize operational efficiency.",
    icon: "Building",
    features: [
      "Tenant experience platforms",
      "Space utilization analytics",
      "Predictive maintenance for building systems",
      "Energy management and optimization",
      "Visitor management systems",
      "Integrated security solutions",
    ],
    benefits: [
      "Increase tenant satisfaction and retention",
      "Reduce operational costs by 20-30%",
      "Extend asset lifespan through predictive maintenance",
      "Meet sustainability and ESG goals",
      "Streamline property management operations",
    ],
    challenges: [
      "Aging infrastructure requiring modernization",
      "Fragmented building systems and data silos",
      "Rising energy costs and sustainability demands",
      "Tenant expectations for smart amenities",
    ],
    solutions: [
      "smart-building",
      "energy-optimization",
      "security-surveillance",
      "iot-monitoring",
    ],
  },
  {
    slug: "retail",
    title: "Retail",
    description:
      "Create smarter retail environments with IoT solutions that enhance customer experience and optimize store operations.",
    icon: "ShoppingBag",
    features: [
      "Customer traffic analytics",
      "Smart inventory management",
      "Energy-efficient store operations",
      "Loss prevention systems",
      "Digital signage integration",
      "Omnichannel experience enablement",
    ],
    benefits: [
      "Increase sales through improved customer insights",
      "Reduce shrinkage and inventory costs",
      "Optimize store staffing based on traffic patterns",
      "Create engaging shopping experiences",
      "Lower energy consumption across locations",
    ],
    challenges: [
      "Intense competition from e-commerce",
      "Rising operational costs",
      "Need for personalized customer experiences",
      "Inventory management complexities",
    ],
    solutions: [
      "ai-dashboards",
      "smart-automation",
      "energy-optimization",
      "security-surveillance",
    ],
  },
  {
    slug: "logistics-warehousing",
    title: "Logistics & Warehousing",
    description:
      "Optimize supply chain operations with intelligent automation and monitoring solutions for warehouses and distribution centers.",
    icon: "Package",
    features: [
      "Warehouse automation systems",
      "Real-time inventory tracking",
      "Fleet management solutions",
      "Cold chain monitoring",
      "Predictive equipment maintenance",
      "Order fulfillment optimization",
    ],
    benefits: [
      "Accelerate order fulfillment times",
      "Reduce inventory inaccuracies",
      "Optimize warehouse space utilization",
      "Prevent costly equipment failures",
      "Improve supply chain visibility",
    ],
    challenges: [
      "Labor shortages and rising wages",
      "Increasing customer expectations for speed",
      "Complex multi-channel distribution",
      "Temperature-sensitive goods handling",
    ],
    solutions: [
      "smart-automation",
      "iot-monitoring",
      "ai-dashboards",
      "security-surveillance",
    ],
  },
  {
    slug: "healthcare",
    title: "Healthcare",
    description:
      "Improve patient care and facility operations with smart healthcare solutions that ensure safety, efficiency, and compliance.",
    icon: "Heart",
    features: [
      "Medical equipment tracking",
      "Environmental monitoring",
      "Patient flow optimization",
      "Compliance management systems",
      "Energy management for critical facilities",
      "Integrated security and access control",
    ],
    benefits: [
      "Enhance patient safety and experience",
      "Ensure regulatory compliance",
      "Optimize critical resource utilization",
      "Reduce energy costs in 24/7 facilities",
      "Improve staff efficiency and satisfaction",
    ],
    challenges: [
      "Strict regulatory requirements",
      "24/7 operational demands",
      "Rising healthcare costs",
      "Aging medical infrastructure",
    ],
    solutions: [
      "iot-monitoring",
      "security-surveillance",
      "smart-building",
      "smart-automation",
    ],
  },
  {
    slug: "manufacturing",
    title: "Manufacturing",
    description:
      "Drive Industry 4.0 transformation with smart manufacturing solutions that increase productivity and reduce operational costs.",
    icon: "Factory",
    features: [
      "Production line monitoring",
      "Predictive maintenance systems",
      "Quality control automation",
      "Energy consumption optimization",
      "Supply chain integration",
      "Safety and compliance systems",
    ],
    benefits: [
      "Increase overall equipment effectiveness",
      "Reduce unplanned downtime by 50%",
      "Improve product quality and consistency",
      "Lower energy and maintenance costs",
      "Enable data-driven production decisions",
    ],
    challenges: [
      "Pressure to increase productivity",
      "Complex legacy systems integration",
      "Skilled labor shortage",
      "Global supply chain disruptions",
    ],
    solutions: [
      "smart-automation",
      "iot-monitoring",
      "ai-dashboards",
      "energy-optimization",
    ],
  },
  {
    slug: "hospitality",
    title: "Hospitality",
    description:
      "Elevate guest experiences with smart hospitality solutions that combine comfort, efficiency, and personalized service.",
    icon: "Hotel",
    features: [
      "Guest room automation",
      "Energy management systems",
      "Guest experience platforms",
      "Predictive maintenance",
      "Smart access solutions",
      "Sustainability monitoring",
    ],
    benefits: [
      "Enhance guest satisfaction and loyalty",
      "Reduce energy costs in guest rooms by 30%",
      "Streamline housekeeping operations",
      "Meet sustainability certifications",
      "Enable personalized guest services",
    ],
    challenges: [
      "Rising guest expectations for technology",
      "High energy consumption in 24/7 operations",
      "Need for operational efficiency",
      "Sustainability and green certifications",
    ],
    solutions: [
      "smart-building",
      "energy-optimization",
      "security-surveillance",
      "iot-monitoring",
    ],
  },
];

export const getIndustryBySlug = (slug: string): Industry | undefined => {
  return industries.find((industry) => industry.slug === slug);
};

export const getIconComponent = (iconName: string) => {
  const icons: Record<string, typeof Building> = {
    Building,
    ShoppingBag,
    Package,
    Heart,
    Factory,
    Hotel,
  };
  return icons[iconName];
};
