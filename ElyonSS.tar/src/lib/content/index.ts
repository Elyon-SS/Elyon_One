// Content data files for Elyon Smart Solutions
// All content is stored in TypeScript files for easy management and type safety

export { solutions, getSolutionBySlug } from "./solutions";
export type { Solution } from "./solutions";

export { industries, getIndustryBySlug } from "./industries";
export type { Industry } from "./industries";

export { useCases, getUseCaseBySlug } from "./use-cases";
export type { UseCase } from "./use-cases";

export { caseStudies, getCaseStudyBySlug } from "./case-studies";
export type { CaseStudy } from "./case-studies";

export { insights, getInsightBySlug } from "./insights";
export type { Insight } from "./insights";
