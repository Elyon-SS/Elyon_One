import {
  Users,
  LayoutDashboard,
  Settings,
  Wrench,
  Gauge,
  Lock,
} from "lucide-react";

export interface UseCase {
  slug: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
  benefits: string[];
  metrics?: {
    label: string;
    value: string;
  }[];
  relatedSolutions?: string[];
  // Extended details for detail page
  longDescription?: string;
  trigger?: string;
  workflowSteps?: {
    step: number;
    title: string;
    description: string;
  }[];
  dataInputs?: string[];
  outputs?: string[];
  faqs?: {
    question: string;
    answer: string;
  }[];
  relatedIndustries?: string[];
}

export const useCases: UseCase[] = [
  {
    slug: "agent-management",
    title: "Agent Management Systems",
    description:
      "Streamline field operations with intelligent agent management that optimizes scheduling, tracking, and performance monitoring.",
    icon: "Users",
    features: [
      "Real-time agent location tracking",
      "Automated task assignment",
      "Performance analytics dashboards",
      "Mobile app integration",
      "Attendance and time management",
      "Route optimization",
    ],
    benefits: [
      "Improve field team productivity by 35%",
      "Reduce scheduling conflicts and overlaps",
      "Enable real-time visibility into operations",
      "Automate performance reporting",
      "Enhance customer service response times",
    ],
    metrics: [
      { label: "Productivity Increase", value: "35%" },
      { label: "Response Time Reduction", value: "40%" },
      { label: "Scheduling Efficiency", value: "50%" },
    ],
    relatedSolutions: ["smart-automation", "ai-dashboards"],
    relatedIndustries: ["logistics-warehousing", "healthcare", "real-estate-facilities"],
  },
  {
    slug: "dashboards",
    title: "Operations Dashboards",
    description:
      "Centralize operational data into intuitive dashboards that provide real-time visibility and actionable insights.",
    icon: "LayoutDashboard",
    features: [
      "Real-time KPI monitoring",
      "Customizable widget layouts",
      "Multi-location aggregation",
      "Automated alerts and notifications",
      "Historical trend analysis",
      "Export and sharing capabilities",
    ],
    benefits: [
      "Make faster data-driven decisions",
      "Reduce reporting time by 60%",
      "Improve cross-team collaboration",
      "Identify issues before they escalate",
      "Standardize performance metrics",
    ],
    metrics: [
      { label: "Reporting Time Saved", value: "60%" },
      { label: "Decision Speed", value: "3x Faster" },
      { label: "Issue Resolution", value: "45% Faster" },
    ],
    relatedSolutions: ["ai-dashboards", "iot-monitoring"],
  },
  {
    slug: "process-automation",
    title: "Process Automation",
    description:
      "Automate repetitive tasks and workflows to reduce manual effort, minimize errors, and accelerate business processes.",
    icon: "Settings",
    features: [
      "Visual workflow builder",
      "Integration with existing systems",
      "Conditional logic and triggers",
      "Approval workflow automation",
      "Document processing automation",
      "Email and notification automation",
    ],
    benefits: [
      "Reduce operational costs by 40%",
      "Eliminate manual errors in workflows",
      "Accelerate process cycle times",
      "Improve compliance and auditability",
      "Free employees for strategic work",
    ],
    metrics: [
      { label: "Cost Reduction", value: "40%" },
      { label: "Error Reduction", value: "90%" },
      { label: "Process Speed", value: "5x Faster" },
    ],
    relatedSolutions: ["smart-automation"],
  },
  {
    slug: "predictive-maintenance",
    title: "Predictive Maintenance",
    description:
      "Prevent equipment failures with AI-powered predictive maintenance that anticipates issues before they cause downtime.",
    icon: "Wrench",
    features: [
      "Sensor-based equipment monitoring",
      "Machine learning failure prediction",
      "Maintenance scheduling optimization",
      "Spare parts inventory management",
      "Work order automation",
      "Equipment health scoring",
    ],
    benefits: [
      "Reduce unplanned downtime by 50%",
      "Lower maintenance costs by 25%",
      "Extend equipment lifespan",
      "Optimize maintenance team scheduling",
      "Improve safety and reliability",
    ],
    metrics: [
      { label: "Downtime Reduction", value: "50%" },
      { label: "Maintenance Cost Savings", value: "25%" },
      { label: "Equipment Lifespan", value: "+20%" },
    ],
    relatedSolutions: ["iot-monitoring", "ai-dashboards"],
  },
  {
    slug: "energy-monitoring",
    title: "Energy Monitoring",
    description:
      "Monitor, analyze, and optimize energy consumption across facilities to reduce costs and meet sustainability goals.",
    icon: "Gauge",
    features: [
      "Real-time energy consumption tracking",
      "Granular meter-level monitoring",
      "Anomaly detection and alerts",
      "Cost allocation by department",
      "Carbon footprint calculation",
      "Benchmark and comparison tools",
    ],
    benefits: [
      "Reduce energy costs by 20-30%",
      "Meet sustainability and ESG targets",
      "Identify energy waste opportunities",
      "Enable accurate cost allocation",
      "Support green building certifications",
    ],
    metrics: [
      { label: "Energy Cost Savings", value: "25%" },
      { label: "Carbon Reduction", value: "30%" },
      { label: "ROI Period", value: "12-18 Months" },
    ],
    relatedSolutions: ["energy-optimization", "smart-building"],
  },
  {
    slug: "access-control",
    title: "Access Control & Security",
    description:
      "Secure facilities with integrated access control and monitoring solutions that protect people, assets, and information.",
    icon: "Lock",
    features: [
      "Multi-factor authentication",
      "Biometric access systems",
      "Visitor management",
      "Time-based access rules",
      "Real-time occupancy monitoring",
      "Integration with video surveillance",
    ],
    benefits: [
      "Enhance facility security",
      "Streamline visitor processing",
      "Maintain compliance with regulations",
      "Reduce security personnel costs",
      "Create detailed access audit trails",
    ],
    metrics: [
      { label: "Security Incidents", value: "-60%" },
      { label: "Visitor Processing Time", value: "-70%" },
      { label: "Compliance Score", value: "100%" },
    ],
    relatedSolutions: ["security-surveillance", "smart-building"],
  },
];

export const getUseCaseBySlug = (slug: string): UseCase | undefined => {
  return useCases.find((useCase) => useCase.slug === slug);
};

export const getIconComponent = (iconName: string) => {
  const icons: Record<string, typeof Users> = {
    Users,
    LayoutDashboard,
    Settings,
    Wrench,
    Gauge,
    Lock,
  };
  return icons[iconName];
};

// Extended details for each use case
export const useCaseDetails: Record<string, {
  longDescription: string;
  trigger: string;
  workflowSteps: { step: number; title: string; description: string }[];
  dataInputs: string[];
  outputs: string[];
  faqs: { question: string; answer: string }[];
  relatedIndustries: string[];
}> = {
  "agent-management": {
    longDescription: "Agent Management Systems provide comprehensive tools for managing field teams, tracking performance, and optimizing scheduling. This solution is ideal for organizations with distributed workforces who need real-time visibility into field operations.",
    trigger: "Organizations with field teams struggling to track agent locations, manage schedules efficiently, or measure performance in real-time.",
    workflowSteps: [
      { step: 1, title: "Agent Onboarding", description: "Register agents in the system with profile details, skills, and territory assignments" },
      { step: 2, title: "Task Assignment", description: "Automated or manual task assignment based on location, skills, and availability" },
      { step: 3, title: "Real-Time Tracking", description: "Monitor agent locations and task progress through GPS-enabled mobile apps" },
      { step: 4, title: "Performance Analytics", description: "Generate reports on productivity, completion rates, and service quality" },
      { step: 5, title: "Continuous Optimization", description: "Use insights to improve scheduling, routing, and resource allocation" },
    ],
    dataInputs: [
      "Agent profiles and credentials",
      "Service request details and locations",
      "Agent availability and schedules",
      "Skill matrices and certifications",
      "Geographic territory definitions",
      "Customer preferences and history",
    ],
    outputs: [
      "Real-time agent location and status",
      "Optimized daily schedules and routes",
      "Performance dashboards and reports",
      "Attendance and time tracking records",
      "Customer service metrics",
      "Resource utilization analytics",
    ],
    faqs: [
      { question: "How does the system handle agent check-ins and attendance?", answer: "Agents can check in via the mobile app using GPS verification, facial recognition, or QR code scanning at designated locations. The system automatically records attendance and validates work hours." },
      { question: "Can the system integrate with our existing CRM?", answer: "Yes, our Agent Management System integrates with popular CRM platforms including Salesforce, HubSpot, and custom systems via REST APIs. This ensures seamless data flow between customer records and field operations." },
      { question: "How does route optimization work?", answer: "The system uses AI algorithms to optimize routes based on multiple factors including task priority, agent location, traffic patterns, service windows, and customer preferences. Routes are dynamically adjusted throughout the day as new tasks are assigned." },
    ],
    relatedIndustries: ["logistics-warehousing", "healthcare", "real-estate-facilities"],
  },
  "dashboards": {
    longDescription: "Operations Dashboards centralize critical business data into intuitive visualizations, enabling teams to monitor KPIs, identify trends, and make data-driven decisions in real-time.",
    trigger: "Teams spending excessive time compiling reports, lacking visibility into operations, or struggling to make timely decisions due to data fragmentation.",
    workflowSteps: [
      { step: 1, title: "Data Source Integration", description: "Connect to existing data sources including databases, APIs, and IoT systems" },
      { step: 2, title: "KPI Definition", description: "Work with stakeholders to identify and define key performance indicators" },
      { step: 3, title: "Dashboard Design", description: "Create custom visualizations and layouts tailored to user roles" },
      { step: 4, title: "Alert Configuration", description: "Set up automated alerts for threshold breaches and anomalies" },
      { step: 5, title: "Deployment & Training", description: "Roll out dashboards with user training and documentation" },
    ],
    dataInputs: [
      "Database connections (SQL, NoSQL)",
      "API endpoints and webhooks",
      "IoT sensor data streams",
      "Spreadsheet imports",
      "ERP/CRM system data",
      "Manual data entry forms",
    ],
    outputs: [
      "Real-time KPI visualizations",
      "Trend analysis charts",
      "Automated reports and alerts",
      "Drill-down analytics",
      "Exportable data summaries",
      "Performance scorecards",
    ],
    faqs: [
      { question: "How long does it take to build a custom dashboard?", answer: "Simple dashboards can be deployed in 1-2 weeks. Complex enterprise dashboards with multiple data sources and advanced analytics typically take 4-8 weeks including integration and user training." },
      { question: "Can dashboards be accessed on mobile devices?", answer: "Yes, all dashboards are fully responsive and optimized for mobile, tablet, and desktop viewing. We also offer native iOS and Android apps for on-the-go access." },
      { question: "What security measures protect our data?", answer: "We implement role-based access controls, data encryption at rest and in transit, audit logging, and comply with industry standards. On-premises deployment is available for organizations with strict data sovereignty requirements." },
    ],
    relatedIndustries: ["retail", "manufacturing", "logistics-warehousing"],
  },
  "process-automation": {
    longDescription: "Process Automation transforms manual, repetitive workflows into streamlined digital processes, reducing errors, accelerating cycle times, and freeing employees to focus on strategic work.",
    trigger: "Organizations experiencing bottlenecks from manual processes, high error rates in routine tasks, or compliance issues due to inconsistent process execution.",
    workflowSteps: [
      { step: 1, title: "Process Discovery", description: "Map existing workflows and identify automation opportunities" },
      { step: 2, title: "Workflow Design", description: "Design automated workflows with triggers, conditions, and actions" },
      { step: 3, title: "Integration Setup", description: "Connect workflows to existing systems and data sources" },
      { step: 4, title: "Testing & Validation", description: "Test workflows thoroughly before production deployment" },
      { step: 5, title: "Monitoring & Optimization", description: "Monitor performance and continuously optimize automated processes" },
    ],
    dataInputs: [
      "Form submissions and documents",
      "Email triggers and notifications",
      "Database changes and events",
      "API calls from external systems",
      "Scheduled time-based triggers",
      "User actions and approvals",
    ],
    outputs: [
      "Automated task execution",
      "Approval notifications and escalations",
      "Process audit trails",
      "Status updates and reports",
      "Document generation",
      "Integration data syncs",
    ],
    faqs: [
      { question: "What types of processes can be automated?", answer: "Almost any rule-based, repetitive process can be automated including approvals, data entry, report generation, email campaigns, invoice processing, employee onboarding, and customer communications." },
      { question: "Do we need coding skills to manage automations?", answer: "No, our visual workflow builder allows non-technical users to create and modify automations through drag-and-drop interfaces. For complex integrations, our team provides implementation support." },
      { question: "How do you handle exceptions in automated workflows?", answer: "Workflows can include exception handling rules that route unusual cases to human reviewers. The system logs all exceptions and provides analytics to help improve workflow logic over time." },
    ],
    relatedIndustries: ["healthcare", "logistics-warehousing", "manufacturing"],
  },
  "predictive-maintenance": {
    longDescription: "Predictive Maintenance uses IoT sensors and AI algorithms to anticipate equipment failures before they occur, enabling proactive maintenance that reduces downtime and extends asset lifespan.",
    trigger: "Facilities experiencing frequent unplanned downtime, high emergency maintenance costs, or difficulty planning maintenance schedules effectively.",
    workflowSteps: [
      { step: 1, title: "Asset Assessment", description: "Identify critical equipment and define monitoring parameters" },
      { step: 2, title: "Sensor Deployment", description: "Install IoT sensors for vibration, temperature, and other metrics" },
      { step: 3, title: "Data Collection", description: "Gather baseline data and establish normal operating patterns" },
      { step: 4, title: "Model Training", description: "Train AI models to recognize anomalies and predict failures" },
      { step: 5, title: "Predictive Alerts", description: "Generate maintenance recommendations before failures occur" },
    ],
    dataInputs: [
      "Vibration sensor readings",
      "Temperature measurements",
      "Power consumption patterns",
      "Equipment runtime logs",
      "Historical maintenance records",
      "Environmental conditions",
    ],
    outputs: [
      "Equipment health scores",
      "Failure probability predictions",
      "Maintenance schedule recommendations",
      "Remaining useful life estimates",
      "Anomaly alerts and notifications",
      "Spare parts requirements forecasts",
    ],
    faqs: [
      { question: "How accurate are failure predictions?", answer: "Our predictive maintenance models typically achieve 85-95% accuracy in predicting equipment failures 2-4 weeks in advance. Accuracy improves over time as more data is collected from your specific equipment." },
      { question: "What types of equipment can be monitored?", answer: "We can monitor virtually any mechanical or electrical equipment including HVAC systems, pumps, motors, compressors, generators, conveyor systems, and production machinery." },
      { question: "How does this differ from preventive maintenance?", answer: "Preventive maintenance follows fixed schedules regardless of actual equipment condition. Predictive maintenance uses real-time data to perform maintenance only when needed, reducing unnecessary work while preventing unexpected failures." },
    ],
    relatedIndustries: ["manufacturing", "real-estate-facilities", "healthcare"],
  },
  "energy-monitoring": {
    longDescription: "Energy Monitoring provides real-time visibility into energy consumption across facilities, enabling organizations to identify waste, optimize usage, and achieve sustainability goals.",
    trigger: "Organizations with rising energy costs, sustainability mandates, or difficulty understanding where and how energy is being consumed.",
    workflowSteps: [
      { step: 1, title: "Energy Audit", description: "Conduct comprehensive assessment of energy usage patterns" },
      { step: 2, title: "Meter Installation", description: "Deploy smart meters and sub-meters for granular monitoring" },
      { step: 3, title: "Baseline Establishment", description: "Establish consumption baselines and identify anomalies" },
      { step: 4, title: "Optimization Rules", description: "Configure automated controls and optimization algorithms" },
      { step: 5, title: "Continuous Reporting", description: "Generate reports and track progress toward goals" },
    ],
    dataInputs: [
      "Smart meter readings",
      "Sub-meter data by zone/equipment",
      "Weather and temperature data",
      "Occupancy schedules",
      "Utility rate schedules",
      "Production/sales activity levels",
    ],
    outputs: [
      "Real-time consumption dashboards",
      "Cost allocation reports",
      "Anomaly detection alerts",
      "Carbon footprint calculations",
      "Benchmark comparisons",
      "Savings opportunity recommendations",
    ],
    faqs: [
      { question: "What energy savings can we expect?", answer: "Most organizations achieve 15-30% reduction in energy costs. Savings depend on current efficiency levels, but we typically identify quick wins within the first month and ongoing optimization opportunities." },
      { question: "Can you help with green building certifications?", answer: "Yes, our energy monitoring provides the data and documentation needed for LEED, BREEAM, and other green building certifications. We can generate reports in the required formats." },
      { question: "How granular is the monitoring?", answer: "We can monitor at the building level down to individual circuits or equipment. Sub-metering allows cost allocation by department, tenant, or zone for accurate billing and accountability." },
    ],
    relatedIndustries: ["real-estate-facilities", "hospitality", "manufacturing"],
  },
  "access-control": {
    longDescription: "Access Control & Security solutions provide comprehensive protection for facilities through integrated authentication, monitoring, and visitor management systems.",
    trigger: "Organizations needing to secure facilities, manage visitor access, maintain compliance with security regulations, or reduce security personnel costs.",
    workflowSteps: [
      { step: 1, title: "Security Assessment", description: "Evaluate facility security needs and define access policies" },
      { step: 2, title: "System Design", description: "Design integrated access control and surveillance architecture" },
      { step: 3, title: "Hardware Deployment", description: "Install access readers, cameras, and biometric devices" },
      { step: 4, title: "Policy Configuration", description: "Configure access rules, time zones, and permissions" },
      { step: 5, title: "Monitoring Setup", description: "Enable real-time monitoring and incident response" },
    ],
    dataInputs: [
      "Employee ID and credentials",
      "Biometric data (fingerprint, face)",
      "Access card/token information",
      "Visitor details and appointments",
      "Time-based access rules",
      "Zone restrictions and permissions",
    ],
    outputs: [
      "Access granted/denied logs",
      "Real-time occupancy tracking",
      "Visitor badges and records",
      "Security incident reports",
      "Audit trail documentation",
      "Alert notifications",
    ],
    faqs: [
      { question: "What authentication methods are supported?", answer: "We support multiple authentication methods including keycards, PIN codes, mobile credentials, fingerprint scanners, facial recognition, and multi-factor combinations. The system can be configured to require different methods for different security zones." },
      { question: "How does visitor management work?", answer: "Visitors can pre-register online or check in at kiosks. The system captures ID, photo, and purpose of visit, then issues temporary credentials with time-limited access. Hosts receive notifications and can approve or deny visits." },
      { question: "Can the system integrate with our existing security cameras?", answer: "Yes, we integrate with most major camera brands including Hikvision, Dahua, Axis, and Bosch. The system can link access events with video footage for comprehensive incident investigation." },
    ],
    relatedIndustries: ["real-estate-facilities", "healthcare", "hospitality"],
  },
};

// Get extended details for a use case
export const getUseCaseDetails = (slug: string) => {
  return useCaseDetails[slug];
};
