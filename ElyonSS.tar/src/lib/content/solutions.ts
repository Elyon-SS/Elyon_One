import {
  Cog,
  Activity,
  BarChart3,
  Zap,
  Shield,
  Building2,
} from "lucide-react";

export interface Solution {
  slug: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
  benefits: string[];
  longDescription?: string;
}

export const solutions: Solution[] = [
  {
    slug: "smart-automation",
    title: "Smart Automation",
    description:
      "Streamline operations with intelligent process automation and workflow optimization that reduces manual effort and increases efficiency.",
    icon: "Cog",
    features: [
      "Workflow automation and orchestration",
      "Rule-based process triggers",
      "Integration with existing systems",
      "Real-time process monitoring",
      "Automated reporting and alerts",
      "Custom automation workflows",
    ],
    benefits: [
      "Reduce operational costs by up to 40%",
      "Minimize human error in repetitive tasks",
      "Accelerate process completion times",
      "Improve compliance and audit trails",
      "Free up staff for strategic work",
    ],
    longDescription:
      "Our Smart Automation solutions transform manual, paper-based processes into streamlined digital workflows. By leveraging intelligent automation, we help organizations eliminate bottlenecks, reduce errors, and achieve unprecedented operational efficiency.",
  },
  {
    slug: "iot-monitoring",
    title: "IoT Monitoring",
    description:
      "Real-time device monitoring and predictive maintenance solutions that keep your operations running smoothly and prevent costly downtime.",
    icon: "Activity",
    features: [
      "Real-time device status tracking",
      "Predictive maintenance alerts",
      "Sensor data aggregation",
      "Anomaly detection algorithms",
      "Remote device management",
      "Historical performance analytics",
    ],
    benefits: [
      "Prevent equipment failures before they occur",
      "Reduce maintenance costs by 25%",
      "Extend equipment lifespan",
      "Minimize unplanned downtime",
      "Optimize maintenance schedules",
    ],
    longDescription:
      "Our IoT Monitoring platform connects your devices, machines, and equipment to provide comprehensive visibility into operations. With advanced analytics and predictive maintenance capabilities, you can anticipate issues before they become problems.",
  },
  {
    slug: "ai-dashboards",
    title: "AI Operations Dashboards",
    description:
      "Powerful analytics dashboards that transform raw data into actionable insights, enabling data-driven decision making across your organization.",
    icon: "BarChart3",
    features: [
      "Real-time KPI visualization",
      "AI-powered insights generation",
      "Customizable dashboard layouts",
      "Cross-platform data integration",
      "Automated report generation",
      "Predictive analytics",
    ],
    benefits: [
      "Make faster, informed decisions",
      "Identify trends and patterns automatically",
      "Improve operational visibility",
      "Reduce reporting time by 60%",
      "Enable data-driven culture",
    ],
    longDescription:
      "Transform your data into actionable intelligence with our AI Operations Dashboards. Our solutions aggregate data from multiple sources, apply machine learning algorithms, and present insights through intuitive visualizations that drive business value.",
  },
  {
    slug: "energy-optimization",
    title: "Energy Optimization",
    description:
      "Reduce energy costs and improve sustainability with intelligent energy management solutions that optimize consumption patterns.",
    icon: "Zap",
    features: [
      "Real-time energy monitoring",
      "Consumption pattern analysis",
      "Automated load balancing",
      "Carbon footprint tracking",
      "Cost optimization algorithms",
      "Sustainability reporting",
    ],
    benefits: [
      "Reduce energy costs by up to 30%",
      "Meet sustainability goals",
      "Comply with environmental regulations",
      "Optimize energy procurement",
      "Improve facility efficiency",
    ],
    longDescription:
      "Our Energy Optimization solutions help organizations reduce their environmental impact while cutting costs. Through intelligent monitoring and automated controls, we identify opportunities to optimize energy usage across all operations.",
  },
  {
    slug: "security-surveillance",
    title: "Security & Surveillance Integration",
    description:
      "Comprehensive security solutions including access control, video monitoring, and threat detection for complete facility protection.",
    icon: "Shield",
    features: [
      "Integrated access control systems",
      "AI-powered video analytics",
      "Real-time threat detection",
      "Visitor management",
      "Multi-site monitoring",
      "Incident response automation",
    ],
    benefits: [
      "Enhanced facility security",
      "Rapid incident response",
      "Reduced security personnel costs",
      "Compliance with safety regulations",
      "24/7 monitoring coverage",
    ],
    longDescription:
      "Protect your people, assets, and information with our integrated Security & Surveillance solutions. We combine access control, video analytics, and threat detection into a unified platform that provides comprehensive protection for your facilities.",
  },
  {
    slug: "smart-building",
    title: "Smart Building Management",
    description:
      "Comprehensive building management systems (BMS) that optimize HVAC, lighting, and other building systems for comfort and efficiency.",
    icon: "Building2",
    features: [
      "Integrated BMS platform",
      "HVAC optimization",
      "Smart lighting control",
      "Occupancy-based automation",
      "Indoor air quality monitoring",
      "Space utilization analytics",
    ],
    benefits: [
      "Improve occupant comfort and productivity",
      "Reduce building operating costs",
      "Extend equipment lifespan",
      "Meet green building standards",
      "Optimize space utilization",
    ],
    longDescription:
      "Create intelligent, responsive buildings with our Smart Building Management solutions. We integrate all building systems into a unified platform that optimizes comfort, efficiency, and sustainability based on real-time conditions and occupancy patterns.",
  },
];

export const getSolutionBySlug = (slug: string): Solution | undefined => {
  return solutions.find((solution) => solution.slug === slug);
};

export const getIconComponent = (iconName: string) => {
  const icons: Record<string, typeof Cog> = {
    Cog,
    Activity,
    BarChart3,
    Zap,
    Shield,
    Building2,
  };
  return icons[iconName];
};
