import Link from "next/link";
import Image from "next/image";
import { MapPin, Mail, Phone, Linkedin, Twitter, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const solutionsLinks = [
  { title: "Smart Automation", href: "/solutions/smart-automation" },
  { title: "IoT Monitoring", href: "/solutions/iot-monitoring" },
  { title: "AI Dashboards", href: "/solutions/ai-dashboards" },
  { title: "Energy Optimization", href: "/solutions/energy-optimization" },
  { title: "Security & Surveillance", href: "/solutions/security-surveillance" },
  { title: "Smart Building", href: "/solutions/smart-building" },
];

const industriesLinks = [
  { title: "Real Estate", href: "/industries/real-estate-facilities" },
  { title: "Retail", href: "/industries/retail" },
  { title: "Logistics", href: "/industries/logistics-warehousing" },
  { title: "Healthcare", href: "/industries/healthcare" },
  { title: "Manufacturing", href: "/industries/manufacturing" },
  { title: "Hospitality", href: "/industries/hospitality" },
];

const quickLinks = [
  { title: "About Us", href: "/about" },
  { title: "Case Studies", href: "/case-studies" },
  { title: "Insights", href: "/insights" },
  { title: "Contact", href: "/contact" },
];

const socialLinks = [
  {
    name: "LinkedIn",
    href: "https://linkedin.com/company/elyon",
    icon: Linkedin,
  },
  {
    name: "Twitter",
    href: "https://twitter.com/elyon",
    icon: Twitter,
  },
];

export default function Footer() {
  return (
    <footer className="relative bg-[#06060f] overflow-hidden">
      {/* Top gradient line */}
      <div className="h-px bg-gradient-to-r from-transparent via-blue-600/50 to-transparent" />
      
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 lg:px-8 py-16 lg:py-20 relative">
        {/* Background decorations */}
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-orange-500/5 rounded-full blur-3xl" />
        
        <div className="relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-12">
            {/* Company Info - Takes 2 columns on desktop */}
            <div className="lg:col-span-2 space-y-6">
              <Link href="/" className="inline-block group">
                <Image
                  src="/images/logo.png"
                  alt="Elyon Smart Solutions"
                  width={160}
                  height={48}
                  className="h-10 w-auto brightness-0 invert group-hover:opacity-80 transition-opacity"
                />
              </Link>
              <p className="text-white/60 leading-relaxed max-w-sm">
                Enabling Businesses through Smart Solutions. We transform operations with IoT, AI, and intelligent automation.
              </p>
              
              {/* Social Links */}
              <div className="flex items-center gap-3 pt-2">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-gradient-to-r hover:from-blue-600 hover:to-cyan-500 hover:border-transparent transition-all duration-300 group"
                    aria-label={social.name}
                  >
                    <social.icon className="w-4 h-4 text-white/60 group-hover:text-white transition-colors" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-sm font-semibold text-white mb-5 uppercase tracking-wider">Quick Links</h3>
              <ul className="space-y-3">
                {quickLinks.map((link) => (
                  <li key={link.title}>
                    <Link
                      href={link.href}
                      className="text-sm text-white/60 hover:text-cyan-400 transition-colors inline-flex items-center group"
                    >
                      <ArrowRight className="w-3 h-3 mr-0 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                      {link.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Solutions */}
            <div>
              <h3 className="text-sm font-semibold text-white mb-5 uppercase tracking-wider">Solutions</h3>
              <ul className="space-y-3">
                {solutionsLinks.map((link) => (
                  <li key={link.title}>
                    <Link
                      href={link.href}
                      className="text-sm text-white/60 hover:text-cyan-400 transition-colors inline-flex items-center group"
                    >
                      <ArrowRight className="w-3 h-3 mr-0 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                      {link.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Industries */}
            <div>
              <h3 className="text-sm font-semibold text-white mb-5 uppercase tracking-wider">Industries</h3>
              <ul className="space-y-3">
                {industriesLinks.map((link) => (
                  <li key={link.title}>
                    <Link
                      href={link.href}
                      className="text-sm text-white/60 hover:text-cyan-400 transition-colors inline-flex items-center group"
                    >
                      <ArrowRight className="w-3 h-3 mr-0 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                      {link.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Contact Info Bar */}
          <div className="mt-12 pt-8 border-t border-white/10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <a
                href="mailto:info@elyon.one"
                className="flex items-start gap-3 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600/20 to-cyan-500/20 flex items-center justify-center shrink-0 group-hover:from-blue-600/40 group-hover:to-cyan-500/40 transition-colors">
                  <Mail className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <div className="text-xs text-white/40 mb-1">Email us at</div>
                  <div className="text-sm text-white/80 group-hover:text-white transition-colors">info@elyon.one</div>
                </div>
              </a>

              <a
                href="tel:+914000000000"
                className="flex items-start gap-3 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-orange-500/20 to-yellow-500/20 flex items-center justify-center shrink-0 group-hover:from-orange-500/40 group-hover:to-yellow-500/40 transition-colors">
                  <Phone className="w-5 h-5 text-orange-400" />
                </div>
                <div>
                  <div className="text-xs text-white/40 mb-1">Call us at</div>
                  <div className="text-sm text-white/80 group-hover:text-white transition-colors">+91 40 0000 0000</div>
                </div>
              </a>

              <div className="flex items-start gap-3 p-4 rounded-xl bg-white/5">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-500/20 to-emerald-500/20 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <div className="text-xs text-white/40 mb-1">Visit us at</div>
                  <address className="text-sm text-white/60 not-italic leading-relaxed">
                    KNR Square, Gachibowli, Hyderabad, Telangana 500032
                  </address>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="container mx-auto px-4 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-white/40 text-center md:text-left">
              © {new Date().getFullYear()} Elyon Smart Solutions. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <Link
                href="/privacy-policy"
                className="text-sm text-white/40 hover:text-white/60 transition-colors"
              >
                Privacy Policy
              </Link>
              <Link
                href="/terms-of-service"
                className="text-sm text-white/40 hover:text-white/60 transition-colors"
              >
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
