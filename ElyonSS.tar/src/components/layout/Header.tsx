"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, Phone, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";

const solutionsItems = [
  {
    title: "Smart Automation",
    href: "/solutions/smart-automation",
    description: "Automate workflows and processes with intelligent systems.",
    icon: "⚙️",
  },
  {
    title: "IoT Monitoring",
    href: "/solutions/iot-monitoring",
    description: "Real-time monitoring and control of connected devices.",
    icon: "📡",
  },
  {
    title: "AI Dashboards",
    href: "/solutions/ai-dashboards",
    description: "Data-driven insights powered by artificial intelligence.",
    icon: "📊",
  },
  {
    title: "Energy Optimization",
    href: "/solutions/energy-optimization",
    description: "Reduce costs and carbon footprint with smart energy management.",
    icon: "⚡",
  },
  {
    title: "Security & Surveillance",
    href: "/solutions/security-surveillance",
    description: "Comprehensive security solutions for modern facilities.",
    icon: "🔒",
  },
  {
    title: "Smart Building",
    href: "/solutions/smart-building",
    description: "Integrated building management for optimal efficiency.",
    icon: "🏢",
  },
];

const industriesItems = [
  {
    title: "Real Estate",
    href: "/industries/real-estate-facilities",
    description: "Smart property management and tenant experiences.",
    icon: "🏗️",
  },
  {
    title: "Retail",
    href: "/industries/retail",
    description: "Enhance customer experience and operational efficiency.",
    icon: "🛒",
  },
  {
    title: "Logistics",
    href: "/industries/logistics-warehousing",
    description: "Optimize supply chain and warehouse operations.",
    icon: "📦",
  },
  {
    title: "Healthcare",
    href: "/industries/healthcare",
    description: "Patient-centric smart facility solutions.",
    icon: "🏥",
  },
  {
    title: "Manufacturing",
    href: "/industries/manufacturing",
    description: "Industry 4.0 solutions for smart factories.",
    icon: "🏭",
  },
  {
    title: "Hospitality",
    href: "/industries/hospitality",
    description: "Elevate guest experiences with smart technology.",
    icon: "🏨",
  },
];

const ListItem = ({
  title,
  href,
  icon,
}: {
  title: string;
  href: string;
  icon: string;
}) => {
  return (
    <li className="list-none">
      <NavigationMenuLink asChild>
        <Link
          href={href}
          className="flex flex-row items-center gap-3 select-none rounded-xl px-4 py-3 leading-none no-underline outline-none transition-all duration-300 hover:bg-white/10 focus:bg-white/10 text-left w-full"
        >
          <span className="text-lg shrink-0">{icon}</span>
          <span className="text-sm font-medium text-white text-left">{title}</span>
        </Link>
      </NavigationMenuLink>
    </li>
  );
};

// Desktop Navigation Component
function DesktopNav() {
  return (
    <div className="hidden lg:flex items-center gap-1">
      <NavigationMenu>
        <NavigationMenuList>
          {/* Solutions Dropdown */}
          <NavigationMenuItem>
            <NavigationMenuTrigger className="bg-transparent text-white/80 hover:text-orange-400 px-4 py-2 rounded-lg transition-all [&>svg]:hidden">
              Solutions
            </NavigationMenuTrigger>
            <NavigationMenuContent>
              <div className="w-[280px] p-2 bg-[#0f1029]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl">
                <ul className="grid gap-0.5">
                  {solutionsItems.map((item) => (
                    <ListItem key={item.title} title={item.title} href={item.href} icon={item.icon} />
                  ))}
                </ul>
              </div>
            </NavigationMenuContent>
          </NavigationMenuItem>

          {/* Industries Dropdown */}
          <NavigationMenuItem>
            <NavigationMenuTrigger className="bg-transparent text-white/80 hover:text-orange-400 px-4 py-2 rounded-lg transition-all [&>svg]:hidden">
              Industries
            </NavigationMenuTrigger>
            <NavigationMenuContent>
              <div className="w-[280px] p-2 bg-[#0f1029]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl">
                <ul className="grid gap-0.5">
                  {industriesItems.map((item) => (
                    <ListItem key={item.title} title={item.title} href={item.href} icon={item.icon} />
                  ))}
                </ul>
              </div>
            </NavigationMenuContent>
          </NavigationMenuItem>

          {/* Simple Links */}
          <NavigationMenuItem>
            <Link
              href="/case-studies"
              className={cn(
                "inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-orange-400 hover:bg-white/5 transition-all"
              )}
            >
              Case Studies
            </Link>
          </NavigationMenuItem>

          <NavigationMenuItem>
            <Link
              href="/insights"
              className={cn(
                "inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-orange-400 hover:bg-white/5 transition-all"
              )}
            >
              Insights
            </Link>
          </NavigationMenuItem>

          <NavigationMenuItem>
            <Link
              href="/about"
              className={cn(
                "inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-orange-400 hover:bg-white/5 transition-all"
              )}
            >
              About
            </Link>
          </NavigationMenuItem>
        </NavigationMenuList>
      </NavigationMenu>
    </div>
  );
}

// Mobile Navigation Component
function MobileNav({ isOpen, setIsOpen }: { isOpen: boolean; setIsOpen: (open: boolean) => void }) {
  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild className="lg:hidden">
        <Button variant="ghost" size="icon" className="text-white">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[320px] sm:w-[350px] bg-[#0a0a1a] border-l border-white/10 p-0">
        <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
        <div className="flex flex-col h-full">
          {/* Mobile Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <Image
              src="/images/logo.png"
              alt="Elyon Smart Solutions"
              width={120}
              height={32}
              className="h-8 w-auto brightness-0 invert"
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Mobile Navigation Links */}
          <div className="flex-1 overflow-y-auto py-4">
            <nav className="flex flex-col">
              <MobileNavItem title="Solutions" items={solutionsItems} setIsOpen={setIsOpen} />
              <MobileNavItem title="Industries" items={industriesItems} setIsOpen={setIsOpen} />
              <MobileNavLink href="/case-studies" setIsOpen={setIsOpen}>
                Case Studies
              </MobileNavLink>
              <MobileNavLink href="/insights" setIsOpen={setIsOpen}>
                Insights
              </MobileNavLink>
              <MobileNavLink href="/about" setIsOpen={setIsOpen}>
                About
              </MobileNavLink>
            </nav>
          </div>

          {/* Mobile CTA */}
          <div className="p-4 border-t border-white/10">
            <Button
              asChild
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white rounded-full shadow-lg"
            >
              <Link href="/contact" onClick={() => setIsOpen(false)}>
                <Phone className="mr-2 h-4 w-4" />
                Book a Call
              </Link>
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// Mobile Navigation Item with collapsible section
function MobileNavItem({
  title,
  items,
  setIsOpen,
}: {
  title: string;
  items: { title: string; href: string; description: string; icon: string }[];
  setIsOpen: (open: boolean) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border-b border-white/10">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center justify-between py-4 px-4 text-base font-semibold text-white hover:bg-white/5 transition-colors"
      >
        {title}
        <ChevronDown
          className={cn(
            "h-4 w-4 text-white/60 transition-transform duration-200",
            expanded && "rotate-180"
          )}
        />
      </button>
      {expanded && (
        <div className="pb-3 px-4 flex flex-col gap-1">
          {items.map((item) => (
            <Link
              key={item.title}
              href={item.href}
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 py-2 px-3 text-sm text-white/70 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
            >
              <span>{item.icon}</span>
              {item.title}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

// Mobile Navigation Link
function MobileNavLink({
  href,
  children,
  setIsOpen,
}: {
  href: string;
  children: React.ReactNode;
  setIsOpen: (open: boolean) => void;
}) {
  return (
    <Link
      href={href}
      onClick={() => setIsOpen(false)}
      className="py-4 px-4 text-base font-semibold text-white border-b border-white/10 hover:bg-white/5 transition-colors"
    >
      {children}
    </Link>
  );
}

// Simple fallback navigation for SSR (no Radix dependencies)
function FallbackNav() {
  return (
    <div className="hidden lg:flex items-center gap-1">
      <Link
        href="/solutions/smart-automation"
        className="inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 transition-all"
      >
        Solutions
      </Link>
      <Link
        href="/industries/real-estate-facilities"
        className="inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 transition-all"
      >
        Industries
      </Link>
      <Link
        href="/case-studies"
        className="inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 transition-all"
      >
        Case Studies
      </Link>
      <Link
        href="/insights"
        className="inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 transition-all"
      >
        Insights
      </Link>
      <Link
        href="/about"
        className="inline-flex h-9 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 transition-all"
      >
        About
      </Link>
    </div>
  );
}

// Mobile fallback button for SSR
function FallbackMobileButton() {
  return (
    <Button variant="ghost" size="icon" className="lg:hidden text-white">
      <Menu className="h-6 w-6" />
      <span className="sr-only">Toggle menu</span>
    </Button>
  );
}

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    
    // Set mounted state using queueMicrotask to avoid synchronous setState warning
    queueMicrotask(() => setMounted(true));
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
        isScrolled
          ? "bg-[#0a0a1a]/95 backdrop-blur-xl border-b border-white/10 shadow-lg shadow-black/20"
          : "bg-[#0a0a1a]/80 backdrop-blur-md border-b border-white/5"
      )}
    >
      <div className="container mx-auto px-4 lg:px-8">
        <nav className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="relative">
              <Image
                src="/images/logo.png"
                alt="Elyon Smart Solutions"
                width={140}
                height={40}
                className="h-8 w-auto lg:h-10 brightness-0 invert group-hover:opacity-90 transition-opacity"
                priority
              />
            </div>
          </Link>

          {/* Desktop Navigation - Show fallback during SSR, full nav after mount */}
          {mounted ? <DesktopNav /> : <FallbackNav />}

          {/* CTA Button - Desktop */}
          <div className="hidden lg:block">
            <Button
              asChild
              className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white rounded-full px-6 shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105"
            >
              <Link href="/contact">
                <Phone className="mr-2 h-4 w-4" />
                Book a Call
              </Link>
            </Button>
          </div>

          {/* Mobile Navigation - Show fallback during SSR, full nav after mount */}
          {mounted ? (
            <MobileNav isOpen={isOpen} setIsOpen={setIsOpen} />
          ) : (
            <FallbackMobileButton />
          )}
        </nav>
      </div>
    </header>
  );
}
