import Link from "next/link";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Zap,
  Target,
  TrendingUp,
  Shield,
  Clock,
  Users,
  Lightbulb,
  MessageSquare,
  Cog,
  Activity,
  BarChart3,
  Building2,
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
  Phone,
  Mail,
  MessageCircle,
  Star,
} from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { solutions, getSolutionBySlug } from "@/lib/content/solutions";
import { getIndustryBySlug } from "@/lib/content/industries";
import { caseStudies } from "@/lib/content/case-studies";

// Icon mappings defined at module level to avoid creating components during render
const solutionIcons: Record<string, typeof Cog> = {
  Cog,
  Activity,
  BarChart3,
  Zap,
  Shield,
  Building2,
};

const industryIcons: Record<string, typeof Building> = {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
};

interface SolutionPageProps {
  params: Promise<{ slug: string }>;
}

// Generate static params for all solutions
export async function generateStaticParams() {
  return solutions.map((solution) => ({
    slug: solution.slug,
  }));
}

// Generate metadata for SEO
export async function generateMetadata({ params }: SolutionPageProps): Promise<Metadata> {
  const { slug } = await params;
  const solution = getSolutionBySlug(slug);

  if (!solution) {
    return {
      title: "Solution Not Found | Elyon Smart Solutions",
    };
  }

  return {
    title: `${solution.title} | Elyon Smart Solutions`,
    description: solution.description,
    keywords: [
      solution.title,
      ...solution.features,
      "smart solutions",
      "operational efficiency",
      "Elyon",
    ],
  };
}

// Extended solution data with additional details
const solutionDetails: Record<string, {
  whoItsFor: string[];
  painPoints: string[];
  howItWorks: { step: number; title: string; description: string }[];
  processSteps: string[];
  faqs: { question: string; answer: string }[];
  relatedIndustries: string[];
}> = {
  "smart-automation": {
    whoItsFor: [
      "Operations managers seeking to streamline workflows",
      "Organizations with repetitive manual processes",
      "Companies looking to reduce operational costs",
      "Teams struggling with compliance and audit requirements",
    ],
    painPoints: [
      "Manual processes consuming valuable employee time",
      "Inconsistent execution of standard procedures",
      "Difficulty tracking and reporting on process status",
      "High error rates in repetitive tasks",
      "Compliance gaps due to human oversight",
    ],
    howItWorks: [
      { step: 1, title: "Discovery", description: "We analyze your existing workflows and identify automation opportunities" },
      { step: 2, title: "Design", description: "Our team designs custom automation workflows tailored to your needs" },
      { step: 3, title: "Deploy", description: "We implement and integrate automation with your existing systems" },
      { step: 4, title: "Optimize", description: "Continuous monitoring and refinement for maximum efficiency" },
    ],
    processSteps: [
      "Map existing workflows and identify bottlenecks",
      "Design rule-based triggers and automated actions",
      "Integrate with ERP, CRM, and other business systems",
      "Deploy with testing and validation phases",
      "Monitor performance and optimize continuously",
    ],
    faqs: [
      { question: "How long does it take to implement smart automation?", answer: "Typical implementations range from 4-12 weeks depending on complexity. Simple workflow automations can be deployed in as little as 2 weeks, while enterprise-wide process automation may take 3-6 months." },
      { question: "Will automation replace our employees?", answer: "Our goal is to augment your workforce, not replace it. Automation handles repetitive tasks, freeing your team to focus on strategic, creative work that adds more value to your organization." },
      { question: "Can you integrate with our existing systems?", answer: "Yes, we have experience integrating with major ERP, CRM, and business applications including SAP, Salesforce, Microsoft Dynamics, and custom systems via APIs." },
    ],
    relatedIndustries: ["logistics-warehousing", "manufacturing", "healthcare"],
  },
  "iot-monitoring": {
    whoItsFor: [
      "Facility managers overseeing multiple locations",
      "Manufacturing plants with critical equipment",
      "Data centers requiring 24/7 monitoring",
      "Organizations with distributed assets",
    ],
    painPoints: [
      "Unplanned equipment failures causing costly downtime",
      "Reactive maintenance instead of proactive prevention",
      "Limited visibility into remote or distributed assets",
      "Difficulty predicting maintenance needs",
      "High maintenance costs from emergency repairs",
    ],
    howItWorks: [
      { step: 1, title: "Assess", description: "Evaluate equipment and identify monitoring requirements" },
      { step: 2, title: "Connect", description: "Deploy IoT sensors and establish data connectivity" },
      { step: 3, title: "Monitor", description: "Real-time dashboards and alert systems go live" },
      { step: 4, title: "Predict", description: "AI algorithms predict maintenance needs" },
    ],
    processSteps: [
      "Install IoT sensors on critical equipment",
      "Configure data collection and transmission",
      "Set up real-time monitoring dashboards",
      "Establish alert thresholds and notifications",
      "Enable predictive maintenance algorithms",
    ],
    faqs: [
      { question: "What types of equipment can be monitored?", answer: "We can monitor virtually any equipment with sensors for temperature, vibration, pressure, humidity, power consumption, and more. Common applications include HVAC systems, manufacturing equipment, generators, and IT infrastructure." },
      { question: "How accurate are predictive maintenance predictions?", answer: "Our AI-powered predictive maintenance typically achieves 85-95% accuracy in predicting equipment failures, allowing maintenance teams to address issues before they cause downtime." },
      { question: "Do we need to replace our existing equipment?", answer: "No, our IoT solutions are designed to retrofit existing equipment. We use non-invasive sensors and wireless connectivity that works with your current infrastructure." },
    ],
    relatedIndustries: ["manufacturing", "real-estate-facilities", "healthcare"],
  },
  "ai-dashboards": {
    whoItsFor: [
      "Executive teams needing real-time visibility",
      "Operations managers tracking KPIs",
      "Data-driven organizations seeking insights",
      "Companies consolidating multiple data sources",
    ],
    painPoints: [
      "Data scattered across multiple systems",
      "Manual reporting consuming hours each week",
      "Lack of real-time visibility into operations",
      "Difficulty identifying trends and anomalies",
      "Delayed decision-making due to data gaps",
    ],
    howItWorks: [
      { step: 1, title: "Connect", description: "Integrate data sources and establish data pipelines" },
      { step: 2, title: "Transform", description: "Clean, normalize, and structure data for analysis" },
      { step: 3, title: "Visualize", description: "Create intuitive dashboards with key metrics" },
      { step: 4, title: "Insight", description: "AI generates actionable recommendations" },
    ],
    processSteps: [
      "Identify key performance indicators and data sources",
      "Build data integration pipelines",
      "Design custom dashboard layouts",
      "Implement AI-powered analytics",
      "Deploy with role-based access controls",
    ],
    faqs: [
      { question: "What data sources can be integrated?", answer: "We integrate with databases (SQL, NoSQL), APIs, IoT platforms, ERP systems, CRM applications, spreadsheets, and virtually any system that can expose data. Our platform supports both real-time streaming and batch data processing." },
      { question: "How long does it take to build a dashboard?", answer: "Basic dashboards can be created in days. Comprehensive enterprise dashboards with AI analytics typically take 4-8 weeks including data integration, customization, and training." },
      { question: "Can dashboards be accessed on mobile devices?", answer: "Yes, all our dashboards are fully responsive and optimized for mobile, tablet, and desktop viewing. We also offer native mobile apps for iOS and Android." },
    ],
    relatedIndustries: ["retail", "manufacturing", "logistics-warehousing"],
  },
  "energy-optimization": {
    whoItsFor: [
      "Facility managers with high energy costs",
      "Organizations with sustainability goals",
      "Companies needing carbon footprint tracking",
      "Buildings seeking green certifications",
    ],
    painPoints: [
      "Rising energy costs impacting profitability",
      "Lack of visibility into energy consumption patterns",
      "Difficulty meeting sustainability targets",
      "Inefficient HVAC and lighting systems",
      "Complex energy procurement decisions",
    ],
    howItWorks: [
      { step: 1, title: "Audit", description: "Comprehensive energy audit and baseline establishment" },
      { step: 2, title: "Monitor", description: "Deploy smart meters and monitoring systems" },
      { step: 3, title: "Optimize", description: "Implement automated controls and optimization" },
      { step: 4, title: "Sustain", description: "Continuous monitoring and reporting for ongoing savings" },
    ],
    processSteps: [
      "Conduct comprehensive energy audit",
      "Install smart meters and monitoring sensors",
      "Analyze consumption patterns and identify savings",
      "Implement automated control systems",
      "Enable continuous optimization and reporting",
    ],
    faqs: [
      { question: "What kind of energy savings can we expect?", answer: "Most clients achieve 15-30% reduction in energy costs. The exact savings depend on current efficiency levels, building type, and operational patterns. We provide guaranteed savings projections before implementation." },
      { question: "Can you help with green building certifications?", answer: "Yes, our energy optimization solutions support LEED, BREEAM, and other green building certifications. We provide the monitoring, reporting, and documentation needed for certification applications." },
      { question: "Do you work with renewable energy systems?", answer: "Absolutely. We integrate with solar panels, wind turbines, and battery storage systems to optimize renewable energy usage and maximize return on green investments." },
    ],
    relatedIndustries: ["real-estate-facilities", "hospitality", "manufacturing"],
  },
  "security-surveillance": {
    whoItsFor: [
      "Security directors managing multiple sites",
      "Organizations requiring 24/7 monitoring",
      "Facilities with access control needs",
      "Companies with compliance requirements",
    ],
    painPoints: [
      "Siloed security systems that don't communicate",
      "Slow incident response times",
      "High costs for security personnel",
      "Difficulty investigating security incidents",
      "Compliance gaps in access management",
    ],
    howItWorks: [
      { step: 1, title: "Assess", description: "Security assessment and vulnerability analysis" },
      { step: 2, title: "Design", description: "Integrated security architecture design" },
      { step: 3, title: "Deploy", description: "Install and configure security systems" },
      { step: 4, title: "Protect", description: "24/7 monitoring and incident response" },
    ],
    processSteps: [
      "Conduct security needs assessment",
      "Design integrated security architecture",
      "Deploy cameras, sensors, and access control",
      "Implement AI-powered video analytics",
      "Enable centralized monitoring and response",
    ],
    faqs: [
      { question: "What video analytics capabilities do you offer?", answer: "Our AI-powered analytics include facial recognition, license plate recognition, intrusion detection, loitering detection, crowd detection, and custom behavior analytics. Alerts can be configured for specific events or anomalies." },
      { question: "Can you integrate with our existing cameras?", answer: "Yes, we support integration with most major camera brands including Hikvision, Dahua, Axis, Bosch, and many others. We can often leverage your existing infrastructure to reduce implementation costs." },
      { question: "How do you handle data privacy and compliance?", answer: "Our solutions comply with relevant data protection regulations. We offer on-premises, cloud, or hybrid deployment options, configurable data retention policies, and role-based access controls." },
    ],
    relatedIndustries: ["real-estate-facilities", "healthcare", "retail"],
  },
  "smart-building": {
    whoItsFor: [
      "Building owners and facility managers",
      "Property management companies",
      "Corporate campuses and office buildings",
      "Organizations seeking LEED certification",
    ],
    painPoints: [
      "Fragmented building systems that don't communicate",
      "High operational costs and energy waste",
      "Poor indoor air quality and occupant comfort",
      "Inefficient space utilization",
      "Difficulty meeting sustainability goals",
    ],
    howItWorks: [
      { step: 1, title: "Integrate", description: "Connect all building systems to a unified platform" },
      { step: 2, title: "Automate", description: "Implement intelligent automation and controls" },
      { step: 3, title: "Optimize", description: "AI-driven optimization for comfort and efficiency" },
      { step: 4, title: "Manage", description: "Centralized management with real-time insights" },
    ],
    processSteps: [
      "Assess existing building systems and infrastructure",
      "Design integrated building management architecture",
      "Connect HVAC, lighting, and other systems",
      "Implement occupancy-based automation",
      "Enable predictive maintenance and optimization",
    ],
    faqs: [
      { question: "What building systems can be integrated?", answer: "We integrate HVAC, lighting, access control, fire safety, elevators, energy management, parking systems, and more. Our platform supports BACnet, Modbus, KNX, and other industry protocols." },
      { question: "How does occupancy-based automation work?", answer: "Using sensors and AI, our system detects occupancy patterns and automatically adjusts HVAC, lighting, and other systems. Empty areas reduce energy consumption while occupied spaces maintain optimal comfort levels." },
      { question: "Can this work with our existing BMS?", answer: "Yes, we can integrate with and enhance existing Building Management Systems. Our platform adds AI-driven optimization, better analytics, and unified management capabilities to legacy systems." },
    ],
    relatedIndustries: ["real-estate-facilities", "hospitality", "healthcare"],
  },
};

export default async function SolutionDetailPage({ params }: SolutionPageProps) {
  const { slug } = await params;
  const solution = getSolutionBySlug(slug);

  if (!solution) {
    notFound();
  }

  const details = solutionDetails[solution.slug];
  const SolutionIcon = solutionIcons[solution.icon];

  // Get related industries
  const relatedIndustries = details?.relatedIndustries
    ?.map((indSlug) => getIndustryBySlug(indSlug))
    .filter(Boolean) || [];

  // Get related case studies (based on industry matching)
  const relatedCaseStudies = caseStudies.filter((study) => {
    const studyIndustry = study.industry.toLowerCase();
    return details?.relatedIndustries?.some((indSlug) => {
      const industry = getIndustryBySlug(indSlug);
      return industry?.title.toLowerCase().includes(studyIndustry) || 
             studyIndustry.includes(industry?.title.toLowerCase() || "");
    });
  }).slice(0, 2);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Breadcrumb */}
        <section className="relative py-4 border-b border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/" className="text-white/60 hover:text-white">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbLink href="/solutions" className="text-white/60 hover:text-white">
                    Solutions
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbPage className="text-white">{solution.title}</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        {/* Hero Section - Modern Dark */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                <Zap className="h-4 w-4 text-yellow-400" />
                <span className="text-sm font-medium text-white/90">Enterprise Solution</span>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/25">
                  {SolutionIcon && <SolutionIcon className="w-8 h-8 text-white" />}
                </div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">
                  {solution.title}
                </h1>
              </div>
              <p className="text-lg md:text-xl text-white/70 leading-relaxed mb-8 max-w-3xl">
                {solution.longDescription || solution.description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white rounded-full shadow-lg shadow-blue-500/25">
                  <Link href="/contact">
                    <Phone className="mr-2 w-4 h-4" />
                    Get Started
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10 rounded-full">
                  <Link href="/case-studies">View Case Studies</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Who It's For Section */}
        <section className="relative py-16 lg:py-20">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Users className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm font-semibold text-cyan-400 uppercase tracking-wide">
                    Who It&apos;s For
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">
                  Built for Organizations Like Yours
                </h2>
                <p className="text-white/60 mb-8">
                  Our {solution.title.toLowerCase()} solution is designed for organizations facing 
                  specific operational challenges. Here&apos;s who benefits most:
                </p>
                <ul className="space-y-4">
                  {details?.whoItsFor.map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
                      <span className="text-white/80">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-gradient-to-br from-blue-600/10 to-orange-500/10 rounded-2xl p-8 border border-white/10">
                <h4 className="text-lg font-semibold text-white mb-4">Key Outcomes</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {solution.benefits.slice(0, 4).map((benefit, index) => (
                    <div key={index} className="flex items-start gap-2 p-3 bg-white/5 rounded-xl">
                      <TrendingUp className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span className="text-sm text-white/70">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Problem/Pain Points Section */}
        <section className="relative py-16 lg:py-20">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Target className="w-5 h-5 text-orange-400" />
                <span className="text-sm font-semibold text-orange-400 uppercase tracking-wide">
                  The Challenge
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                Common Pain Points We Solve
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {details?.painPoints.map((point, index) => (
                <Card key={index} className="bg-white/5 border-white/10 hover:border-red-500/30 transition-colors">
                  <CardContent className="pt-6">
                    <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center mb-4">
                      <span className="text-red-400 font-bold">{index + 1}</span>
                    </div>
                    <p className="text-white/70">{point}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* What Elyon Delivers Section */}
        <section className="relative py-16 lg:py-20">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Zap className="w-5 h-5 text-green-400" />
                <span className="text-sm font-semibold text-green-400 uppercase tracking-wide">
                  The Solution
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                What Elyon Delivers
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {solution.features.map((feature, index) => (
                <Card key={index} className="bg-white/5 border-white/10 hover:border-cyan-500/30 transition-colors">
                  <CardContent className="pt-6">
                    <CheckCircle2 className="w-6 h-6 text-cyan-400 mb-3" />
                    <p className="font-medium text-white">{feature}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="relative py-16 lg:py-20">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-purple-400" />
                <span className="text-sm font-semibold text-purple-400 uppercase tracking-wide">
                  Implementation
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                How It Works
              </h2>
            </div>

            {/* Steps with connectors */}
            <div className="max-w-4xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
                {details?.howItWorks.map((step, index) => (
                  <div key={index} className="relative text-center">
                    <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-blue-500/25">
                      {step.step}
                    </div>
                    <h4 className="font-semibold text-white mb-2">{step.title}</h4>
                    <p className="text-sm text-white/60">{step.description}</p>
                    {index < details.howItWorks.length - 1 && (
                      <div className="hidden md:block absolute top-7 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-gradient-to-r from-cyan-500/50 to-transparent" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Process Steps */}
            <div className="max-w-3xl mx-auto mt-16">
              <h4 className="text-lg font-semibold text-white mb-6 text-center">Detailed Process</h4>
              <div className="space-y-4">
                {details?.processSteps.map((step, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/10">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center text-white font-semibold text-sm">
                      {index + 1}
                    </div>
                    <span className="text-white/80">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Key Features Grid */}
        <section className="relative py-16 lg:py-20">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Lightbulb className="w-5 h-5 text-yellow-400" />
                <span className="text-sm font-semibold text-yellow-400 uppercase tracking-wide">
                  Capabilities
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                Key Features & Benefits
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
              {/* Features Card */}
              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Shield className="w-5 h-5 text-cyan-400" />
                    Features
                  </CardTitle>
                  <CardDescription className="text-white/60">Core capabilities included in this solution</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {solution.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                        <span className="text-sm text-white/70">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Benefits Card */}
              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-orange-400" />
                    Benefits
                  </CardTitle>
                  <CardDescription className="text-white/60">Measurable outcomes you can expect</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {solution.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                        <span className="text-sm text-white/70">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Related Case Studies */}
        {relatedCaseStudies.length > 0 && (
          <section className="relative py-16 lg:py-20">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="max-w-3xl mx-auto text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                  <Star className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm font-medium text-white/90">Success Stories</span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-white">
                  Success Stories
                </h2>
                <p className="text-white/60 mt-2">
                  See how organizations have achieved results with our {solution.title.toLowerCase()} solution
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
                {relatedCaseStudies.map((study) => (
                  <Link key={study.slug} href={`/case-studies/${study.slug}`} className="group">
                    <Card className="h-full bg-white/5 border-white/10 hover:border-orange-500/50 transition-all duration-500">
                      <CardHeader>
                        <div className="flex items-center justify-between mb-2">
                          <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0">
                            {study.industry}
                          </Badge>
                          <span className="text-sm text-white/50">{study.timeline}</span>
                        </div>
                        <CardTitle className="text-lg text-white group-hover:text-orange-400 transition-colors">
                          {study.client}
                        </CardTitle>
                        <CardDescription className="text-white/60 line-clamp-2">{study.challenge}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          {study.results.slice(0, 2).map((result, index) => (
                            <div key={index} className="text-center p-3 bg-white/5 rounded-xl">
                              <div className="text-2xl font-bold text-green-400">{result.value}</div>
                              <div className="text-xs text-white/60">{result.metric}</div>
                            </div>
                          ))}
                        </div>
                        <div className="flex items-center text-orange-400 font-medium mt-4 group-hover:text-cyan-400 transition-colors">
                          Read Full Case Study
                          <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Related Industries */}
        {relatedIndustries.length > 0 && (
          <section className="relative py-16 lg:py-20">
            <div className="absolute inset-0 bg-[#0a0a1a]" />
            <div className="absolute inset-0 grid-pattern opacity-20" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="max-w-3xl mx-auto text-center mb-12">
                <h2 className="text-2xl md:text-3xl font-bold text-white">
                  Industries We Serve
                </h2>
                <p className="text-white/60 mt-2">
                  This solution delivers value across multiple industries
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
                {relatedIndustries.map((industry) => {
                  if (!industry) return null;
                  const IndustryIcon = industryIcons[industry.icon];
                  return (
                    <Link
                      key={industry.slug}
                      href={`/industries/${industry.slug}`}
                      className="flex items-center gap-3 px-6 py-4 bg-white/5 border border-white/10 rounded-xl hover:border-cyan-500/50 hover:bg-white/10 transition-all group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600/20 to-cyan-500/20 flex items-center justify-center group-hover:from-blue-600/40 group-hover:to-cyan-500/40 transition-all">
                        {IndustryIcon && <IndustryIcon className="w-5 h-5 text-cyan-400" />}
                      </div>
                      <span className="font-medium text-white group-hover:text-cyan-400 transition-colors">
                        {industry.title}
                      </span>
                      <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-cyan-400 transition-colors" />
                    </Link>
                  );
                })}
              </div>
            </div>
          </section>
        )}

        {/* FAQ Section */}
        <section className="relative py-16 lg:py-20">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-12">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <MessageSquare className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm font-semibold text-cyan-400 uppercase tracking-wide">
                    FAQs
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-white">
                  Frequently Asked Questions
                </h2>
              </div>

              <Accordion type="single" collapsible className="w-full space-y-4">
                {details?.faqs.map((faq, index) => (
                  <AccordionItem
                    key={index}
                    value={`item-${index}`}
                    className="bg-white/5 border border-white/10 rounded-2xl px-6 hover:bg-white/10 transition-colors"
                  >
                    <AccordionTrigger className="text-left font-semibold text-white hover:text-cyan-400 py-5 transition-colors">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-white/60 pb-5 leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">
                Ready to Implement {solution.title}?
              </h2>
              <p className="text-white/90 text-lg mb-10">
                Schedule a consultation with our solutions experts to discuss how {solution.title.toLowerCase()} 
                can transform your operations.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 w-4 h-4" />
                    Schedule Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <Link href="/solutions">Explore All Solutions</Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a
                  href="mailto:info@elyon.one"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a
                  href="tel:+914000000000"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
