import Link from "next/link";
import { Metadata } from "next";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { solutions, getIconComponent } from "@/lib/content/solutions";

export const metadata: Metadata = {
  title: "Smart Solutions for Modern Operations | Elyon Smart Solutions",
  description:
    "Discover Elyon's comprehensive smart solutions: IoT monitoring, AI dashboards, automation, energy optimization, security integration, and smart building management.",
  keywords: [
    "smart automation",
    "IoT monitoring",
    "AI dashboards",
    "energy optimization",
    "security surveillance",
    "smart building management",
    "operational efficiency",
  ],
};

export default function SolutionsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-elyon-navy via-elyon-blue/90 to-elyon-navy py-20 lg:py-28 overflow-hidden">
          {/* Background decorations */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-elyon-orange/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-elyon-blue/30 rounded-full blur-3xl" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge variant="secondary" className="mb-4 bg-elyon-orange/20 text-elyon-orange border-elyon-orange/30">
                Our Solutions
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                Smart Solutions for{" "}
                <span className="bg-gradient-to-r from-elyon-orange to-amber-400 bg-clip-text text-transparent">
                  Modern Operations
                </span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto leading-relaxed">
                Transform your operations with our comprehensive suite of intelligent solutions. 
                From IoT monitoring to AI-powered analytics, we help businesses achieve unprecedented 
                efficiency and visibility.
              </p>
            </div>
          </div>
        </section>

        {/* Solutions Grid */}
        <section className="py-16 lg:py-24 bg-background">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {solutions.map((solution) => {
                const IconComponent = getIconComponent(solution.icon);
                return (
                  <Card
                    key={solution.slug}
                    className="group relative overflow-hidden border-2 border-transparent hover:border-elyon-blue/30 transition-all duration-300 hover:shadow-xl hover:shadow-elyon-blue/5"
                  >
                    <CardHeader className="pb-4">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-elyon-blue to-elyon-navy flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          {IconComponent && (
                            <IconComponent className="w-7 h-7 text-white" />
                          )}
                        </div>
                        <Badge variant="outline" className="text-xs border-elyon-blue/30 text-elyon-blue">
                          Solution
                        </Badge>
                      </div>
                      <CardTitle className="text-xl font-bold text-elyon-navy group-hover:text-elyon-blue transition-colors">
                        {solution.title}
                      </CardTitle>
                      <CardDescription className="text-muted-foreground leading-relaxed">
                        {solution.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Key Outcomes */}
                      <div>
                        <p className="text-sm font-semibold text-elyon-navy mb-3">Key Outcomes:</p>
                        <ul className="space-y-2">
                          {solution.benefits.slice(0, 3).map((benefit, index) => (
                            <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <CheckCircle2 className="w-4 h-4 text-elyon-green shrink-0 mt-0.5" />
                              <span>{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Learn More Link */}
                      <Link
                        href={`/solutions/${solution.slug}`}
                        className="inline-flex items-center gap-2 text-elyon-blue font-medium hover:gap-3 transition-all group/link"
                      >
                        Learn More
                        <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                      </Link>
                    </CardContent>

                    {/* Decorative gradient */}
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-elyon-blue via-elyon-orange to-elyon-blue opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Why Choose Elyon Section */}
        <section className="py-16 lg:py-24 bg-secondary/50">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-elyon-navy mb-4">
                Why Choose Elyon Solutions?
              </h2>
              <p className="text-muted-foreground text-lg">
                Our solutions are designed to deliver measurable results with minimal disruption to your operations.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-elyon-blue/10 flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-elyon-blue" />
                </div>
                <h3 className="text-lg font-semibold text-elyon-navy mb-2">Proven Results</h3>
                <p className="text-muted-foreground">
                  100+ successful implementations with documented ROI and measurable business outcomes.
                </p>
              </div>
              <div className="text-center p-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-elyon-orange/10 flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-elyon-orange" />
                </div>
                <h3 className="text-lg font-semibold text-elyon-navy mb-2">Scalable Architecture</h3>
                <p className="text-muted-foreground">
                  Cloud-native solutions that grow with your business from single site to enterprise deployment.
                </p>
              </div>
              <div className="text-center p-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-elyon-green/10 flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-elyon-green" />
                </div>
                <h3 className="text-lg font-semibold text-elyon-navy mb-2">Expert Support</h3>
                <p className="text-muted-foreground">
                  Dedicated implementation teams and 24/7 support to ensure your success at every stage.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-20 bg-gradient-to-r from-elyon-blue to-elyon-navy">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Ready to Transform Your Operations?
              </h2>
              <p className="text-white/80 text-lg mb-8">
                Schedule a consultation with our solutions experts to discover how Elyon can help 
                you achieve operational excellence.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-elyon-orange hover:bg-elyon-orange/90 text-white"
                >
                  <Link href="/contact">
                    Book a Consultation
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  <Link href="/case-studies">View Case Studies</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
