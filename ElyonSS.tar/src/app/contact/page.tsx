"use client";

import { useState } from "react";
import Link from "next/link";
import {
  MapPin,
  Mail,
  Phone,
  Clock,
  CheckCircle2,
  ArrowRight,
  Loader2,
  MessageSquare,
  Calendar,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const industries = [
  "Real Estate & Facilities",
  "Retail",
  "Logistics & Warehousing",
  "Healthcare",
  "Manufacturing",
  "Hospitality",
  "Technology",
  "Finance",
  "Education",
  "Other",
];

const budgetRanges = [
  "Under ₹5 Lakhs",
  "₹5 - 15 Lakhs",
  "₹15 - 50 Lakhs",
  "₹50 Lakhs - 1 Crore",
  "Above ₹1 Crore",
  "Not sure yet",
];

const timelines = [
  "Immediate (within 1 month)",
  "Short-term (1-3 months)",
  "Medium-term (3-6 months)",
  "Long-term (6+ months)",
  "Just exploring",
];

const nextSteps = [
  {
    step: 1,
    title: "Initial Review",
    description: "Our team reviews your submission within 24 hours",
    timeframe: "24 hours",
    icon: MessageSquare,
  },
  {
    step: 2,
    title: "Discovery Call",
    description: "We schedule a call to understand your requirements in detail",
    timeframe: "2-3 days",
    icon: Phone,
  },
  {
    step: 3,
    title: "Solution Proposal",
    description: "Receive a tailored solution proposal with pricing",
    timeframe: "5-7 days",
    icon: Sparkles,
  },
  {
    step: 4,
    title: "Project Kickoff",
    description: "Begin implementation once you approve the proposal",
    timeframe: "As agreed",
    icon: Calendar,
  },
];

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    industry: "",
    message: "",
    budget: "",
    timeline: "",
    honeypot: "", // Spam protection
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formData.company.trim()) {
      newErrors.company = "Company name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    if (!formData.message.trim()) {
      newErrors.message = "Please tell us what you need";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Check honeypot for spam
    if (formData.honeypot) {
      console.log("Spam submission blocked");
      return;
    }

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        throw new Error("Failed to submit form");
      }
    } catch (error) {
      console.error("Form submission error:", error);
      setErrors({ submit: "Failed to submit form. Please try again." });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 pt-16 lg:pt-20">
        {/* Hero Section - Modern Dark */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-8">
                <Calendar className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium text-white/90">Book a Call</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
                Let&apos;s Start a{" "}
                <span className="gradient-text-vibrant">Conversation</span>
              </h1>
              <p className="text-lg lg:text-xl text-white/70 mb-10 max-w-3xl mx-auto">
                Ready to transform your operations? Get in touch with our team
                and discover how Elyon can help your business thrive with smart solutions.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Form & Info Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-30" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid lg:grid-cols-5 gap-8 max-w-7xl mx-auto">
              {/* Contact Form */}
              <div className="lg:col-span-3">
                {isSubmitted ? (
                  <Card className="border-2 border-green-500/30 bg-green-500/10 backdrop-blur-xl">
                    <CardContent className="p-8 text-center">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/25">
                        <CheckCircle2 className="h-10 w-10 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-white mb-3">
                        Thank You for Reaching Out!
                      </h2>
                      <p className="text-white/70 mb-8 max-w-md mx-auto">
                        We&apos;ve received your message and will get back to you
                        within 24 hours.
                      </p>
                      <Button
                        onClick={() => {
                          setIsSubmitted(false);
                          setFormData({
                            name: "",
                            company: "",
                            email: "",
                            phone: "",
                            industry: "",
                            message: "",
                            budget: "",
                            timeline: "",
                            honeypot: "",
                          });
                        }}
                        variant="outline"
                        className="border-white/20 text-white hover:bg-white/10"
                      >
                        Submit Another Inquiry
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="border-2 border-white/10 bg-white/5 backdrop-blur-xl">
                    <CardContent className="p-6 lg:p-8">
                      <h2 className="text-xl font-semibold text-white mb-6">
                        Send Us a Message
                      </h2>

                      <form onSubmit={handleSubmit} className="space-y-6">
                        {/* Honeypot field for spam protection */}
                        <input
                          type="text"
                          name="honeypot"
                          value={formData.honeypot}
                          onChange={handleChange}
                          className="hidden"
                          tabIndex={-1}
                          autoComplete="off"
                        />

                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="name" className="text-white/80">
                              Name <span className="text-orange-400">*</span>
                            </Label>
                            <Input
                              id="name"
                              name="name"
                              placeholder="Your name"
                              value={formData.name}
                              onChange={handleChange}
                              className={`bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-cyan-500/50 ${
                                errors.name ? "border-red-500" : ""
                              }`}
                            />
                            {errors.name && (
                              <p className="text-sm text-red-400">
                                {errors.name}
                              </p>
                            )}
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="company" className="text-white/80">
                              Company{" "}
                              <span className="text-orange-400">*</span>
                            </Label>
                            <Input
                              id="company"
                              name="company"
                              placeholder="Company name"
                              value={formData.company}
                              onChange={handleChange}
                              className={`bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-cyan-500/50 ${
                                errors.company ? "border-red-500" : ""
                              }`}
                            />
                            {errors.company && (
                              <p className="text-sm text-red-400">
                                {errors.company}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="email" className="text-white/80">
                              Email <span className="text-orange-400">*</span>
                            </Label>
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              placeholder="your@email.com"
                              value={formData.email}
                              onChange={handleChange}
                              className={`bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-cyan-500/50 ${
                                errors.email ? "border-red-500" : ""
                              }`}
                            />
                            {errors.email && (
                              <p className="text-sm text-red-400">
                                {errors.email}
                              </p>
                            )}
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="phone" className="text-white/80">
                              Phone
                            </Label>
                            <Input
                              id="phone"
                              name="phone"
                              type="tel"
                              placeholder="+91 XXXXX XXXXX"
                              value={formData.phone}
                              onChange={handleChange}
                              className="bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-cyan-500/50"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="industry" className="text-white/80">
                            Industry
                          </Label>
                          <Select
                            value={formData.industry}
                            onValueChange={(value) =>
                              handleSelectChange("industry", value)
                            }
                          >
                            <SelectTrigger
                              id="industry"
                              className="w-full bg-white/5 border-white/10 text-white data-[placeholder]:text-white/40 focus:border-cyan-500/50"
                            >
                              <SelectValue placeholder="Select your industry" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#1a1a2e] border-white/10">
                              {industries.map((industry) => (
                                <SelectItem
                                  key={industry}
                                  value={industry}
                                  className="text-white hover:bg-white/10 focus:bg-white/10"
                                >
                                  {industry}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="message" className="text-white/80">
                            What do you need?{" "}
                            <span className="text-orange-400">*</span>
                          </Label>
                          <Textarea
                            id="message"
                            name="message"
                            placeholder="Tell us about your project, challenges, or requirements..."
                            rows={5}
                            value={formData.message}
                            onChange={handleChange}
                            className={`bg-white/5 border-white/10 text-white placeholder:text-white/40 focus:border-cyan-500/50 resize-none ${
                              errors.message ? "border-red-500" : ""
                            }`}
                          />
                          {errors.message && (
                            <p className="text-sm text-red-400">
                              {errors.message}
                            </p>
                          )}
                        </div>

                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="budget" className="text-white/80">
                              Budget Range
                            </Label>
                            <Select
                              value={formData.budget}
                              onValueChange={(value) =>
                                handleSelectChange("budget", value)
                              }
                            >
                              <SelectTrigger
                                id="budget"
                                className="w-full bg-white/5 border-white/10 text-white data-[placeholder]:text-white/40 focus:border-cyan-500/50"
                              >
                                <SelectValue placeholder="Select budget" />
                              </SelectTrigger>
                              <SelectContent className="bg-[#1a1a2e] border-white/10">
                                {budgetRanges.map((budget) => (
                                  <SelectItem
                                    key={budget}
                                    value={budget}
                                    className="text-white hover:bg-white/10 focus:bg-white/10"
                                  >
                                    {budget}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="timeline" className="text-white/80">
                              Timeline
                            </Label>
                            <Select
                              value={formData.timeline}
                              onValueChange={(value) =>
                                handleSelectChange("timeline", value)
                              }
                            >
                              <SelectTrigger
                                id="timeline"
                                className="w-full bg-white/5 border-white/10 text-white data-[placeholder]:text-white/40 focus:border-cyan-500/50"
                              >
                                <SelectValue placeholder="Select timeline" />
                              </SelectTrigger>
                              <SelectContent className="bg-[#1a1a2e] border-white/10">
                                {timelines.map((timeline) => (
                                  <SelectItem
                                    key={timeline}
                                    value={timeline}
                                    className="text-white hover:bg-white/10 focus:bg-white/10"
                                  >
                                    {timeline}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {errors.submit && (
                          <p className="text-sm text-red-400">
                            {errors.submit}
                          </p>
                        )}

                        <Button
                          type="submit"
                          size="lg"
                          className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-semibold py-6 rounded-xl shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-[1.02]"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                              Sending...
                            </>
                          ) : (
                            <>
                              Send Message
                              <ArrowRight className="ml-2 h-5 w-5" />
                            </>
                          )}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Contact Information */}
              <div className="lg:col-span-2 space-y-6">
                {/* Direct Contact */}
                <Card className="border-2 border-white/10 bg-white/5 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-white mb-6">
                      Contact Information
                    </h3>

                    <div className="space-y-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/25">
                          <Mail className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-white">Email</p>
                          <a
                            href="mailto:info@elyon.one"
                            className="text-white/60 hover:text-cyan-400 transition-colors"
                          >
                            info@elyon.one
                          </a>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center shrink-0 shadow-lg shadow-orange-500/25">
                          <Phone className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-white">Phone</p>
                          <a
                            href="tel:+914000000000"
                            className="text-white/60 hover:text-orange-400 transition-colors"
                          >
                            +91 40 0000 0000
                          </a>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center shrink-0 shadow-lg shadow-green-500/25">
                          <MapPin className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-white">Address</p>
                          <address className="text-white/60 not-italic leading-relaxed">
                            3rd Floor, Door No 1-60/8/A &B, KNR Square,
                            Gachibowli, Kondapur, Hyderabad, Telangana - 500032
                          </address>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shrink-0 shadow-lg shadow-purple-500/25">
                          <Clock className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-white">Business Hours</p>
                          <p className="text-white/60">
                            Mon - Fri: 9:00 AM - 6:00 PM IST
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Map Placeholder */}
                <Card className="border-2 border-white/10 bg-white/5 backdrop-blur-xl overflow-hidden">
                  <div className="aspect-video bg-gradient-to-br from-blue-600/10 to-orange-500/10 flex items-center justify-center">
                    <div className="text-center p-6">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/25">
                        <MapPin className="h-8 w-8 text-white" />
                      </div>
                      <p className="text-white/60 text-sm">
                        Map integration coming soon
                      </p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* What Happens Next Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-30" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="text-center mb-12">
              <Badge className="px-4 py-2 bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 rounded-full mb-6">
                Next Steps
              </Badge>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4">
                What Happens Next?
              </h2>
              <p className="text-white/60 text-lg max-w-2xl mx-auto">
                Here&apos;s what to expect after you submit your inquiry.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {nextSteps.map((step, index) => {
                const IconComponent = step.icon;
                return (
                  <Card
                    key={index}
                    className="border-2 border-white/10 bg-white/5 backdrop-blur-xl hover:border-cyan-500/30 transition-all duration-300 group"
                  >
                    <CardContent className="p-6 text-center">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/25 group-hover:scale-110 transition-transform duration-300">
                        <IconComponent className="h-7 w-7 text-white" />
                      </div>
                      <div className="flex items-center justify-center gap-2 mb-3">
                        <span className="text-sm text-cyan-400 font-medium">
                          Step {step.step}
                        </span>
                        <span className="text-xs text-white/40 bg-white/5 px-2 py-1 rounded-full">
                          {step.timeframe}
                        </span>
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {step.title}
                      </h3>
                      <p className="text-white/60 text-sm">
                        {step.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                Prefer to Talk Directly?
              </h2>
              <p className="text-white/90 text-lg mb-10">
                Schedule a consultation call with our team and let&apos;s discuss your
                requirements in detail.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <a href="tel:+914000000000">
                    <Phone className="mr-2 h-5 w-5" />
                    Call Us Now
                  </a>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <a href="mailto:info@elyon.one">info@elyon.one</a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
