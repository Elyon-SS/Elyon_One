import { Metadata } from "next";
import Link from "next/link";
import {
  Lightbulb,
  Shield,
  Handshake,
  Award,
  Search,
  Palette,
  Rocket,
  Headphones,
  Users,
  Building2,
  Target,
  Zap,
  CheckCircle2,
  ArrowRight,
  Phone,
  Mail,
  MessageCircle,
  Star,
  Globe,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: "About Us | Elyon Smart Solutions",
  description:
    "Elyon Smart Solutions enables businesses through innovative IoT, AI, and automation technologies. Learn about our mission, values, and approach to digital transformation.",
  openGraph: {
    title: "About Us | Elyon Smart Solutions",
    description:
      "Elyon Smart Solutions enables businesses through innovative IoT, AI, and automation technologies.",
    type: "website",
  },
};

const coreValues = [
  {
    icon: Lightbulb,
    title: "Innovation",
    description:
      "We constantly push boundaries to deliver cutting-edge solutions that transform how businesses operate.",
    gradient: "from-orange-500 to-yellow-500",
  },
  {
    icon: Shield,
    title: "Reliability",
    description:
      "Trust is the foundation of every partnership. We deliver robust, secure solutions with 99.9% uptime.",
    gradient: "from-blue-600 to-cyan-500",
  },
  {
    icon: Handshake,
    title: "Partnership",
    description:
      "We don't just deliver solutions; we build lasting relationships through collaborative approaches.",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: Award,
    title: "Excellence",
    description:
      "Quality is non-negotiable. We maintain the highest standards in every aspect of our service delivery.",
    gradient: "from-purple-500 to-pink-500",
  },
];

const approachSteps = [
  {
    step: 1,
    icon: Search,
    title: "Discover",
    description:
      "We begin by understanding your business inside-out—challenges, goals, existing infrastructure, and opportunities for improvement.",
  },
  {
    step: 2,
    icon: Palette,
    title: "Design",
    description:
      "Our experts craft tailored solutions that align with your objectives, ensuring scalability, security, and seamless integration.",
  },
  {
    step: 3,
    icon: Rocket,
    title: "Deliver",
    description:
      "We implement solutions with precision, minimizing disruption to your operations while maximizing value from day one.",
  },
  {
    step: 4,
    icon: Headphones,
    title: "Support",
    description:
      "Our commitment doesn't end at deployment. We provide ongoing support, maintenance, and optimization to ensure long-term success.",
  },
];

const leadership = [
  {
    name: "Leadership Team",
    role: "Executive Leadership",
    description:
      "Our leadership brings decades of combined experience in technology, operations, and business strategy, guiding Elyon's vision and growth.",
    icon: Users,
  },
  {
    name: "Technical Experts",
    role: "Engineering & Innovation",
    description:
      "Our engineering team comprises specialists in IoT, AI/ML, cloud architecture, and cybersecurity, ensuring world-class technical solutions.",
    icon: Zap,
  },
  {
    name: "Client Success",
    role: "Customer Excellence",
    description:
      "Dedicated to ensuring every client achieves their desired outcomes, our client success team provides proactive support and guidance.",
    icon: Star,
  },
];

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Elyon Smart Solutions",
  description:
    "Enabling Businesses through Smart Solutions - IoT monitoring, AI-powered analytics, and intelligent automation.",
  url: "https://elyon.one",
  logo: "https://elyon.one/images/logo.png",
  address: {
    "@type": "PostalAddress",
    streetAddress: "3rd Floor, Door No 1-60/8/A &B, KNR Square, Gachibowli, Kondapur",
    addressLocality: "Hyderabad",
    addressRegion: "Telangana",
    postalCode: "500032",
    addressCountry: "IN",
  },
  contactPoint: {
    "@type": "ContactPoint",
    email: "info@elyon.one",
    contactType: "customer service",
  },
  sameAs: [
    "https://linkedin.com/company/elyon",
    "https://twitter.com/elyon",
  ],
};

export default function AboutPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pt-16 lg:pt-20">
          {/* Hero Section - Modern Dark */}
          <section className="relative py-20 lg:py-28 overflow-hidden">
            {/* Animated gradient background */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

            {/* Mesh gradient overlay */}
            <div className="absolute inset-0 opacity-60">
              <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
              <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
              <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
            </div>

            {/* Grid pattern */}
            <div className="absolute inset-0 grid-pattern opacity-40" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="max-w-4xl mx-auto text-center">
                {/* Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-8">
                  <Globe className="h-4 w-4 text-orange-400" />
                  <span className="text-sm font-medium text-white/90">About Elyon</span>
                </div>

                <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
                  Enabling Businesses Through{" "}
                  <span className="gradient-text-vibrant">Smart Solutions</span>
                </h1>
                <p className="text-lg lg:text-xl text-white/70 mb-10 max-w-3xl mx-auto">
                  At Elyon Smart Solutions, we believe technology should simplify, not complicate. 
                  Our mission is to empower organizations with intelligent IoT, AI, and automation 
                  solutions that drive efficiency, reduce costs, and unlock new possibilities.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    asChild
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 py-6 text-lg font-semibold rounded-full shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105"
                  >
                    <Link href="/contact">
                      Get in Touch
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-8 py-6 text-lg font-semibold rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-105"
                  >
                    <Link href="/solutions/smart-automation">
                      Explore Solutions
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* What Elyon Does Section */}
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-[#0a0a1a]" />
            <div className="absolute inset-0 grid-pattern opacity-20" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="max-w-5xl mx-auto">
                <div className="text-center mb-12">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                    <Zap className="h-4 w-4 text-yellow-400" />
                    <span className="text-sm font-medium text-white/90">What We Do</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                    Bridging Challenges & <span className="gradient-text">Possibilities</span>
                  </h2>
                  <p className="text-white/60 text-lg max-w-3xl mx-auto">
                    We bridge the gap between business challenges and technological possibilities, 
                    delivering measurable results through smart solutions.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    {
                      icon: Zap,
                      title: "Smart Automation",
                      description:
                        "Streamline operations with intelligent workflow automation that reduces manual effort and human error.",
                      gradient: "from-blue-600 to-cyan-500",
                    },
                    {
                      icon: Building2,
                      title: "IoT Monitoring",
                      description:
                        "Real-time visibility into your facilities, assets, and operations through connected sensor networks.",
                      gradient: "from-orange-500 to-yellow-500",
                    },
                    {
                      icon: Target,
                      title: "AI-Powered Analytics",
                      description:
                        "Transform raw data into actionable insights with machine learning and predictive analytics.",
                      gradient: "from-green-500 to-emerald-500",
                    },
                  ].map((item, index) => (
                    <Card
                      key={index}
                      className="bg-white/5 border-white/10 hover:border-cyan-500/30 transition-all duration-300 group"
                    >
                      <CardContent className="p-6">
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-r ${item.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                          <item.icon className="h-7 w-7 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-white/60 text-sm leading-relaxed">
                          {item.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Core Values Section */}
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                  <Award className="h-4 w-4 text-purple-400" />
                  <span className="text-sm font-medium text-white/90">Our Values</span>
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Core <span className="gradient-text">Values</span>
                </h2>
                <p className="text-white/60 text-lg max-w-2xl mx-auto">
                  The principles that guide every decision we make and every solution we deliver.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {coreValues.map((value, index) => (
                  <Card
                    key={index}
                    className="bg-white/5 border-white/10 hover:border-white/20 transition-all duration-300 group"
                  >
                    <CardContent className="p-6 text-center">
                      <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${value.gradient} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                        <value.icon className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-2">
                        {value.title}
                      </h3>
                      <p className="text-white/60 text-sm leading-relaxed">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Team/Leadership Section */}
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-[#0a0a1a]" />
            <div className="absolute inset-0 grid-pattern opacity-20" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                  <Users className="h-4 w-4 text-cyan-400" />
                  <span className="text-sm font-medium text-white/90">Our Team</span>
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Expert <span className="gradient-text">Team</span>
                </h2>
                <p className="text-white/60 text-lg max-w-2xl mx-auto">
                  A diverse team of experts united by a passion for technology and a commitment to client success.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
                {leadership.map((team, index) => (
                  <Card
                    key={index}
                    className="bg-white/5 border-white/10 hover:border-orange-500/30 transition-all duration-300 group"
                  >
                    <CardContent className="p-6">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-orange-500 to-yellow-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                        <team.icon className="h-7 w-7 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-1">{team.name}</h3>
                      <p className="text-orange-400 text-sm mb-3">{team.role}</p>
                      <p className="text-white/60 text-sm leading-relaxed">
                        {team.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Approach & Methodology Section */}
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                  <Rocket className="h-4 w-4 text-green-400" />
                  <span className="text-sm font-medium text-white/90">Our Process</span>
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Our <span className="gradient-text">Approach</span>
                </h2>
                <p className="text-white/60 text-lg max-w-2xl mx-auto">
                  A proven methodology that ensures successful outcomes for every project.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
                {approachSteps.map((step, index) => (
                  <div key={index} className="relative text-center">
                    {/* Connector line for desktop */}
                    {index < approachSteps.length - 1 && (
                      <div className="hidden lg:block absolute top-7 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-cyan-500/50 to-transparent" />
                    )}
                    
                    <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-blue-500/25">
                      {step.step}
                    </div>
                    <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-white/5 flex items-center justify-center">
                      <step.icon className="h-6 w-6 text-cyan-400" />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                    <p className="text-white/60 text-sm leading-relaxed">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Partners Section */}
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-[#0a0a1a]" />
            <div className="absolute inset-0 grid-pattern opacity-20" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                  <Building2 className="h-4 w-4 text-blue-400" />
                  <span className="text-sm font-medium text-white/90">Partners</span>
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Our <span className="gradient-text">Partners</span>
                </h2>
                <p className="text-white/60 text-lg max-w-2xl mx-auto">
                  We collaborate with leading technology providers to deliver best-in-class solutions.
                </p>
              </div>

              <Card className="bg-white/5 border-white/10 max-w-4xl mx-auto">
                <CardContent className="p-8 lg:p-12 text-center">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/25">
                    <Building2 className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">
                    Strategic Technology Partners
                  </h3>
                  <p className="text-white/60 mb-6 max-w-xl mx-auto">
                    We partner with global leaders in IoT, cloud computing, and AI to provide 
                    cutting-edge solutions for our clients.
                  </p>
                  <div className="flex flex-wrap justify-center gap-3">
                    {[
                      "Cloud Platforms",
                      "IoT Hardware",
                      "AI/ML Tools",
                      "Security Solutions",
                    ].map((partner, index) => (
                      <Badge
                        key={index}
                        className="bg-white/5 text-white/70 border-white/10 px-4 py-2 rounded-full"
                      >
                        {partner}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Why Choose Us Section */}
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
                <div>
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="text-sm font-medium text-white/90">Why Choose Us</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                    Why Businesses Choose <span className="gradient-text">Elyon</span>
                  </h2>
                  <p className="text-white/60 text-lg mb-8">
                    We combine deep technical expertise with a client-centric approach to deliver 
                    solutions that create lasting value.
                  </p>
                  <ul className="space-y-4">
                    {[
                      "30+ successful implementations across industries",
                      "End-to-end solution delivery from concept to support",
                      "Proven ROI with measurable business outcomes",
                      "24/7 support and proactive monitoring",
                      "Scalable solutions that grow with your business",
                    ].map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-green-400 shrink-0 mt-0.5" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-r from-blue-600/20 to-orange-500/20 rounded-3xl blur-2xl" />
                  <Card className="relative bg-white/5 border-white/10">
                    <CardContent className="p-8">
                      <div className="grid grid-cols-2 gap-6">
                        {[
                          { value: "30+", label: "Projects Delivered", color: "text-cyan-400" },
                          { value: "99.9%", label: "System Uptime", color: "text-green-400" },
                          { value: "40%", label: "Cost Reduction", color: "text-orange-400" },
                          { value: "24/7", label: "Support", color: "text-purple-400" },
                        ].map((stat, index) => (
                          <div key={index} className="text-center p-4 bg-white/5 rounded-xl">
                            <div className={`text-3xl font-bold ${stat.color} mb-1`}>
                              {stat.value}
                            </div>
                            <div className="text-sm text-white/60">
                              {stat.label}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="relative py-24 lg:py-32 overflow-hidden">
            {/* Animated gradient background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
            <div className="absolute inset-0 opacity-50">
              <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
            </div>

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="max-w-3xl mx-auto text-center">
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                  Ready to Transform Your Operations?
                </h2>
                <p className="text-white/90 text-lg mb-10">
                  Let&apos;s discuss how Elyon can help your organization achieve its goals 
                  through smart technology solutions.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                  <Button
                    asChild
                    size="lg"
                    className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                  >
                    <Link href="/contact">
                      <Phone className="mr-2 h-5 w-5" />
                      Schedule a Consultation
                    </Link>
                  </Button>
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                  >
                    <Link href="https://wa.me/914000000000" target="_blank">
                      <MessageCircle className="mr-2 h-5 w-5" />
                      WhatsApp Us
                    </Link>
                  </Button>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                  <a
                    href="mailto:info@elyon.one"
                    className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                  >
                    <Mail className="h-5 w-5" />
                    info@elyon.one
                  </a>
                  <a
                    href="tel:+914000000000"
                    className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                  >
                    <Phone className="h-5 w-5" />
                    +91 40 0000 0000
                  </a>
                </div>
              </div>
            </div>
          </section>
        </main>
        <Footer />
      </div>
    </>
  );
}
