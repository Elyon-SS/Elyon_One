import type { Metadata } from "next";
import { Inter, Manrope } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://elyon.one"),
  title: {
    default: "Elyon Smart Solutions | Smart Automation, IoT, AI & Systems Integration",
    template: "%s | Elyon Smart Solutions",
  },
  description: "Smart Solutions that reduce cost, improve visibility, and automate operations. Elyon delivers IoT monitoring, AI dashboards, smart automation, and systems integration for enterprises.",
  keywords: ["smart solutions", "IoT solutions", "AI automation", "smart automation", "energy optimization", "security integration", "smart building", "industrial automation", "Elyon"],
  authors: [{ name: "Elyon Smart Solutions" }],
  icons: {
    icon: "/favicon.png",
    apple: "/favicon.png",
  },
  openGraph: {
    title: "Elyon Smart Solutions | Smart Automation, IoT, AI & Systems Integration",
    description: "Smart Solutions that reduce cost, improve visibility, and automate operations.",
    url: "https://elyon.one",
    siteName: "Elyon Smart Solutions",
    type: "website",
    images: [{ url: "/images/og-image.png", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Elyon Smart Solutions",
    description: "Smart Solutions that reduce cost, improve visibility, and automate operations.",
    images: ["/images/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body className={`${inter.variable} ${manrope.variable} font-sans antialiased bg-[#0a0a1a] text-white min-h-screen`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
