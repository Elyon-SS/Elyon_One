import Link from "next/link";
import { Metadata } from "next";
import { ArrowRight, Calendar, Clock, User, Building2, Activity, Zap, Phone, Mail, BookOpen } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { insights, type Insight } from "@/lib/content/insights";

export const metadata: Metadata = {
  title: "Insights & Resources | Elyon Smart Solutions",
  description:
    "Expert perspectives on smart solutions, IoT, and digital transformation. Stay informed with our latest insights on building automation, energy optimization, and more.",
  keywords: [
    "smart solutions insights",
    "IoT blog",
    "digital transformation",
    "building automation",
    "energy optimization",
    "Industry 4.0",
    "Elyon blog",
  ],
};

// Icon mappings for insights
const insightIcons = {
  Building2,
  Activity,
  Zap,
};

// Calculate reading time from content
function calculateReadTime(content: string): string {
  const wordsPerMinute = 200;
  const words = content.split(/\s+/).length;
  const minutes = Math.ceil(words / wordsPerMinute);
  return `${minutes} min read`;
}

// Format date for display
function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// Insight Card Component
function InsightCard({ insight }: { insight: Insight }) {
  const IconComponent = insightIcons[insight.icon as keyof typeof insightIcons] || Building2;
  const readTime = calculateReadTime(insight.content);

  return (
    <Link href={`/insights/${insight.slug}`} className="group">
      <Card className="h-full flex flex-col bg-white/5 border-white/10 hover:border-orange-500/50 transition-all duration-500 overflow-hidden">
        {/* Featured Image Placeholder */}
        <div className="relative h-48 bg-gradient-to-br from-blue-600/20 to-orange-500/20 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-blue-500/25">
              <IconComponent className="w-10 h-10 text-white" />
            </div>
          </div>
          {/* Category Badge */}
          <div className="absolute top-4 left-4">
            <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0">
              {insight.category}
            </Badge>
          </div>
        </div>

        <CardHeader className="pb-2">
          <h3 className="text-lg font-bold text-white line-clamp-2 group-hover:text-orange-400 transition-colors">
            {insight.title}
          </h3>
        </CardHeader>

        <CardContent className="flex-1">
          <p className="text-white/60 text-sm line-clamp-3 mb-4">
            {insight.excerpt}
          </p>
          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {insight.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="text-xs px-2 py-1 bg-white/5 rounded-full text-white/50"
              >
                {tag}
              </span>
            ))}
          </div>
        </CardContent>

        <CardFooter className="pt-4 border-t border-white/10">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">{insight.author}</p>
                <div className="flex items-center gap-2 text-xs text-white/50">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(insight.date)}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs text-white/50">
              <Clock className="w-3 h-3" />
              <span>{readTime}</span>
            </div>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}

export default function InsightsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Hero Section - Modern Dark */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-8">
                <BookOpen className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium text-white/90">Knowledge Hub</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
                Insights & <span className="gradient-text-vibrant">Resources</span>
              </h1>
              <p className="text-lg lg:text-xl text-white/70 mb-10 max-w-3xl mx-auto">
                Expert perspectives on smart solutions, IoT, and digital transformation. 
                Stay informed with our latest thinking on building automation, energy optimization, 
                and industry best practices.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 py-6 text-lg font-semibold rounded-full shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105"
                >
                  <Link href="/contact">
                    Subscribe to Updates
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-8 py-6 text-lg font-semibold rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-105"
                >
                  <Link href="/solutions">Explore Solutions</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Category Filter Section */}
        <section className="relative py-8 border-b border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Badge className="px-4 py-2 cursor-pointer bg-gradient-to-r from-blue-600 to-cyan-500 text-white border-0 rounded-full">
                All Posts
              </Badge>
              <Badge variant="outline" className="px-4 py-2 cursor-pointer border-white/20 text-white/70 hover:border-cyan-500/50 hover:text-white hover:bg-white/10 transition-all rounded-full">
                Technology Trends
              </Badge>
              <Badge variant="outline" className="px-4 py-2 cursor-pointer border-white/20 text-white/70 hover:border-cyan-500/50 hover:text-white hover:bg-white/10 transition-all rounded-full">
                Industry 4.0
              </Badge>
              <Badge variant="outline" className="px-4 py-2 cursor-pointer border-white/20 text-white/70 hover:border-cyan-500/50 hover:text-white hover:bg-white/10 transition-all rounded-full">
                Energy Management
              </Badge>
            </div>
          </div>
        </section>

        {/* Insights Grid */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-30" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {insights.map((insight) => (
                <InsightCard key={insight.slug} insight={insight} />
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter CTA */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                Stay Ahead with Expert Insights
              </h2>
              <p className="text-white/90 text-lg mb-10">
                Get the latest articles on smart solutions, industry trends, and digital transformation 
                delivered directly to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">
                    Subscribe to Newsletter
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">Contact Us</Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a
                  href="mailto:info@elyon.one"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a
                  href="tel:+914000000000"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
