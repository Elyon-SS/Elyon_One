import Link from "next/link";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import {
  ArrowRight,
  ArrowLeft,
  Calendar,
  Clock,
  User,
  Building2,
  Activity,
  Zap,
  Share2,
  Linkedin,
  Twitter,
  Facebook,
  BookOpen,
  Target,
  CheckCircle2,
  Lightbulb,
  MessageSquare,
  Phone,
  Mail,
} from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { insights, getInsightBySlug, type Insight } from "@/lib/content/insights";

// Icon mappings for insights
const insightIcons: Record<string, typeof Building2> = {
  Building2,
  Activity,
  Zap,
};

interface InsightPageProps {
  params: Promise<{ slug: string }>;
}

// Generate static params for all insights
export async function generateStaticParams() {
  return insights.map((insight) => ({
    slug: insight.slug,
  }));
}

// Calculate reading time from content
function calculateReadTime(content: string): string {
  const wordsPerMinute = 200;
  const words = content.split(/\s+/).length;
  const minutes = Math.ceil(words / wordsPerMinute);
  return `${minutes} min read`;
}

// Format date for display
function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// Generate metadata for SEO
export async function generateMetadata({ params }: InsightPageProps): Promise<Metadata> {
  const { slug } = await params;
  const insight = getInsightBySlug(slug);

  if (!insight) {
    return {
      title: "Article Not Found | Elyon Smart Solutions",
    };
  }

  return {
    title: `${insight.title} | Elyon Smart Solutions`,
    description: insight.excerpt,
    keywords: [...insight.tags, "Elyon Smart Solutions", "smart solutions"],
    authors: [{ name: insight.author }],
    openGraph: {
      title: insight.title,
      description: insight.excerpt,
      type: "article",
      publishedTime: insight.date,
      authors: [insight.author],
      tags: insight.tags,
    },
  };
}

// Generate Article Schema for SEO
function generateArticleSchema(insight: Insight) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: insight.title,
    description: insight.excerpt,
    author: {
      "@type": "Person",
      name: insight.author,
    },
    datePublished: insight.date,
    dateModified: insight.date,
    publisher: {
      "@type": "Organization",
      name: "Elyon Smart Solutions",
      logo: {
        "@type": "ImageObject",
        url: "https://elyon.one/images/logo.png",
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://elyon.one/insights/${insight.slug}`,
    },
    keywords: insight.tags.join(", "),
  };
}

// Parse markdown content to HTML-like sections
function parseContent(content: string) {
  const lines = content.split("\n");
  const sections: { type: string; content: string; items?: string[] }[] = [];
  let currentList: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line.startsWith("# ")) {
      if (currentList.length > 0) {
        sections.push({ type: "list", content: "", items: [...currentList] });
        currentList = [];
      }
      sections.push({ type: "h1", content: line.replace("# ", "") });
    } else if (line.startsWith("## ")) {
      if (currentList.length > 0) {
        sections.push({ type: "list", content: "", items: [...currentList] });
        currentList = [];
      }
      sections.push({ type: "h2", content: line.replace("## ", "") });
    } else if (line.startsWith("### ")) {
      if (currentList.length > 0) {
        sections.push({ type: "list", content: "", items: [...currentList] });
        currentList = [];
      }
      sections.push({ type: "h3", content: line.replace("### ", "") });
    } else if (line.startsWith("- ") || line.startsWith("* ")) {
      currentList.push(line.replace(/^[-*] /, ""));
    } else if (line.match(/^\d+\./)) {
      currentList.push(line.replace(/^\d+\.\s*/, ""));
    } else if (line.startsWith("```")) {
      continue;
    } else if (line.length > 0 && !line.startsWith("|")) {
      if (currentList.length > 0) {
        sections.push({ type: "list", content: "", items: [...currentList] });
        currentList = [];
      }
      const processedLine = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
      sections.push({ type: "paragraph", content: processedLine });
    }
  }

  if (currentList.length > 0) {
    sections.push({ type: "list", content: "", items: currentList });
  }

  return sections;
}

// Render content sections
function RenderContent({ content }: { content: string }) {
  const sections = parseContent(content);

  return (
    <div className="prose prose-lg max-w-none">
      {sections.map((section, index) => {
        switch (section.type) {
          case "h1":
            return (
              <h1 key={index} className="text-3xl font-bold text-white mt-8 mb-4 first:mt-0">
                {section.content}
              </h1>
            );
          case "h2":
            return (
              <h2 key={index} className="text-2xl font-semibold text-white mt-8 mb-4">
                {section.content}
              </h2>
            );
          case "h3":
            return (
              <h3 key={index} className="text-xl font-semibold text-white mt-6 mb-3">
                {section.content}
              </h3>
            );
          case "paragraph":
            return (
              <p
                key={index}
                className="text-white/70 leading-relaxed mb-4"
                dangerouslySetInnerHTML={{ __html: section.content }}
              />
            );
          case "list":
            return (
              <ul key={index} className="space-y-2 mb-4">
                {section.items?.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-white/70">
                    <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
                    <span dangerouslySetInnerHTML={{ __html: item }} />
                  </li>
                ))}
              </ul>
            );
          default:
            return null;
        }
      })}
    </div>
  );
}

// TL;DR Component
function TldrSection({ insight }: { insight: Insight }) {
  return (
    <Card className="bg-gradient-to-br from-blue-600/10 to-orange-500/10 border-blue-500/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <BookOpen className="w-5 h-5 text-cyan-400" />
          TL;DR
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-white/70">{insight.excerpt}</p>
        <div className="flex flex-wrap gap-2 mt-4">
          {insight.features.slice(0, 4).map((feature) => (
            <Badge key={feature} className="bg-cyan-500/20 text-cyan-400 border-0">
              {feature}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// FAQ Section
function FaqSection({ insights: insight }: { insights: Insight }) {
  const faqs = [
    {
      question: `What are the key takeaways from this article?`,
      answer: insight.benefits.join(", "),
    },
    {
      question: `What topics are covered in "${insight.title}"?`,
      answer: `This article covers: ${insight.features.slice(0, 3).join(", ")}, and more.`,
    },
    {
      question: "How can I apply these insights to my organization?",
      answer: `Contact our team at Elyon Smart Solutions for a personalized consultation on implementing ${insight.tags[0].toLowerCase()} solutions for your business.`,
    },
  ];

  return (
    <section className="relative py-16">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

      <div className="max-w-3xl mx-auto px-4 lg:px-8 relative z-10">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-2">
            <MessageSquare className="w-5 h-5 text-cyan-400" />
            <span className="text-sm font-semibold text-cyan-400 uppercase tracking-wide">
              Quick Answers
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white">Frequently Asked Questions</h2>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="bg-white/5 border border-white/10 rounded-2xl px-6 hover:bg-white/10 transition-colors"
            >
              <AccordionTrigger className="text-left font-semibold text-white hover:text-cyan-400 py-5 transition-colors">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-white/60 pb-5 leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

// Author Bio Card
function AuthorBioCard({ author }: { author: string }) {
  const initials = author
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2);

  return (
    <Card className="bg-white/5 border-white/10">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <Avatar className="w-16 h-16">
            <AvatarFallback className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-lg font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h4 className="font-semibold text-white text-lg">{author}</h4>
            <p className="text-sm text-white/60 mb-2">Expert Contributor</p>
            <p className="text-sm text-white/60">
              A thought leader in smart solutions and digital transformation, bringing years of 
              expertise in IoT, automation, and operational efficiency to help organizations thrive.
            </p>
            <div className="flex gap-3 mt-3">
              <a href="#" className="text-white/50 hover:text-cyan-400 transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#" className="text-white/50 hover:text-cyan-400 transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Related Posts
function RelatedPosts({ currentSlug }: { currentSlug: string }) {
  const relatedPosts = insights.filter((i) => i.slug !== currentSlug).slice(0, 2);

  return (
    <section className="relative py-16">
      <div className="absolute inset-0 bg-[#0a0a1a]" />
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="max-w-4xl mx-auto px-4 lg:px-8 relative z-10">
        <div className="flex items-center gap-2 mb-8">
          <Lightbulb className="w-5 h-5 text-orange-400" />
          <span className="text-sm font-semibold text-orange-400 uppercase tracking-wide">
            Continue Reading
          </span>
        </div>
        <h3 className="text-2xl font-bold text-white mb-6">Related Articles</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {relatedPosts.map((post) => {
            const IconComponent = insightIcons[post.icon] || Building2;
            return (
              <Link key={post.slug} href={`/insights/${post.slug}`}>
                <Card className="h-full bg-white/5 border-white/10 hover:border-orange-500/50 transition-all group cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center">
                        <IconComponent className="w-5 h-5 text-white" />
                      </div>
                      <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0">
                        {post.category}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg text-white group-hover:text-orange-400 transition-colors line-clamp-2">
                      {post.title}
                    </CardTitle>
                    <CardDescription className="text-white/60 line-clamp-2">
                      {post.excerpt}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 text-sm text-white/50">
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {post.author}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {calculateReadTime(post.content)}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// Social Share Buttons
function SocialShare({ title, slug }: { title: string; slug: string }) {
  const url = `https://elyon.one/insights/${slug}`;
  const encodedTitle = encodeURIComponent(title);
  const encodedUrl = encodeURIComponent(url);

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-white/60 flex items-center gap-1">
        <Share2 className="w-4 h-4" />
        Share:
      </span>
      <a
        href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedTitle}`}
        target="_blank"
        rel="noopener noreferrer"
        className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-cyan-500 hover:text-white transition-colors"
      >
        <Linkedin className="w-4 h-4" />
      </a>
      <a
        href={`https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-cyan-500 hover:text-white transition-colors"
      >
        <Twitter className="w-4 h-4" />
      </a>
      <a
        href={`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-cyan-500 hover:text-white transition-colors"
      >
        <Facebook className="w-4 h-4" />
      </a>
    </div>
  );
}

export default async function InsightDetailPage({ params }: InsightPageProps) {
  const { slug } = await params;
  const insight = getInsightBySlug(slug);

  if (!insight) {
    notFound();
  }

  const IconComponent = insightIcons[insight.icon] || Building2;
  const readTime = calculateReadTime(insight.content);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Breadcrumb */}
        <section className="relative py-4 border-b border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/" className="text-white/60 hover:text-white">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbLink href="/insights" className="text-white/60 hover:text-white">
                    Insights
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbPage className="text-white line-clamp-1">{insight.title}</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        {/* Hero Section - Modern Dark */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto">
              {/* Category Badge */}
              <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 mb-4">
                {insight.category}
              </Badge>

              {/* Title */}
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
                {insight.title}
              </h1>

              {/* Meta Info */}
              <div className="flex flex-wrap items-center gap-6 text-white/80 mb-6">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-sm font-medium">
                      {insight.author.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-white font-medium">{insight.author}</p>
                    <p className="text-sm text-white/60">Expert Contributor</p>
                  </div>
                </div>
                <Separator orientation="vertical" className="h-8 bg-white/20" />
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span className="text-white/70">{formatDate(insight.date)}</span>
                </div>
                <Separator orientation="vertical" className="h-8 bg-white/20" />
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span className="text-white/70">{readTime}</span>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-8">
                {insight.tags.map((tag) => (
                  <Badge key={tag} className="bg-white/10 text-white/70 border-0">
                    {tag}
                  </Badge>
                ))}
              </div>

              {/* Social Share */}
              <SocialShare title={insight.title} slug={insight.slug} />
            </div>
          </div>
        </section>

        {/* Featured Image */}
        <section className="relative py-8">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto">
              <div className="relative h-64 md:h-80 lg:h-96 bg-gradient-to-br from-blue-600/20 to-orange-500/20 rounded-2xl overflow-hidden border border-white/10">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-32 h-32 rounded-3xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/25">
                    <IconComponent className="w-16 h-16 text-white" />
                  </div>
                </div>
                {/* Decorative elements */}
                <div className="absolute top-4 right-4 w-24 h-24 bg-orange-500/30 rounded-full blur-xl" />
                <div className="absolute bottom-4 left-4 w-32 h-32 bg-blue-600/30 rounded-full blur-xl" />
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="relative py-8">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto">
              {/* TL;DR */}
              <TldrSection insight={insight} />

              {/* Article Content */}
              <article className="mt-12">
                <RenderContent content={insight.content} />
              </article>

              {/* Tags */}
              <div className="mt-12 pt-8 border-t border-white/10">
                <h4 className="text-sm font-semibold text-white/60 mb-4">Topics Covered</h4>
                <div className="flex flex-wrap gap-2">
                  {insight.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="border-white/20 text-white/70 hover:border-cyan-500/50 hover:text-cyan-400 transition-colors cursor-pointer">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <FaqSection insights={insight} />

        {/* Author Bio */}
        <section className="relative py-12">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="max-w-4xl mx-auto px-4 lg:px-8 relative z-10">
            <div className="flex items-center gap-2 mb-6">
              <User className="w-5 h-5 text-cyan-400" />
              <span className="text-sm font-semibold text-cyan-400 uppercase tracking-wide">
                About the Author
              </span>
            </div>
            <AuthorBioCard author={insight.author} />
          </div>
        </section>

        {/* Related Posts */}
        <RelatedPosts currentSlug={insight.slug} />

        {/* CTA Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                <Target className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium text-white/90">Take Action</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">
                Ready to Transform Your Operations?
              </h2>
              <p className="text-white/90 text-lg mb-10">
                Let&apos;s discuss how Elyon Smart Solutions can help you implement 
                the strategies and technologies covered in this article.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 w-5 h-5" />
                    Schedule Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <Link href="/solutions">Explore Solutions</Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a
                  href="mailto:info@elyon.one"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a
                  href="tel:+914000000000"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Back to Insights */}
        <section className="relative py-8 border-t border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <Link
              href="/insights"
              className="inline-flex items-center gap-2 text-cyan-400 hover:text-orange-400 transition-colors font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Insights
            </Link>
          </div>
        </section>
      </main>

      <Footer />

      {/* Article Schema Script */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(generateArticleSchema(insight)) }}
      />
    </div>
  );
}
