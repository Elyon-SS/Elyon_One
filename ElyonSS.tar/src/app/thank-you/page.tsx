import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2, ArrowRight, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: "Thank You",
  description: "Thank you for contacting Elyon Smart Solutions. We'll be in touch soon.",
  robots: {
    index: false,
    follow: true,
  },
};

export default function ThankYouPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 flex items-center justify-center py-20 px-4">
        <div className="max-w-2xl mx-auto text-center">
          {/* Success Icon */}
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-elyon-blue/10 mb-6">
              <CheckCircle2 className="w-12 h-12 text-elyon-blue" />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Thank You for <span className="gradient-text">Reaching Out!</span>
          </h1>

          {/* Description */}
          <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
            We&apos;ve received your message and appreciate your interest in Elyon Smart Solutions. 
            Our team will review your inquiry and get back to you within 24-48 business hours.
          </p>

          {/* What's Next Card */}
          <div className="bg-card border border-border rounded-2xl p-8 mb-8 text-left">
            <h2 className="text-xl font-semibold mb-4">What Happens Next?</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-elyon-blue/10 text-elyon-blue font-semibold text-sm shrink-0">
                  1
                </div>
                <div>
                  <h3 className="font-medium">Review</h3>
                  <p className="text-sm text-muted-foreground">
                    Our team reviews your inquiry to understand your specific needs and requirements.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-elyon-blue/10 text-elyon-blue font-semibold text-sm shrink-0">
                  2
                </div>
                <div>
                  <h3 className="font-medium">Connect</h3>
                  <p className="text-sm text-muted-foreground">
                    We&apos;ll reach out via email or phone to discuss your project and schedule a consultation.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-elyon-blue/10 text-elyon-blue font-semibold text-sm shrink-0">
                  3
                </div>
                <div>
                  <h3 className="font-medium">Propose</h3>
                  <p className="text-sm text-muted-foreground">
                    Based on our discussion, we&apos;ll prepare a tailored proposal for your smart solutions needs.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Immediate Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <Button asChild className="bg-elyon-blue hover:bg-elyon-blue/90 text-white">
              <Link href="/">
                Return Home
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/solutions">
                Explore Solutions
              </Link>
            </Button>
          </div>

          {/* Direct Contact */}
          <div className="pt-8 border-t border-border">
            <p className="text-sm text-muted-foreground mb-4">
              Need immediate assistance? Reach out directly:
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <a
                href="mailto:info@elyon.one"
                className="flex items-center gap-2 text-elyon-blue hover:text-elyon-blue/80 transition-colors"
              >
                <Mail className="h-4 w-4" />
                info@elyon.one
              </a>
              <a
                href="tel:+914000000000"
                className="flex items-center gap-2 text-elyon-blue hover:text-elyon-blue/80 transition-colors"
              >
                <Phone className="h-4 w-4" />
                +91 40 0000 0000
              </a>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
