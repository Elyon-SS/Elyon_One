import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import {
  Building2,
  ShoppingBag,
  Factory,
  Phone,
  ArrowRight,
  CheckCircle,
  Calendar,
  Users,
  TrendingUp,
  Mail,
  MessageCircle,
  Sparkles,
  Star,
} from "lucide-react";
import { caseStudies } from "@/lib/content/case-studies";

// Icon mapping for case studies
const caseStudyIcons: Record<string, typeof Building2> = {
  Building2,
  ShoppingBag,
  Factory,
};

// Extract unique industries for filter buttons
const industries = [...new Set(caseStudies.map((study) => study.industry))];

export const metadata = {
  title: "Case Studies | Elyon Smart Solutions",
  description:
    "Explore our success stories and see how we've helped organizations transform their operations with smart automation, IoT monitoring, and AI-powered solutions.",
  keywords: [
    "case studies",
    "success stories",
    "smart building",
    "retail analytics",
    "manufacturing automation",
    "IoT implementation",
    "operational excellence",
  ],
};

export default function CaseStudiesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Hero Section - Modern Dark */}
        <section className="relative overflow-hidden py-20 lg:py-28">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-8">
                <Star className="h-4 w-4 text-yellow-400" />
                <span className="text-sm font-medium text-white/90">Success Stories</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
                See How We&apos;ve Helped Organizations{" "}
                <span className="gradient-text-vibrant">Transform Their Operations</span>
              </h1>
              <p className="text-lg lg:text-xl text-white/70 mb-10 max-w-3xl mx-auto">
                Real results from real clients. Discover how Elyon Smart Solutions
                has helped businesses across industries achieve operational
                excellence and significant ROI.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 py-6 text-lg font-semibold rounded-full shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Book a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-8 py-6 text-lg font-semibold rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-105"
                >
                  <Link href="#case-studies">
                    View Case Studies
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Strip - Modern Glass Cards */}
        <section className="relative py-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-cyan-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative p-6 lg:p-8 rounded-2xl glass-dark border border-white/10 hover:border-white/20 transition-all duration-300 text-center">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center mx-auto mb-3">
                    <TrendingUp className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-2xl lg:text-3xl font-bold text-white mb-1">35%+</p>
                  <p className="text-sm text-white/60">Avg. Cost Reduction</p>
                </div>
              </div>
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-yellow-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative p-6 lg:p-8 rounded-2xl glass-dark border border-white/10 hover:border-white/20 transition-all duration-300 text-center">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-orange-500 to-yellow-500 flex items-center justify-center mx-auto mb-3">
                    <Calendar className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-2xl lg:text-3xl font-bold text-white mb-1">6-8</p>
                  <p className="text-sm text-white/60">Weeks Avg. Deployment</p>
                </div>
              </div>
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative p-6 lg:p-8 rounded-2xl glass-dark border border-white/10 hover:border-white/20 transition-all duration-300 text-center">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-3">
                    <CheckCircle className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-2xl lg:text-3xl font-bold text-white mb-1">100%</p>
                  <p className="text-sm text-white/60">Client Satisfaction</p>
                </div>
              </div>
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative p-6 lg:p-8 rounded-2xl glass-dark border border-white/10 hover:border-white/20 transition-all duration-300 text-center">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-3">
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-2xl lg:text-3xl font-bold text-white mb-1">30+</p>
                  <p className="text-sm text-white/60">Projects Delivered</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Filter Section */}
        <section className="relative py-8 border-b border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="flex flex-wrap items-center justify-center gap-3">
              <span className="text-sm text-white/60 mr-2">
                Filter by industry:
              </span>
              <Button
                variant="outline"
                size="sm"
                className="rounded-full border-white/20 text-white hover:bg-white/10 hover:border-cyan-500/50 bg-white/5"
              >
                All
              </Button>
              {industries.map((industry) => (
                <Button
                  key={industry}
                  variant="outline"
                  size="sm"
                  className="rounded-full border-white/20 text-white/70 hover:border-cyan-500/50 hover:text-white hover:bg-white/10"
                >
                  {industry}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Case Studies Grid */}
        <section id="case-studies" className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-30" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {caseStudies.map((study) => {
                const IconComponent = caseStudyIcons[study.icon] || Building2;
                return (
                  <Link key={study.slug} href={`/case-studies/${study.slug}`} className="group">
                    <Card className="h-full bg-white/5 border-white/10 hover:border-orange-500/50 transition-all duration-500 overflow-hidden">
                      <CardContent className="p-6 lg:p-8">
                        {/* Header with Icon and Industry Badge */}
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                            <IconComponent className="h-6 w-6 text-white" />
                          </div>
                          <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0">
                            {study.industry}
                          </Badge>
                        </div>

                        {/* Client Name */}
                        <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-400 transition-colors">
                          {study.client}
                        </h3>

                        {/* Challenge Summary */}
                        <p className="text-white/60 mb-5 line-clamp-3 text-sm leading-relaxed">
                          {study.challenge}
                        </p>

                        {/* Timeline */}
                        {study.timeline && (
                          <div className="flex items-center gap-2 text-xs text-white/50 mb-4">
                            <Calendar className="h-3.5 w-3.5" />
                            <span>{study.timeline} implementation</span>
                          </div>
                        )}

                        {/* Key Results Metrics */}
                        <div className="space-y-3 mb-5">
                          {study.results.slice(0, 3).map((result, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between p-3 rounded-xl bg-white/5"
                            >
                              <span className="text-xs text-white/60 line-clamp-1">
                                {result.metric}
                              </span>
                              <span className="text-sm font-bold text-green-400 shrink-0 ml-2">
                                {result.value}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* CTA Link */}
                        <div className="flex items-center text-orange-400 font-medium group-hover:text-cyan-400 transition-colors">
                          Read Full Case Study
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA Section - Vibrant Gradient */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                Ready to Write Your Success Story?
              </h2>
              <p className="text-lg text-white/90 mb-10 max-w-2xl mx-auto">
                Let us show you how Elyon Smart Solutions can transform your
                operations and deliver measurable results for your organization.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Schedule a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <Link href="https://wa.me/914000000000" target="_blank">
                    <MessageCircle className="mr-2 h-5 w-5" />
                    WhatsApp Us
                  </Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a
                  href="mailto:info@elyon.one"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a
                  href="tel:+914000000000"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
