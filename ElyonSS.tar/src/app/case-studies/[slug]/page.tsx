import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  Building2,
  ShoppingBag,
  Factory,
  Phone,
  ArrowRight,
  CheckCircle,
  Calendar,
  Users,
  TrendingUp,
  Mail,
  MessageCircle,
  Quote,
  Clock,
  Target,
  Settings,
  BarChart3,
  Zap,
  Star,
} from "lucide-react";
import {
  caseStudies,
  getCaseStudyBySlug,
  type CaseStudy,
} from "@/lib/content/case-studies";

// Icon mapping for case studies
const caseStudyIcons: Record<string, typeof Building2> = {
  Building2,
  ShoppingBag,
  Factory,
};

// Generate static params for all case studies
export function generateStaticParams() {
  return caseStudies.map((study) => ({
    slug: study.slug,
  }));
}

// Generate metadata for SEO
export function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  return params.then(({ slug }) => {
    const study = getCaseStudyBySlug(slug);
    if (!study) {
      return {
        title: "Case Study Not Found | Elyon Smart Solutions",
      };
    }
    return {
      title: `${study.title} | Case Study | Elyon Smart Solutions`,
      description: study.description,
      keywords: [
        study.industry.toLowerCase(),
        "case study",
        "smart solutions",
        "digital transformation",
        "operational excellence",
        ...study.technologies?.map((t) => t.toLowerCase()) || [],
      ],
    };
  });
}

// Generate Article Schema for SEO
function generateArticleSchema(study: CaseStudy) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: study.title,
    description: study.description,
    author: {
      "@type": "Organization",
      name: "Elyon Smart Solutions",
    },
    publisher: {
      "@type": "Organization",
      name: "Elyon Smart Solutions",
      logo: {
        "@type": "ImageObject",
        url: "https://elyon.one/images/logo.png",
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://elyon.one/case-studies/${study.slug}`,
    },
    about: {
      "@type": "Thing",
      name: study.industry,
    },
  };
}

interface CaseStudyPageProps {
  params: Promise<{ slug: string }>;
}

export default async function CaseStudyDetailPage({
  params,
}: CaseStudyPageProps) {
  const { slug } = await params;
  const study = getCaseStudyBySlug(slug);

  if (!study) {
    notFound();
  }

  // Get related case studies (excluding current one)
  const relatedCaseStudies = caseStudies
    .filter((s) => s.slug !== study.slug)
    .slice(0, 2);

  // Get the icon component
  const IconComponent = caseStudyIcons[study.icon] || Building2;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Breadcrumb */}
        <section className="relative py-4 border-b border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/" className="text-white/60 hover:text-white">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbLink href="/case-studies" className="text-white/60 hover:text-white">
                    Case Studies
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbPage className="text-white">{study.client}</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        {/* Hero Section - Modern Dark */}
        <section className="relative overflow-hidden py-16 lg:py-24">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto">
              {/* Header */}
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/25">
                  <IconComponent className="h-8 w-8 text-white" />
                </div>
                <div>
                  <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 mb-2">
                    {study.industry}
                  </Badge>
                  <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white">
                    {study.title}
                  </h1>
                </div>
              </div>

              {/* Client Info */}
              <p className="text-lg text-white/70 mb-8">
                {study.description}
              </p>

              {/* Summary Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="bg-white/5 border-white/10 backdrop-blur">
                  <CardContent className="p-4 text-center">
                    <Building2 className="h-5 w-5 text-cyan-400 mx-auto mb-2" />
                    <p className="text-xs text-white/50">Client</p>
                    <p className="font-semibold text-sm text-white">{study.client}</p>
                  </CardContent>
                </Card>
                <Card className="bg-white/5 border-white/10 backdrop-blur">
                  <CardContent className="p-4 text-center">
                    <Target className="h-5 w-5 text-orange-400 mx-auto mb-2" />
                    <p className="text-xs text-white/50">Industry</p>
                    <p className="font-semibold text-sm text-white">{study.industry}</p>
                  </CardContent>
                </Card>
                {study.timeline && (
                  <Card className="bg-white/5 border-white/10 backdrop-blur">
                    <CardContent className="p-4 text-center">
                      <Clock className="h-5 w-5 text-green-400 mx-auto mb-2" />
                      <p className="text-xs text-white/50">Timeline</p>
                      <p className="font-semibold text-sm text-white">{study.timeline}</p>
                    </CardContent>
                  </Card>
                )}
                <Card className="bg-white/5 border-white/10 backdrop-blur">
                  <CardContent className="p-4 text-center">
                    <TrendingUp className="h-5 w-5 text-purple-400 mx-auto mb-2" />
                    <p className="text-xs text-white/50">ROI</p>
                    <p className="font-semibold text-sm text-white">6-12 months</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="relative py-16 lg:py-24">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
              {/* Left Column - Main Content */}
              <div className="lg:col-span-2 space-y-12">
                {/* Challenge Section */}
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-orange-500 to-yellow-500 flex items-center justify-center">
                      <Target className="h-5 w-5 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-white">The Challenge</h2>
                  </div>
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <p className="text-white/70 leading-relaxed">
                        {study.challenge}
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Solution/Approach Section */}
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center">
                      <Zap className="h-5 w-5 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-white">Our Approach</h2>
                  </div>
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <p className="text-white/70 leading-relaxed mb-6">
                        {study.solution}
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Implementation Details */}
                {study.features && study.features.length > 0 && (
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center">
                        <Settings className="h-5 w-5 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-white">
                        Implementation Details
                      </h2>
                    </div>
                    <Card className="bg-white/5 border-white/10">
                      <CardContent className="p-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {study.features.map((feature, idx) => (
                            <div
                              key={idx}
                              className="flex items-start gap-3 p-3 rounded-xl bg-white/5"
                            >
                              <CheckCircle className="h-5 w-5 text-green-400 shrink-0 mt-0.5" />
                              <span className="text-sm text-white/80">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Results Section */}
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                      <BarChart3 className="h-5 w-5 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-white">Results & Impact</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {study.results.map((result, idx) => (
                      <Card
                        key={idx}
                        className="bg-gradient-to-br from-white/5 to-white/[0.02] border-white/10 border-l-4 border-l-green-500"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-white/60">
                              {result.metric}
                            </span>
                            <span className="text-2xl lg:text-3xl font-bold text-green-400">
                              {result.value}
                            </span>
                          </div>
                          <p className="text-sm text-white/50">
                            {result.description}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Testimonial */}
                {study.testimonial && (
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center">
                        <Quote className="h-5 w-5 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-white">Client Testimonial</h2>
                    </div>
                    <Card className="bg-gradient-to-br from-blue-600/10 to-orange-500/10 border-blue-500/20">
                      <CardContent className="p-6 lg:p-8">
                        <Quote className="h-8 w-8 text-cyan-400/30 mb-4" />
                        <blockquote className="text-lg lg:text-xl italic text-white/90 mb-6 leading-relaxed">
                          &ldquo;{study.testimonial.quote}&rdquo;
                        </blockquote>
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center">
                            <Users className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <p className="font-semibold text-white">
                              {study.testimonial.author}
                            </p>
                            <p className="text-sm text-white/60">
                              {study.testimonial.position}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>

              {/* Right Column - Sidebar */}
              <div className="lg:col-span-1 space-y-6">
                {/* Technologies Used */}
                {study.technologies && study.technologies.length > 0 && (
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                        <Settings className="h-5 w-5 text-cyan-400" />
                        Technologies Used
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {study.technologies.map((tech, idx) => (
                          <Badge
                            key={idx}
                            variant="outline"
                            className="border-cyan-500/30 text-cyan-400 bg-cyan-500/10"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Key Benefits */}
                {study.benefits && study.benefits.length > 0 && (
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-400" />
                        Key Benefits
                      </h3>
                      <ul className="space-y-3">
                        {study.benefits.map((benefit, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-400 shrink-0 mt-0.5" />
                            <span className="text-sm text-white/70">{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}

                {/* CTA Card */}
                <Card className="bg-gradient-to-br from-blue-600 to-purple-600 border-0">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-white mb-2">
                      Want Similar Results?
                    </h3>
                    <p className="text-sm text-white/80 mb-4">
                      Let us show you how we can transform your operations.
                    </p>
                    <Button
                      asChild
                      className="w-full bg-white text-blue-600 hover:bg-white/90 rounded-full"
                    >
                      <Link href="/contact">
                        <Phone className="mr-2 h-4 w-4" />
                        Get Started
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Related Case Studies */}
        {relatedCaseStudies.length > 0 && (
          <section className="relative py-16 lg:py-24">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />
            <div className="absolute inset-0 opacity-30">
              <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-orange-600/15 rounded-full blur-3xl" />
              <div className="absolute bottom-1/3 left-1/4 w-72 h-72 bg-green-600/15 rounded-full blur-3xl" />
            </div>

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-6">
                  <Star className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm font-medium text-white/90">More Success Stories</span>
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Related Case Studies
                </h2>
                <p className="text-white/60 max-w-2xl mx-auto">
                  Discover how we&apos;ve helped other organizations achieve
                  similar transformations
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                {relatedCaseStudies.map((relatedStudy) => {
                  const RelatedIcon =
                    caseStudyIcons[relatedStudy.icon] || Building2;
                  return (
                    <Link key={relatedStudy.slug} href={`/case-studies/${relatedStudy.slug}`} className="group">
                      <Card className="h-full bg-white/5 border-white/10 hover:border-orange-500/50 transition-all duration-500 overflow-hidden">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                              <RelatedIcon className="h-5 w-5 text-white" />
                            </div>
                            <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0">
                              {relatedStudy.industry}
                            </Badge>
                          </div>

                          <h3 className="text-lg font-bold text-white mb-2 group-hover:text-orange-400 transition-colors">
                            {relatedStudy.client}
                          </h3>

                          <p className="text-sm text-white/60 mb-4 line-clamp-2">
                            {relatedStudy.challenge}
                          </p>

                          <div className="space-y-2 mb-4">
                            {relatedStudy.results.slice(0, 2).map((result, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between p-3 rounded-xl bg-white/5"
                              >
                                <span className="text-xs text-white/60">
                                  {result.metric}
                                </span>
                                <span className="text-sm font-bold text-green-400">
                                  {result.value}
                                </span>
                              </div>
                            ))}
                          </div>

                          <div className="flex items-center text-orange-400 font-medium group-hover:text-cyan-400 transition-colors">
                            Read Full Case Study
                            <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>

              <div className="text-center mt-8">
                <Button asChild variant="outline" className="border-white/20 text-white hover:bg-white/10 hover:border-cyan-500/50 rounded-full">
                  <Link href="/case-studies">
                    View All Case Studies
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </section>
        )}

        {/* Final CTA Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                Ready to Achieve Similar Results?
              </h2>
              <p className="text-lg text-white/90 mb-10 max-w-2xl mx-auto">
                Schedule a free consultation with our experts to discuss how we
                can help transform your operations.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Schedule a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <Link href="https://wa.me/914000000000" target="_blank">
                    <MessageCircle className="mr-2 h-5 w-5" />
                    WhatsApp Us
                  </Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a
                  href="mailto:info@elyon.one"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a
                  href="tel:+914000000000"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Article Schema for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(generateArticleSchema(study)),
        }}
      />
    </div>
  );
}
