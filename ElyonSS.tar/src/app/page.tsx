import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import {
  Cog,
  Activity,
  BarChart3,
  Zap,
  Shield,
  Building2,
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
  Phone,
  ArrowRight,
  CheckCircle,
  Search,
  Lightbulb,
  Rocket,
  HeadphonesIcon,
  MessageCircle,
  Mail,
  TrendingUp,
  Sparkles,
  ChevronRight,
  Star,
  Users,
  Award,
  Zap as ZapIcon,
} from "lucide-react";
import { solutions } from "@/lib/content/solutions";
import { industries } from "@/lib/content/industries";
import { caseStudies } from "@/lib/content/case-studies";

// Icon mapping for solutions
const solutionIcons: Record<string, typeof Cog> = {
  Cog,
  Activity,
  BarChart3,
  Zap,
  Shield,
  Building2,
};

// Icon mapping for industries
const industryIcons: Record<string, typeof Building> = {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
};

// How it works steps
const howItWorksSteps = [
  {
    number: 1,
    title: "Discover",
    description: "We analyze your operations, identify pain points, and understand your unique business requirements.",
    icon: Search,
    color: "from-blue-500 to-cyan-500",
  },
  {
    number: 2,
    title: "Design",
    description: "Our experts design a customized solution architecture tailored to your specific needs and goals.",
    icon: Lightbulb,
    color: "from-orange-500 to-yellow-500",
  },
  {
    number: 3,
    title: "Deliver",
    description: "We implement the solution with minimal disruption to your operations, ensuring seamless integration.",
    icon: Rocket,
    color: "from-green-500 to-emerald-500",
  },
  {
    number: 4,
    title: "Support",
    description: "Our team provides ongoing support, maintenance, and optimization to maximize your ROI.",
    icon: HeadphonesIcon,
    color: "from-purple-500 to-pink-500",
  },
];

// FAQ data
const faqs = [
  {
    question: "What industries does Elyon Smart Solutions serve?",
    answer: "Elyon serves a wide range of industries including Real Estate & Facilities, Retail, Logistics & Warehousing, Healthcare, Manufacturing, and Hospitality. Our solutions are customizable to meet the unique needs of each sector.",
  },
  {
    question: "How long does a typical IoT implementation take?",
    answer: "Implementation timelines vary based on project scope and complexity. A typical IoT monitoring deployment takes 4-12 weeks, while comprehensive smart building solutions may take 3-6 months. We provide detailed timelines during the discovery phase.",
  },
  {
    question: "What is the ROI timeline for smart automation solutions?",
    answer: "Most clients see measurable ROI within 6-12 months of implementation. Energy optimization solutions typically show results within 3-6 months, while process automation can deliver immediate efficiency gains.",
  },
  {
    question: "Can Elyon solutions integrate with our existing systems?",
    answer: "Yes, our solutions are designed for seamless integration with existing enterprise systems including ERPs, BMS, SCADA, and other legacy systems. We use industry-standard protocols and APIs to ensure compatibility.",
  },
  {
    question: "What kind of support do you provide after implementation?",
    answer: "We provide comprehensive post-implementation support including 24/7 monitoring, proactive maintenance, regular system health checks, software updates, and a dedicated support team.",
  },
  {
    question: "How do you ensure data security in IoT deployments?",
    answer: "Security is paramount in all our solutions. We implement end-to-end encryption, secure device authentication, regular security audits, and comply with industry standards like ISO 27001.",
  },
];

// Metrics data
const metrics = [
  { value: "30+", label: "Projects Delivered", icon: TrendingUp },
  { value: "99.9%", label: "System Uptime", icon: Activity },
  { value: "40%", label: "Cost Reduction", icon: BarChart3 },
  { value: "24/7", label: "Support Coverage", icon: HeadphonesIcon },
];

// Stats for trust section
const trustStats = [
  { icon: Users, value: "15+", label: "Enterprise Clients" },
  { icon: Award, value: "6+", label: "Industries Served" },
  { icon: ZapIcon, value: "30+", label: "Projects Completed" },
  { icon: Star, value: "4.9", label: "Client Rating" },
];

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a1a]">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]">
          {/* Hero content */}
          <div className="container mx-auto px-4 lg:px-8 relative z-10 pt-32 pb-20">
            <div className="max-w-5xl mx-auto text-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 backdrop-blur-xl border border-white/10 mb-8">
                <Sparkles className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium text-white/90">
                  Transforming Operations with Smart Technology
                </span>
              </div>

              {/* Main headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 leading-tight">
                Smart Solutions that
                <br />
                <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-orange-400 bg-clip-text text-transparent">reduce cost</span>, improve
                <br />
                <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-orange-400 bg-clip-text text-transparent">visibility</span>, and automate
                <br />
                <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-orange-400 bg-clip-text text-transparent">operations</span>
              </h1>

              <p className="text-lg sm:text-xl lg:text-2xl text-white/70 mb-10 max-w-3xl mx-auto leading-relaxed">
                Elyon delivers{" "}
                <span className="text-cyan-400 font-medium">IoT monitoring</span>,{" "}
                <span className="text-orange-400 font-medium">AI-powered analytics</span>, and
                <span className="text-green-400 font-medium"> intelligent automation</span> to transform your operations
              </p>

              {/* CTA buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 py-6 text-lg font-semibold rounded-full shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Book a Call
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-8 py-6 text-lg font-semibold rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-105"
                >
                  <Link href="/solutions">
                    Explore Solutions
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>

              {/* Trust stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
                {trustStats.map((stat, index) => (
                  <div
                    key={index}
                    className="flex flex-col items-center p-4 rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10"
                  >
                    <stat.icon className="h-6 w-6 text-orange-400 mb-2" />
                    <div className="text-2xl font-bold text-white">{stat.value}</div>
                    <div className="text-sm text-white/60">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Metrics Strip */}
        <section className="relative py-16 bg-[#0a0a1a]">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {metrics.map((metric, index) => (
                <div key={index} className="p-6 lg:p-8 rounded-2xl bg-white/5 border border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center mb-3">
                    <metric.icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="text-3xl lg:text-4xl font-bold text-white mb-1">{metric.value}</div>
                  <div className="text-sm lg:text-base text-white/60">{metric.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Core Solutions Grid */}
        <section className="relative py-20 lg:py-28 bg-[#0a0a1a]">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 border border-white/10 mb-6">
                <Zap className="h-4 w-4 text-yellow-400" />
                <span className="text-sm font-medium text-white/90">Our Solutions</span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
                Comprehensive <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">Smart Solutions</span>
              </h2>
              <p className="text-lg text-white/60 max-w-2xl mx-auto">
                Transform your operations with our suite of intelligent solutions designed for modern enterprises
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {solutions.map((solution, index) => {
                const IconComponent = solutionIcons[solution.icon] || Cog;
                const gradients = [
                  "from-blue-600 to-cyan-500",
                  "from-orange-500 to-yellow-500",
                  "from-green-500 to-emerald-500",
                  "from-purple-600 to-pink-500",
                  "from-cyan-500 to-blue-600",
                  "from-orange-600 to-red-500",
                ];
                return (
                  <Link key={solution.slug} href={`/solutions/${solution.slug}`} className="group">
                    <Card className="h-full bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10 transition-all duration-500">
                      <CardContent className="p-6 lg:p-8">
                        <div className="flex items-start gap-4 mb-5">
                          <div className={`w-14 h-14 rounded-2xl bg-gradient-to-r ${gradients[index % gradients.length]} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                            <IconComponent className="h-7 w-7 text-white" />
                          </div>
                          <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                            {solution.title}
                          </h3>
                        </div>

                        <p className="text-white/60 mb-5 line-clamp-2 leading-relaxed">
                          {solution.description}
                        </p>

                        <div className="space-y-2.5 mb-5">
                          {solution.benefits.slice(0, 3).map((benefit, idx) => (
                            <div key={idx} className="flex items-start gap-2.5 text-sm">
                              <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0 mt-0.5" />
                              <span className="text-white/70">{benefit}</span>
                            </div>
                          ))}
                        </div>

                        <div className="flex items-center text-cyan-400 font-medium group-hover:text-orange-400 transition-colors">
                          Learn More
                          <ChevronRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>

            <div className="text-center mt-12">
              <Button asChild size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 rounded-full shadow-lg shadow-blue-500/25">
                <Link href="/solutions">
                  View All Solutions
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Industries Section */}
        <section className="relative py-20 lg:py-28 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 border border-white/10 mb-6">
                <Building className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium text-white/90">Industries We Serve</span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
                Tailored Solutions for <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">Every Industry</span>
              </h2>
              <p className="text-lg text-white/60 max-w-2xl mx-auto">
                We bring deep domain expertise to solve the unique challenges of each industry we serve
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {industries.map((industry) => {
                const IconComponent = industryIcons[industry.icon] || Building;
                return (
                  <Link key={industry.slug} href={`/industries/${industry.slug}`} className="group">
                    <Card className="h-full bg-white/5 border-white/10 hover:border-cyan-500/50 hover:bg-white/10 transition-all duration-300">
                      <CardContent className="p-5 text-center">
                        <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-r from-blue-600/20 to-cyan-500/20 flex items-center justify-center mb-4 group-hover:from-blue-600/40 group-hover:to-cyan-500/40 transition-all duration-300">
                          <IconComponent className="h-7 w-7 text-cyan-400 group-hover:scale-110 transition-transform" />
                        </div>
                        <h3 className="font-bold text-white text-sm lg:text-base group-hover:text-cyan-400 transition-colors">
                          {industry.title}
                        </h3>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        {/* How Elyon Works */}
        <section className="relative py-20 lg:py-28 bg-[#0a0a1a]">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 border border-white/10 mb-6">
                <Rocket className="h-4 w-4 text-green-400" />
                <span className="text-sm font-medium text-white/90">Our Process</span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
                How <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">Elyon Works</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {howItWorksSteps.map((step) => (
                <div key={step.number} className="group">
                  <Card className="h-full bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10 transition-all duration-300 relative">
                    <CardContent className="p-6 lg:p-8 text-center">
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                          {step.number}
                        </div>
                      </div>
                      <div className="pt-4">
                        <div className={`w-16 h-16 mx-auto rounded-2xl bg-gradient-to-r ${step.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                          <step.icon className="h-8 w-8 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                        <p className="text-white/60 text-sm leading-relaxed">{step.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Case Studies */}
        <section className="relative py-20 lg:py-28 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 border border-white/10 mb-6">
                <Star className="h-4 w-4 text-yellow-400" />
                <span className="text-sm font-medium text-white/90">Case Studies</span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
                Proven <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">Results</span> Across Industries
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {caseStudies.slice(0, 3).map((study) => (
                <Link key={study.slug} href={`/case-studies/${study.slug}`} className="group">
                  <Card className="h-full bg-white/5 border-white/10 hover:border-orange-500/50 transition-all duration-500">
                    <CardContent className="p-6 lg:p-8">
                      <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 mb-4">
                        {study.industry}
                      </Badge>
                      <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-400 transition-colors">
                        {study.client}
                      </h3>
                      <p className="text-white/60 mb-5 line-clamp-3 text-sm leading-relaxed">
                        {study.challenge}
                      </p>
                      <div className="space-y-3 mb-5">
                        {study.results.slice(0, 2).map((result, idx) => (
                          <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                            <span className="text-sm text-white/60">{result.metric}</span>
                            <span className="text-lg font-bold text-green-400">{result.value}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex items-center text-orange-400 font-medium group-hover:text-cyan-400 transition-colors">
                        Read Full Case Study
                        <ChevronRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="text-center mt-12">
              <Button asChild size="lg" variant="outline" className="border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-8 rounded-full">
                <Link href="/case-studies">
                  View All Case Studies
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="relative py-20 lg:py-28 bg-[#0a0a1a]">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 border border-white/10 mb-6">
                  <MessageCircle className="h-4 w-4 text-cyan-400" />
                  <span className="text-sm font-medium text-white/90">FAQs</span>
                </div>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
                  Frequently Asked <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">Questions</span>
                </h2>
              </div>

              <Accordion type="single" collapsible className="w-full space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem
                    key={index}
                    value={`item-${index}`}
                    className="bg-white/5 border border-white/10 rounded-2xl px-6 hover:bg-white/10 transition-colors"
                  >
                    <AccordionTrigger className="text-left font-semibold text-white hover:text-cyan-400 py-5 transition-colors">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-white/60 pb-5 leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="relative py-24 lg:py-32 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500">
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
                Ready to Transform Your Operations?
              </h2>
              <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto">
                Schedule a free consultation with our experts to discover how Elyon can help you achieve operational excellence
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300">
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Schedule a Consultation
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300">
                  <Link href="https://wa.me/914000000000" target="_blank">
                    <MessageCircle className="mr-2 h-5 w-5" />
                    WhatsApp Us
                  </Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a href="mailto:info@elyon.one" className="flex items-center gap-2 hover:text-white transition-colors font-medium">
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a href="tel:+914000000000" className="flex items-center gap-2 hover:text-white transition-colors font-medium">
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* FAQ Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqs.map((faq) => ({
              "@type": "Question",
              name: faq.question,
              acceptedAnswer: {
                "@type": "Answer",
                text: faq.answer,
              },
            })),
          }),
        }}
      />
    </div>
  );
}
