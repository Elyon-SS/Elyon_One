import { Metadata } from "next";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  FileText,
  CheckCircle,
  Briefcase,
  Lightbulb,
  AlertTriangle,
  Scale,
  RefreshCw,
  Mail,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Terms of Service | Elyon Smart Solutions",
  description:
    "Read the Terms of Service for Elyon Smart Solutions. Understand the terms and conditions governing your use of our website and services.",
  keywords: [
    "terms of service",
    "terms and conditions",
    "user agreement",
    "Elyon Smart Solutions",
    "legal terms",
  ],
};

const sections = [
  {
    id: "acceptance-of-terms",
    title: "Acceptance of Terms",
    icon: CheckCircle,
    content: `By accessing and using the Elyon Smart Solutions website (elyon.one) and our services, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our website or services.

These Terms of Service constitute a legally binding agreement between you and Elyon Smart Solutions regarding your use of our website, services, and content. We reserve the right to modify these terms at any time, and your continued use of our services following any changes indicates your acceptance of the new terms.

You represent and warrant that you have the legal capacity to enter into these Terms of Service. If you are using our services on behalf of an organization, you represent and warrant that you are authorized to bind that organization to these terms.`,
  },
  {
    id: "use-of-services",
    title: "Use of Services",
    icon: Briefcase,
    content: `You agree to use our website and services only for lawful purposes and in accordance with these Terms of Service. You agree not to use our services in any way that violates any applicable laws or regulations, or to engage in any conduct that restricts or inhibits anyone's use or enjoyment of the website.

You may not attempt to gain unauthorized access to any portion of our website or any systems or networks connected to it. You agree not to use any automated means, including robots, spiders, or scrapers, to access our website or collect any information without our prior written consent.

We reserve the right to terminate or suspend your access to our website and services at any time, without prior notice, for conduct that we believe violates these Terms of Service or is harmful to other users, us, or third parties, or for any other reason at our sole discretion.`,
  },
  {
    id: "intellectual-property",
    title: "Intellectual Property",
    icon: Lightbulb,
    content: `All content on this website, including but not limited to text, graphics, logos, images, software, and other materials, is the property of Elyon Smart Solutions or its content suppliers and is protected by intellectual property laws. This content may not be copied, reproduced, modified, distributed, or used for commercial purposes without our prior written consent.

The Elyon Smart Solutions name, logo, and all related names, logos, product and service names, designs, and slogans are trademarks of Elyon Smart Solutions. You may not use such marks without our prior written permission. All other trademarks, logos, and service marks displayed on our website are the property of their respective owners.

We respect the intellectual property rights of others. If you believe that any content on our website infringes upon your intellectual property rights, please contact us at info@elyon.one with a detailed description of the alleged infringement.`,
  },
  {
    id: "user-responsibilities",
    title: "User Responsibilities",
    icon: AlertTriangle,
    content: `As a user of our website and services, you are responsible for maintaining the confidentiality of any account credentials and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account or any other breach of security.

You are responsible for ensuring that any information you provide to us is accurate, current, and complete. You agree not to impersonate any person or entity, or to falsely state or misrepresent your affiliation with any person or entity.

You agree to indemnify and hold harmless Elyon Smart Solutions and its officers, directors, employees, agents, and affiliates from any claims, damages, losses, or expenses arising from your use of our services, your violation of these Terms of Service, or your violation of any rights of a third party.`,
  },
  {
    id: "limitation-of-liability",
    title: "Limitation of Liability",
    icon: Shield,
    content: `To the fullest extent permitted by applicable law, Elyon Smart Solutions shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to loss of profits, data, use, goodwill, or other intangible losses, resulting from your use or inability to use our services.

In no event shall our total aggregate liability to you for all claims exceed the amount you paid us, if any, for access to our services. Some jurisdictions do not allow the exclusion of certain warranties or the limitation of liability for consequential damages, so the above limitations may not apply to you.

We make no warranties or representations about the accuracy or completeness of the content on our website or the content of any sites linked to this site. We assume no liability for any errors or omissions in the content of this website or any other site.`,
  },
  {
    id: "governing-law",
    title: "Governing Law",
    icon: Scale,
    content: `These Terms of Service shall be governed by and construed in accordance with the laws of India, without regard to its conflict of law provisions. Any disputes arising under or in connection with these Terms of Service shall be subject to the exclusive jurisdiction of the courts located in Hyderabad, Telangana, India.

You agree that any cause of action arising out of or related to our services must commence within one (1) year after the cause of action accrues. Otherwise, such cause of action is permanently barred.

If any provision of these Terms of Service is found to be unenforceable or invalid, that provision shall be limited or eliminated to the minimum extent necessary so that these Terms of Service shall otherwise remain in full force and effect.`,
  },
  {
    id: "changes-to-terms",
    title: "Changes to Terms",
    icon: RefreshCw,
    content: `We reserve the right, at our sole discretion, to modify or replace these Terms of Service at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.

By continuing to access or use our services after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using our services.

We encourage you to review these Terms of Service periodically for any changes. Your continued use of our website and services following the posting of any changes to these Terms of Service constitutes acceptance of those changes.`,
  },
  {
    id: "contact-information",
    title: "Contact Information",
    icon: Mail,
    content: `If you have any questions, concerns, or feedback regarding these Terms of Service, please contact us using the information provided below:

Email: info@elyon.one
Website: www.elyon.one
Address: 3rd Floor, Door No 1-60/8/A &B, KNR Square, Gachibowli, Kondapur, Hyderabad, Telangana - 500032

We value your feedback and will make reasonable efforts to respond to your inquiries within a reasonable timeframe. For urgent legal matters, please clearly indicate the nature of your inquiry in your communication.`,
  },
];

// Custom Shield component for limitation of liability
function Shield({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}

export default function TermsOfServicePage() {
  const lastUpdated = "January 15, 2026";

  return (
    <>
      <Header />
      <main className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-white">
        {/* Hero Section */}
        <section className="relative pt-32 pb-16 lg:pt-40 lg:pb-20 overflow-hidden">
          {/* Background Decorations */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -left-40 w-80 h-80 bg-elyon-navy/5 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-elyon-blue/5 rounded-full blur-3xl" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge
                variant="outline"
                className="mb-6 border-elyon-navy/30 text-elyon-navy"
              >
                <FileText className="w-3 h-3 mr-1" />
                Legal Document
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-elyon-navy mb-4">
                Terms of Service
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                Last updated: {lastUpdated}
              </p>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Welcome to Elyon Smart Solutions. These Terms of Service govern
                your use of our website and services. Please read them carefully
                before using our platform.
              </p>
            </div>
          </div>
        </section>

        {/* Table of Contents */}
        <section className="py-8 lg:py-12">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <Card className="border-slate-200 bg-white/80 backdrop-blur-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-elyon-navy">
                    Table of Contents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <nav className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {sections.map((section, index) => (
                      <a
                        key={section.id}
                        href={`#${section.id}`}
                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-100 transition-colors group"
                      >
                        <span className="flex items-center justify-center w-7 h-7 rounded-full bg-elyon-navy/10 text-elyon-navy text-sm font-medium group-hover:bg-elyon-navy group-hover:text-white transition-colors">
                          {index + 1}
                        </span>
                        <span className="text-sm font-medium text-slate-700 group-hover:text-elyon-navy transition-colors">
                          {section.title}
                        </span>
                      </a>
                    ))}
                  </nav>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Terms Sections */}
        <section className="py-8 lg:py-12 flex-1">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-4xl mx-auto space-y-8">
              {sections.map((section, index) => (
                <Card
                  key={section.id}
                  id={section.id}
                  className="border-slate-200 bg-white/80 backdrop-blur-sm scroll-mt-24"
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-elyon-navy to-elyon-blue text-white">
                        <section.icon className="w-6 h-6" />
                      </div>
                      <CardTitle className="text-xl text-elyon-navy">
                        {section.title}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-slate-600 leading-relaxed space-y-4">
                      {section.content.split("\n\n").map((paragraph, pIndex) => (
                        <p key={pIndex}>{paragraph}</p>
                      ))}
                    </div>
                  </CardContent>
                  {index < sections.length - 1 && (
                    <Separator className="mt-4" />
                  )}
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Agreement Notice */}
        <section className="py-8 lg:py-12">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <Card className="border-elyon-navy/20 bg-elyon-navy/5">
                <CardContent className="p-6">
                  <p className="text-sm text-slate-600 leading-relaxed">
                    <strong className="text-elyon-navy">Agreement to Terms: </strong>
                    By using the Elyon Smart Solutions website and services, you
                    acknowledge that you have read this Terms of Service agreement
                    carefully and that you agree to be bound by all of its terms
                    and conditions. If you do not agree to these terms, please do
                    not use our website or services. We appreciate your trust and
                    look forward to serving your smart solutions needs.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
