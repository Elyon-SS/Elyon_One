import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
  Phone,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { industries } from "@/lib/content/industries";

// Icon mapping for industries
const industryIcons: Record<string, typeof Building> = {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
};

export const metadata = {
  title: "Industries We Serve | Elyon Smart Solutions",
  description:
    "Elyon delivers tailored smart solutions for Real Estate, Retail, Logistics, Healthcare, Manufacturing, and Hospitality industries. Discover how we transform operations.",
};

export default function IndustriesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-muted/30 py-16 lg:py-24">
          {/* Background decoration */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-elyon-blue/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-elyon-orange/10 rounded-full blur-3xl" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge
                variant="outline"
                className="mb-4 text-elyon-orange border-elyon-orange"
              >
                Industries
              </Badge>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-tight mb-6">
                Industries We <span className="gradient-text">Serve</span>
              </h1>
              <p className="text-lg lg:text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                We bring deep domain expertise to solve the unique challenges of
                each industry we serve. Discover how Elyon transforms operations
                across diverse sectors.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-elyon-blue hover:bg-elyon-blue/90 text-white px-8"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Book a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-elyon-orange text-elyon-orange hover:bg-elyon-orange/10 px-8"
                >
                  <Link href="/case-studies">
                    View Case Studies
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Industries Grid */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {industries.map((industry) => {
                const IconComponent = industryIcons[industry.icon] || Building;
                return (
                  <Link
                    key={industry.slug}
                    href={`/industries/${industry.slug}`}
                    className="group"
                  >
                    <Card className="h-full hover:shadow-lg transition-all duration-300 border-2 border-transparent hover:border-elyon-blue/30 overflow-hidden">
                      <CardContent className="p-6">
                        {/* Icon and Title */}
                        <div className="flex items-start gap-4 mb-4">
                          <div className="flex-shrink-0 w-14 h-14 rounded-xl gradient-blue-orange flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <IconComponent className="h-7 w-7 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold mb-1 group-hover:text-elyon-blue transition-colors">
                              {industry.title}
                            </h3>
                          </div>
                        </div>

                        {/* Description */}
                        <p className="text-muted-foreground mb-4 line-clamp-3">
                          {industry.description}
                        </p>

                        {/* Top 3 Outcomes */}
                        <div className="space-y-2 mb-4">
                          <p className="text-sm font-medium text-foreground">
                            Key Outcomes:
                          </p>
                          {industry.benefits.slice(0, 3).map((benefit, idx) => (
                            <div
                              key={idx}
                              className="flex items-start gap-2 text-sm"
                            >
                              <CheckCircle className="h-4 w-4 text-elyon-green flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">
                                {benefit}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Learn More Link */}
                        <div className="flex items-center text-elyon-blue font-medium text-sm group-hover:text-elyon-orange transition-colors">
                          Explore {industry.title}
                          <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="bg-elyon-navy py-12 lg:py-16">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-white mb-1">
                  6+
                </div>
                <div className="text-sm lg:text-base text-white/70">
                  Industries Served
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-white mb-1">
                  30+
                </div>
                <div className="text-sm lg:text-base text-white/70">
                  Projects Delivered
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-white mb-1">
                  40%
                </div>
                <div className="text-sm lg:text-base text-white/70">
                  Avg. Cost Reduction
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-white mb-1">
                  99.9%
                </div>
                <div className="text-sm lg:text-base text-white/70">
                  System Uptime
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-24 relative overflow-hidden">
          {/* Background */}
          <div className="absolute inset-0 gradient-blue-orange opacity-95" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                Don&apos;t See Your Industry Listed?
              </h2>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
                Our solutions are adaptable to various sectors. Contact us to
                discuss how we can customize our smart solutions for your unique
                industry requirements.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-elyon-blue hover:bg-white/90 px-8"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Schedule a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10 px-8"
                >
                  <Link href="/solutions">
                    Explore All Solutions
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
