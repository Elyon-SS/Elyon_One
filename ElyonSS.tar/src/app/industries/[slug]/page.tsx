import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
  Phone,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Settings,
  Building2,
  MessageCircle,
  Mail,
  Globe,
} from "lucide-react";
import {
  industries,
  getIndustryBySlug,
} from "@/lib/content/industries";
import { solutions, getSolutionBySlug } from "@/lib/content/solutions";
import { caseStudies } from "@/lib/content/case-studies";

// Icon mapping for industries
const industryIcons: Record<string, typeof Building> = {
  Building,
  ShoppingBag,
  Package,
  Heart,
  Factory,
  Hotel,
};

// Icon mapping for solutions
const solutionIcons: Record<string, typeof Settings> = {
  Cog: Settings,
  Activity: Settings,
  BarChart3: Settings,
  Zap: Settings,
  Shield: Settings,
  Building2: Building2,
};

// Generate static params for all industries
export function generateStaticParams() {
  return industries.map((industry) => ({
    slug: industry.slug,
  }));
}

// Generate metadata for SEO
export function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  return params.then(({ slug }) => {
    const industry = getIndustryBySlug(slug);
    if (!industry) {
      return {
        title: "Industry Not Found | Elyon Smart Solutions",
      };
    }
    return {
      title: `${industry.title} Solutions | Elyon Smart Solutions`,
      description: `${industry.description} Discover how Elyon's smart solutions transform ${industry.title.toLowerCase()} operations.`,
    };
  });
}

// FAQ data for industries
const industryFaqs = [
  {
    question: "How long does implementation typically take?",
    answer:
      "Implementation timelines vary based on project scope and complexity. A typical deployment takes 4-12 weeks, while comprehensive solutions may take 3-6 months. We provide detailed timelines during the discovery phase.",
  },
  {
    question: "What is the expected ROI timeline?",
    answer:
      "Most clients see measurable ROI within 6-12 months of implementation. Some solutions like energy optimization show results within 3-6 months, while process automation can deliver immediate efficiency gains.",
  },
  {
    question: "Can solutions integrate with our existing systems?",
    answer:
      "Yes, our solutions are designed for seamless integration with existing enterprise systems including ERPs, BMS, SCADA, and other legacy systems. We use industry-standard protocols and APIs.",
  },
  {
    question: "What kind of support do you provide?",
    answer:
      "We provide comprehensive support including 24/7 monitoring, proactive maintenance, regular system health checks, software updates, and a dedicated support team with guaranteed SLAs.",
  },
];

interface IndustryPageProps {
  params: Promise<{ slug: string }>;
}

export default async function IndustryPage({ params }: IndustryPageProps) {
  const { slug } = await params;
  const industry = getIndustryBySlug(slug);

  if (!industry) {
    notFound();
  }

  // Get related solutions
  const relatedSolutions = industry.solutions
    ? industry.solutions
        .map((solSlug) => getSolutionBySlug(solSlug))
        .filter(Boolean)
    : [];

  // Get related case studies for this industry
  const relatedCaseStudies = caseStudies.filter(
    (study) =>
      study.industry.toLowerCase().includes(industry.title.toLowerCase()) ||
      industry.title.toLowerCase().includes(study.industry.toLowerCase())
  );

  // Get the icon component
  const IconComponent = industryIcons[industry.icon] || Building;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16 lg:pt-20">
        {/* Breadcrumb */}
        <section className="relative py-4 border-b border-white/10">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/" className="text-white/60 hover:text-white">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbLink href="/industries" className="text-white/60 hover:text-white">
                    Industries
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-white/40" />
                <BreadcrumbItem>
                  <BreadcrumbPage className="text-white">{industry.title}</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        {/* Hero Section - Modern Dark */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0f1029] to-[#0a0a1a]" />

          {/* Mesh gradient overlay */}
          <div className="absolute inset-0 opacity-60">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-float" />
            <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl animate-float-slow" />
            <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl animate-float" />
          </div>

          {/* Grid pattern */}
          <div className="absolute inset-0 grid-pattern opacity-40" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark border border-white/10 mb-8">
                <Globe className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium text-white/90">{industry.title}</span>
              </div>

              {/* Icon */}
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 mb-8 shadow-lg shadow-blue-500/25">
                <IconComponent className="h-10 w-10 text-white" />
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
                {industry.title} <span className="gradient-text-vibrant">Solutions</span>
              </h1>
              <p className="text-lg lg:text-xl text-white/70 mb-10 max-w-3xl mx-auto">
                {industry.description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 py-6 text-lg font-semibold rounded-full shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Book a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-8 py-6 text-lg font-semibold rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-105"
                >
                  <Link href="#solutions">
                    View Solutions
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Key Benefits Strip */}
        <section className="relative py-12 lg:py-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-orange-500/20" />
          <div className="absolute inset-0 bg-[#0a0a1a]/80" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
              {industry.benefits.slice(0, 4).map((benefit, idx) => (
                <div key={idx} className="text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-orange-500 to-yellow-500 mb-3 shadow-lg shadow-orange-500/25">
                    <CheckCircle className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-sm lg:text-base text-white/90">
                    {benefit}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Common Challenges Section */}
        {industry.challenges && industry.challenges.length > 0 && (
          <section className="relative py-16 lg:py-24 overflow-hidden">
            <div className="absolute inset-0 bg-[#0a0a1a]" />
            <div className="absolute inset-0 grid-pattern opacity-20" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <Badge className="px-4 py-2 bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 rounded-full mb-6">
                  Challenges
                </Badge>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Common Challenges in <span className="gradient-text">{industry.title}</span>
                </h2>
                <p className="text-white/60 max-w-2xl mx-auto">
                  We understand the unique obstacles your industry faces and
                  have developed targeted solutions to address them
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                {industry.challenges.map((challenge, idx) => (
                  <Card
                    key={idx}
                    className="bg-white/5 border-l-4 border-l-orange-500 border-white/10 hover:border-orange-500/50 transition-all duration-300"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-r from-orange-500 to-yellow-500 flex items-center justify-center shadow-lg shadow-orange-500/25">
                          <AlertTriangle className="h-6 w-6 text-white" />
                        </div>
                        <p className="text-white/80 pt-2">{challenge}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Recommended Solutions Section */}
        <section id="solutions" className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="text-center mb-12">
              <Badge className="px-4 py-2 bg-gradient-to-r from-blue-600/20 to-cyan-500/20 text-cyan-400 border-0 rounded-full mb-6">
                Solutions
              </Badge>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                Recommended Solutions for <span className="gradient-text">{industry.title}</span>
              </h2>
              <p className="text-white/60 max-w-2xl mx-auto">
                Our tailored solutions address the specific needs of your
                industry
              </p>
            </div>

            {relatedSolutions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedSolutions.map((solution) => {
                  if (!solution) return null;
                  const SolIcon =
                    solutionIcons[solution.icon] || Settings;
                  return (
                    <Link
                      key={solution.slug}
                      href={`/solutions/${solution.slug}`}
                      className="group"
                    >
                      <Card className="h-full bg-white/5 border-white/10 hover:border-cyan-500/30 transition-all duration-300 overflow-hidden">
                        <CardContent className="p-6">
                          <div className="flex flex-col items-center text-center">
                            <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-blue-500/25">
                              <SolIcon className="h-7 w-7 text-white" />
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                              {solution.title}
                            </h3>
                            <p className="text-sm text-white/60 line-clamp-3 mb-4">
                              {solution.description}
                            </p>
                            <span className="text-cyan-400 text-sm font-medium group-hover:text-orange-400 transition-colors flex items-center">
                              Learn More
                              <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center">
                <p className="text-white/60 mb-4">
                  Contact us to learn about solutions tailored for your
                  industry
                </p>
                <Button asChild className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-full">
                  <Link href="/contact">Get in Touch</Link>
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* Typical Deployments/Features Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="text-center mb-12">
              <Badge className="px-4 py-2 bg-gradient-to-r from-green-600/20 to-emerald-500/20 text-green-400 border-0 rounded-full mb-6">
                Capabilities
              </Badge>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                Typical <span className="gradient-text">Deployments</span>
              </h2>
              <p className="text-white/60 max-w-2xl mx-auto">
                Our solutions are deployed across various scenarios in{" "}
                {industry.title.toLowerCase()} operations
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {industry.features.map((feature, idx) => (
                <Card key={idx} className="bg-white/5 border-white/10 hover:border-cyan-500/30 transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/25 group-hover:scale-110 transition-transform duration-300">
                        <Settings className="h-6 w-6 text-white" />
                      </div>
                      <div className="pt-2">
                        <h3 className="font-medium text-white">{feature}</h3>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Case Studies Section */}
        {relatedCaseStudies.length > 0 && (
          <section className="relative py-16 lg:py-24 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a1a] via-[#0d0d20] to-[#0a0a1a]" />

            <div className="container mx-auto px-4 lg:px-8 relative z-10">
              <div className="text-center mb-12">
                <Badge className="px-4 py-2 bg-gradient-to-r from-blue-600/20 to-cyan-500/20 text-cyan-400 border-0 rounded-full mb-6">
                  Case Studies
                </Badge>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Success Stories in <span className="gradient-text">{industry.title}</span>
                </h2>
                <p className="text-white/60 max-w-2xl mx-auto">
                  See how we&apos;ve helped organizations like yours transform
                  their operations
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                {relatedCaseStudies.map((study) => (
                  <Card
                    key={study.slug}
                    className="group overflow-hidden bg-white/5 border-white/10 hover:border-cyan-500/30 transition-all duration-300"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Badge className="bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 text-xs">
                          {study.industry}
                        </Badge>
                      </div>

                      <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                        {study.client}
                      </h3>

                      <p className="text-sm text-white/60 mb-4 line-clamp-3">
                        {study.challenge}
                      </p>

                      <div className="space-y-2 mb-4">
                        {study.results.slice(0, 2).map((result, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between bg-white/5 rounded-lg p-2"
                          >
                            <span className="text-xs text-white/50">
                              {result.metric}
                            </span>
                            <span className="text-sm font-bold text-green-400">
                              {result.value}
                            </span>
                          </div>
                        ))}
                      </div>

                      <Button
                        asChild
                        variant="link"
                        className="p-0 h-auto text-cyan-400 hover:text-orange-400"
                      >
                        <Link href={`/case-studies/${study.slug}`}>
                          Read Full Case Study
                          <ArrowRight className="ml-1 h-4 w-4" />
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* FAQ Section */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-[#0a0a1a]" />
          <div className="absolute inset-0 grid-pattern opacity-20" />

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-12">
                <Badge className="px-4 py-2 bg-gradient-to-r from-orange-600/20 to-yellow-500/20 text-orange-400 border-0 rounded-full mb-6">
                  FAQs
                </Badge>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
                  Frequently Asked <span className="gradient-text">Questions</span>
                </h2>
                <p className="text-white/60">
                  Common questions about our {industry.title.toLowerCase()}{" "}
                  solutions
                </p>
              </div>

              <Accordion type="single" collapsible className="w-full space-y-4">
                {industryFaqs.map((faq, index) => (
                  <AccordionItem
                    key={index}
                    value={`item-${index}`}
                    className="bg-white/5 border-white/10 rounded-xl px-6 data-[state=open]:bg-white/10 transition-all"
                  >
                    <AccordionTrigger className="text-left font-medium text-white hover:text-cyan-400 transition-colors">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-white/60">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500" />
          <div className="absolute inset-0 opacity-50">
            <div className="absolute top-0 left-0 w-full h-full animated-gradient-bg" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6">
                Transform Your {industry.title} Operations
              </h2>
              <p className="text-white/90 text-lg mb-10">
                Schedule a free consultation with our industry experts to
                discover how Elyon can help you achieve operational excellence
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
                <Button
                  asChild
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-white/90 px-10 py-7 text-lg font-bold rounded-full shadow-2xl hover:scale-105 transition-all duration-300"
                >
                  <Link href="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Schedule a Consultation
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 px-10 py-7 text-lg font-semibold rounded-full backdrop-blur-sm hover:scale-105 transition-all duration-300"
                >
                  <Link
                    href="https://wa.me/914000000000"
                    target="_blank"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    WhatsApp Us
                  </Link>
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/90">
                <a
                  href="mailto:info@elyon.one"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Mail className="h-5 w-5" />
                  info@elyon.one
                </a>
                <a
                  href="tel:+914000000000"
                  className="flex items-center gap-2 hover:text-white transition-colors font-medium"
                >
                  <Phone className="h-5 w-5" />
                  +91 40 0000 0000
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
