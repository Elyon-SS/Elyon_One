import { NextResponse } from "next/server";

/**
 * Health Check API Endpoint
 * Used by load balancers, monitoring tools, and container orchestrators
 * to verify the application is running correctly
 */

interface HealthCheckResponse {
  status: "healthy" | "unhealthy" | "degraded";
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  checks: {
    database: "ok" | "error" | "skipped";
    memory: {
      used: number;
      total: number;
      percentage: number;
    };
  };
}

export async function GET() {
  const startTime = Date.now();
  
  // Check database connection
  let databaseStatus: "ok" | "error" | "skipped" = "skipped";
  let dbError: string | null = null;
  
  try {
    // Dynamic import to avoid issues if Prisma isn't configured
    const { PrismaClient } = await import("@prisma/client");
    const prisma = new PrismaClient();
    await prisma.$queryRaw`SELECT 1`;
    await prisma.$disconnect();
    databaseStatus = "ok";
  } catch (error) {
    // Database connection failed
    databaseStatus = "error";
    dbError = error instanceof Error ? error.message : "Unknown database error";
  }

  // Memory usage check
  const memoryUsage = process.memoryUsage();
  const memoryCheck = {
    used: Math.round(memoryUsage.heapUsed / 1024 / 1024), // MB
    total: Math.round(memoryUsage.heapTotal / 1024 / 1024), // MB
    percentage: Math.round((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100),
  };

  // Determine overall status
  let status: "healthy" | "unhealthy" | "degraded" = "healthy";
  
  if (databaseStatus === "error") {
    status = "unhealthy";
  } else if (memoryCheck.percentage > 90) {
    status = "degraded";
  }

  const response: HealthCheckResponse & { error?: string } = {
    status,
    timestamp: new Date().toISOString(),
    uptime: Math.round(process.uptime()),
    version: process.env.npm_package_version || "1.0.0",
    environment: process.env.NODE_ENV || "development",
    checks: {
      database: databaseStatus,
      memory: memoryCheck,
    },
  };

  // Include error details if database failed
  if (dbError) {
    (response as HealthCheckResponse & { error: string }).error = dbError;
  }

  // Add response time header
  const responseTime = Date.now() - startTime;

  return NextResponse.json(response, {
    status: status === "unhealthy" ? 503 : 200,
    headers: {
      "X-Response-Time": `${responseTime}ms`,
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}
