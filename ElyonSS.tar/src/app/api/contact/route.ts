import { NextResponse } from "next/server";

interface ContactFormData {
  name: string;
  company: string;
  email: string;
  phone?: string;
  industry?: string;
  message: string;
  budget?: string;
  timeline?: string;
  honeypot?: string;
}

export async function POST(request: Request) {
  try {
    const body: ContactFormData = await request.json();

    // Honeypot check - if filled, it's likely a bot
    if (body.honeypot) {
      // Silently reject but return success to confuse bots
      console.log("Spam submission blocked via honeypot");
      return NextResponse.json(
        { success: true, message: "Thank you for your submission." },
        { status: 200 }
      );
    }

    // Validate required fields
    const errors: Record<string, string> = {};

    if (!body.name || !body.name.trim()) {
      errors.name = "Name is required";
    }

    if (!body.company || !body.company.trim()) {
      errors.company = "Company name is required";
    }

    if (!body.email || !body.email.trim()) {
      errors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
      errors.email = "Please enter a valid email address";
    }

    if (!body.message || !body.message.trim()) {
      errors.message = "Message is required";
    }

    if (Object.keys(errors).length > 0) {
      return NextResponse.json(
        { success: false, errors },
        { status: 400 }
      );
    }

    // Log the submission (in production, this would be saved to database or sent to email service)
    console.log("=== Contact Form Submission ===");
    console.log("Timestamp:", new Date().toISOString());
    console.log("Name:", body.name);
    console.log("Company:", body.company);
    console.log("Email:", body.email);
    console.log("Phone:", body.phone || "Not provided");
    console.log("Industry:", body.industry || "Not specified");
    console.log("Message:", body.message);
    console.log("Budget:", body.budget || "Not specified");
    console.log("Timeline:", body.timeline || "Not specified");
    console.log("===============================");

    // In production, you would:
    // 1. Save to database
    // 2. Send notification email to team
    // 3. Send confirmation email to user
    // 4. Integrate with CRM (HubSpot, Salesforce, etc.)

    return NextResponse.json(
      {
        success: true,
        message: "Thank you for your message. We'll get back to you within 24 hours.",
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Contact form error:", error);
    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while processing your request. Please try again.",
      },
      { status: 500 }
    );
  }
}
