import Link from "next/link";
import { Metadata } from "next";
import { ArrowRight, CheckCircle2, Zap, Target, TrendingUp } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCases, getIconComponent, useCaseDetails } from "@/lib/content/use-cases";

export const metadata: Metadata = {
  title: "Use Cases - Real-World Smart Solutions Applications | Elyon Smart Solutions",
  description:
    "Explore real-world applications of Elyon's smart solutions. See how organizations use our technology for agent management, operations dashboards, process automation, and more.",
  keywords: [
    "smart solutions use cases",
    "agent management systems",
    "operations dashboards",
    "process automation",
    "predictive maintenance",
    "energy monitoring",
    "access control",
    "IoT applications",
  ],
};

export default function UseCasesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-elyon-navy via-elyon-blue/90 to-elyon-navy py-20 lg:py-28 overflow-hidden">
          {/* Background decorations */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-elyon-orange/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-elyon-blue/30 rounded-full blur-3xl" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge variant="secondary" className="mb-4 bg-elyon-orange/20 text-elyon-orange border-elyon-orange/30">
                Use Cases
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                Use Cases{" "}
                <span className="bg-gradient-to-r from-elyon-orange to-amber-400 bg-clip-text text-transparent">
                  in Action
                </span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto leading-relaxed">
                Real-world applications of our smart solutions. Discover how organizations transform their operations 
                with practical implementations that deliver measurable results.
              </p>
            </div>
          </div>
        </section>

        {/* Use Cases Grid */}
        <section className="py-16 lg:py-24 bg-background">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {useCases.map((useCase) => {
                const IconComponent = getIconComponent(useCase.icon);
                const details = useCaseDetails[useCase.slug];
                
                return (
                  <Card
                    key={useCase.slug}
                    className="group relative overflow-hidden border-2 border-transparent hover:border-elyon-blue/30 transition-all duration-300 hover:shadow-xl hover:shadow-elyon-blue/5 flex flex-col"
                  >
                    <CardHeader className="pb-4">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-elyon-blue to-elyon-navy flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          {IconComponent && (
                            <IconComponent className="w-7 h-7 text-white" />
                          )}
                        </div>
                        <Badge variant="outline" className="text-xs border-elyon-orange/30 text-elyon-orange">
                          Use Case
                        </Badge>
                      </div>
                      <CardTitle className="text-xl font-bold text-elyon-navy group-hover:text-elyon-blue transition-colors">
                        {useCase.title}
                      </CardTitle>
                      <CardDescription className="text-muted-foreground leading-relaxed">
                        {useCase.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4 flex-1 flex flex-col">
                      {/* Trigger → Workflow → Outcome Summary */}
                      {details && (
                        <div className="space-y-3 flex-1">
                          <div className="flex items-start gap-2 p-3 bg-elyon-blue/5 rounded-lg">
                            <Target className="w-4 h-4 text-elyon-blue shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-semibold text-elyon-blue mb-1">Trigger</p>
                              <p className="text-sm text-muted-foreground line-clamp-2">{details.trigger}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-2 p-3 bg-elyon-orange/5 rounded-lg">
                            <Zap className="w-4 h-4 text-elyon-orange shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-semibold text-elyon-orange mb-1">Workflow</p>
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {details.workflowSteps.length}-step process from {details.workflowSteps[0]?.title} to {details.workflowSteps[details.workflowSteps.length - 1]?.title}
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-2 p-3 bg-elyon-green/5 rounded-lg">
                            <TrendingUp className="w-4 h-4 text-elyon-green shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-semibold text-elyon-green mb-1">Outcome</p>
                              <p className="text-sm text-muted-foreground line-clamp-2">{useCase.benefits[0]}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Key Metrics */}
                      {useCase.metrics && (
                        <div className="grid grid-cols-3 gap-2 py-4 border-t border-border">
                          {useCase.metrics.slice(0, 3).map((metric, index) => (
                            <div key={index} className="text-center">
                              <div className="text-lg font-bold text-elyon-blue">{metric.value}</div>
                              <div className="text-xs text-muted-foreground line-clamp-1">{metric.label}</div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Learn More Link */}
                      <Link
                        href={`/use-cases/${useCase.slug}`}
                        className="inline-flex items-center gap-2 text-elyon-blue font-medium hover:gap-3 transition-all group/link mt-auto"
                      >
                        View Details
                        <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                      </Link>
                    </CardContent>

                    {/* Decorative gradient */}
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-elyon-blue via-elyon-orange to-elyon-blue opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 lg:py-24 bg-secondary/50">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-elyon-navy mb-4">
                How Elyon Use Cases Work
              </h2>
              <p className="text-muted-foreground text-lg">
                Each use case represents a practical application of our smart solutions designed to solve specific operational challenges.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="text-center p-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-elyon-blue/10 flex items-center justify-center">
                  <Target className="w-8 h-8 text-elyon-blue" />
                </div>
                <h3 className="text-lg font-semibold text-elyon-navy mb-2">Identify the Trigger</h3>
                <p className="text-muted-foreground">
                  We start by understanding the specific operational challenge or opportunity that drives the need for smart solutions.
                </p>
              </div>
              <div className="text-center p-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-elyon-orange/10 flex items-center justify-center">
                  <Zap className="w-8 h-8 text-elyon-orange" />
                </div>
                <h3 className="text-lg font-semibold text-elyon-navy mb-2">Design the Workflow</h3>
                <p className="text-muted-foreground">
                  Our team designs a step-by-step implementation that integrates with your existing processes and systems.
                </p>
              </div>
              <div className="text-center p-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-elyon-green/10 flex items-center justify-center">
                  <TrendingUp className="w-8 h-8 text-elyon-green" />
                </div>
                <h3 className="text-lg font-semibold text-elyon-navy mb-2">Deliver Outcomes</h3>
                <p className="text-muted-foreground">
                  Measure and optimize results to ensure the solution delivers measurable business value and ROI.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-20 bg-gradient-to-r from-elyon-blue to-elyon-navy">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                See Your Use Case Here?
              </h2>
              <p className="text-white/80 text-lg mb-8">
                Schedule a consultation with our solutions experts to discuss how we can implement 
                similar solutions for your organization.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-elyon-orange hover:bg-elyon-orange/90 text-white"
                >
                  <Link href="/contact">
                    Book a Consultation
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  <Link href="/solutions">Explore Solutions</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
