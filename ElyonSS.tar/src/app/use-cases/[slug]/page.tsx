import Link from "next/link";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Target,
  Zap,
  TrendingUp,
  Clock,
  Database,
  FileOutput,
  Lightbulb,
  MessageSquare,
  Cog,
  Activity,
  BarChart3,
  Shield,
  Building2,
  Users,
  LayoutDashboard,
  Settings,
  Wrench,
  Gauge,
  Lock,
} from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { useCases, getUseCaseBySlug, getUseCaseDetails, getIconComponent } from "@/lib/content/use-cases";
import { getSolutionBySlug } from "@/lib/content/solutions";
import { getIndustryBySlug } from "@/lib/content/industries";
import { caseStudies } from "@/lib/content/case-studies";

// Icon mappings for solutions
const solutionIcons: Record<string, typeof Cog> = {
  Cog,
  Activity,
  BarChart3,
  Zap,
  Shield,
  Building2,
};

// Icon mappings for use cases
const useCaseIcons: Record<string, typeof Users> = {
  Users,
  LayoutDashboard,
  Settings,
  Wrench,
  Gauge,
  Lock,
};

// Industry icons
const industryIcons: Record<string, typeof Building2> = {
  Building: Building2,
  ShoppingBag: BarChart3,
  Package: Settings,
  Heart: Activity,
  Factory: Wrench,
  Hotel: Building2,
};

interface UseCasePageProps {
  params: Promise<{ slug: string }>;
}

// Generate static params for all use cases
export async function generateStaticParams() {
  return useCases.map((useCase) => ({
    slug: useCase.slug,
  }));
}

// Generate metadata for SEO
export async function generateMetadata({ params }: UseCasePageProps): Promise<Metadata> {
  const { slug } = await params;
  const useCase = getUseCaseBySlug(slug);

  if (!useCase) {
    return {
      title: "Use Case Not Found | Elyon Smart Solutions",
    };
  }

  return {
    title: `${useCase.title} - Use Case | Elyon Smart Solutions`,
    description: useCase.description,
    keywords: [
      useCase.title,
      ...useCase.features,
      "smart solutions",
      "operational efficiency",
      "Elyon",
    ],
  };
}

export default async function UseCaseDetailPage({ params }: UseCasePageProps) {
  const { slug } = await params;
  const useCase = getUseCaseBySlug(slug);

  if (!useCase) {
    notFound();
  }

  const details = getUseCaseDetails(slug);
  const UseCaseIcon = useCaseIcons[useCase.icon];

  // Get related solutions
  const relatedSolutions = useCase.relatedSolutions
    ?.map((solSlug) => getSolutionBySlug(solSlug))
    .filter(Boolean) || [];

  // Get related industries
  const relatedIndustries = details?.relatedIndustries
    ?.map((indSlug) => getIndustryBySlug(indSlug))
    .filter(Boolean) || [];

  // Get related case studies (based on industry matching)
  const relatedCaseStudies = caseStudies.filter((study) => {
    const studyIndustry = study.industry.toLowerCase();
    return details?.relatedIndustries?.some((indSlug) => {
      const industry = getIndustryBySlug(indSlug);
      return industry?.title.toLowerCase().includes(studyIndustry) || 
             studyIndustry.includes(industry?.title.toLowerCase() || "");
    });
  }).slice(0, 2);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-20">
        {/* Breadcrumb */}
        <section className="bg-secondary/30 py-4 border-b">
          <div className="container mx-auto px-4 lg:px-8">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink asChild>
                    <Link href="/">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbLink asChild>
                    <Link href="/use-cases">Use Cases</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>{useCase.title}</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-elyon-navy via-elyon-blue/90 to-elyon-navy py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-elyon-orange/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-elyon-blue/30 rounded-full blur-3xl" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl">
              <Badge variant="secondary" className="mb-4 bg-elyon-orange/20 text-elyon-orange border-elyon-orange/30">
                Use Case
              </Badge>
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-elyon-orange to-amber-500 flex items-center justify-center">
                  {UseCaseIcon && <UseCaseIcon className="w-8 h-8 text-white" />}
                </div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">
                  {useCase.title}
                </h1>
              </div>
              <p className="text-lg md:text-xl text-white/80 leading-relaxed mb-8 max-w-3xl">
                {details?.longDescription || useCase.description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-elyon-orange hover:bg-elyon-orange/90 text-white">
                  <Link href="/contact">
                    Get Started
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <Link href="/solutions">View Related Solutions</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Key Metrics Strip */}
        {useCase.metrics && (
          <section className="py-8 bg-elyon-navy border-y border-white/10">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {useCase.metrics.map((metric, index) => (
                  <div key={index} className="text-center">
                    <div className="text-2xl md:text-3xl font-bold text-elyon-orange">{metric.value}</div>
                    <div className="text-sm text-white/70">{metric.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Trigger Section */}
        {details?.trigger && (
          <section className="py-12 bg-background">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-4xl mx-auto">
                <Card className="border-2 border-elyon-blue/20 bg-gradient-to-r from-elyon-blue/5 to-transparent">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-elyon-blue/10 flex items-center justify-center shrink-0">
                        <Target className="w-6 h-6 text-elyon-blue" />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold text-elyon-navy mb-2">When to Use This Solution</h2>
                        <p className="text-muted-foreground leading-relaxed">{details.trigger}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>
        )}

        {/* Workflow Steps Section */}
        {details?.workflowSteps && (
          <section className="py-16 bg-secondary/30">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-3xl mx-auto text-center mb-12">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-elyon-blue" />
                  <h2 className="text-sm font-semibold text-elyon-blue uppercase tracking-wide">
                    Implementation
                  </h2>
                </div>
                <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                  Workflow Steps
                </h3>
                <p className="text-muted-foreground mt-2">
                  Step-by-step process to implement this use case
                </p>
              </div>

              {/* Steps with connectors */}
              <div className="max-w-5xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
                  {details.workflowSteps.map((step, index) => (
                    <div key={index} className="relative">
                      <Card className="h-full hover:shadow-lg transition-shadow">
                        <CardContent className="pt-6 text-center">
                          <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-gradient-to-br from-elyon-blue to-elyon-navy flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            {step.step}
                          </div>
                          <h4 className="font-semibold text-elyon-navy mb-2">{step.title}</h4>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                        </CardContent>
                      </Card>
                      {index < details.workflowSteps.length - 1 && (
                        <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-0.5 bg-elyon-blue/30" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Data Inputs & Outputs Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Database className="w-5 h-5 text-elyon-orange" />
                <h2 className="text-sm font-semibold text-elyon-orange uppercase tracking-wide">
                  Data Flow
                </h2>
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                Inputs & Outputs
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {/* Data Inputs Card */}
              <Card className="border-2 border-elyon-blue/20">
                <CardHeader>
                  <CardTitle className="text-elyon-navy flex items-center gap-2">
                    <Database className="w-5 h-5 text-elyon-blue" />
                    Data/Inputs Needed
                  </CardTitle>
                  <CardDescription>Information required to implement this use case</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {details?.dataInputs?.map((input, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-elyon-blue/10 flex items-center justify-center shrink-0 mt-0.5">
                          <ArrowRight className="w-3 h-3 text-elyon-blue" />
                        </div>
                        <span className="text-sm text-muted-foreground">{input}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Outputs Card */}
              <Card className="border-2 border-elyon-green/20">
                <CardHeader>
                  <CardTitle className="text-elyon-navy flex items-center gap-2">
                    <FileOutput className="w-5 h-5 text-elyon-green" />
                    Outputs Delivered
                  </CardTitle>
                  <CardDescription>Results and deliverables from this implementation</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {details?.outputs?.map((output, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-elyon-green shrink-0 mt-0.5" />
                        <span className="text-sm text-muted-foreground">{output}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Features & Benefits Section */}
        <section className="py-16 bg-secondary/30">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Lightbulb className="w-5 h-5 text-elyon-orange" />
                <h2 className="text-sm font-semibold text-elyon-orange uppercase tracking-wide">
                  Capabilities
                </h2>
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                Features & Benefits
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
              {/* Features Card */}
              <Card className="border-2 border-elyon-blue/20">
                <CardHeader>
                  <CardTitle className="text-elyon-navy flex items-center gap-2">
                    <Zap className="w-5 h-5 text-elyon-blue" />
                    Features
                  </CardTitle>
                  <CardDescription>Core capabilities included in this use case</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {useCase.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-elyon-blue shrink-0 mt-0.5" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Benefits Card */}
              <Card className="border-2 border-elyon-orange/20">
                <CardHeader>
                  <CardTitle className="text-elyon-navy flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-elyon-orange" />
                    Benefits
                  </CardTitle>
                  <CardDescription>Measurable outcomes you can expect</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {useCase.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-elyon-orange shrink-0 mt-0.5" />
                        <span className="text-sm text-muted-foreground">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Recommended Solutions Section */}
        {relatedSolutions.length > 0 && (
          <section className="py-16 bg-background">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-3xl mx-auto text-center mb-12">
                <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                  Recommended Solutions
                </h3>
                <p className="text-muted-foreground mt-2">
                  Elyon solutions that power this use case
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
                {relatedSolutions.map((solution) => {
                  if (!solution) return null;
                  const SolutionIcon = solutionIcons[solution.icon];
                  return (
                    <Link
                      key={solution.slug}
                      href={`/solutions/${solution.slug}`}
                      className="flex items-center gap-3 px-6 py-4 bg-white border border-border rounded-xl hover:border-elyon-blue/30 hover:shadow-lg transition-all group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-elyon-blue to-elyon-navy flex items-center justify-center group-hover:scale-110 transition-transform">
                        {SolutionIcon && <SolutionIcon className="w-5 h-5 text-white" />}
                      </div>
                      <span className="font-medium text-foreground group-hover:text-elyon-blue transition-colors">
                        {solution.title}
                      </span>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-elyon-blue transition-colors" />
                    </Link>
                  );
                })}
              </div>
            </div>
          </section>
        )}

        {/* Related Case Studies */}
        {relatedCaseStudies.length > 0 && (
          <section className="py-16 bg-secondary/30">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-3xl mx-auto text-center mb-12">
                <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                  Related Case Studies
                </h3>
                <p className="text-muted-foreground mt-2">
                  See how organizations have implemented similar solutions
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
                {relatedCaseStudies.map((study) => (
                  <Card key={study.slug} className="group hover:border-elyon-blue/30 transition-colors">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="border-elyon-blue/30 text-elyon-blue">
                          {study.industry}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{study.timeline}</span>
                      </div>
                      <CardTitle className="text-lg text-elyon-navy group-hover:text-elyon-blue transition-colors">
                        {study.client}
                      </CardTitle>
                      <CardDescription className="line-clamp-2">{study.challenge}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        {study.results.slice(0, 2).map((result, index) => (
                          <div key={index} className="text-center p-3 bg-secondary/50 rounded-lg">
                            <div className="text-2xl font-bold text-elyon-blue">{result.value}</div>
                            <div className="text-xs text-muted-foreground">{result.metric}</div>
                          </div>
                        ))}
                      </div>
                      <Link
                        href={`/case-studies/${study.slug}`}
                        className="inline-flex items-center gap-2 text-elyon-blue font-medium mt-4 hover:gap-3 transition-all"
                      >
                        Read Full Case Study
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Related Industries */}
        {relatedIndustries.length > 0 && (
          <section className="py-16 bg-background">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-3xl mx-auto text-center mb-12">
                <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                  Applicable Industries
                </h3>
                <p className="text-muted-foreground mt-2">
                  This use case delivers value across multiple industries
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
                {relatedIndustries.map((industry) => {
                  if (!industry) return null;
                  const IndustryIcon = industryIcons[industry.icon];
                  return (
                    <Link
                      key={industry.slug}
                      href={`/industries/${industry.slug}`}
                      className="flex items-center gap-3 px-6 py-4 bg-white border border-border rounded-xl hover:border-elyon-blue/30 hover:shadow-lg transition-all group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-elyon-blue/10 flex items-center justify-center group-hover:bg-elyon-blue/20 transition-colors">
                        {IndustryIcon && <IndustryIcon className="w-5 h-5 text-elyon-blue" />}
                      </div>
                      <span className="font-medium text-foreground group-hover:text-elyon-blue transition-colors">
                        {industry.title}
                      </span>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-elyon-blue transition-colors" />
                    </Link>
                  );
                })}
              </div>
            </div>
          </section>
        )}

        {/* FAQ Section */}
        {details?.faqs && details.faqs.length > 0 && (
          <section className="py-16 bg-secondary/30">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-3xl mx-auto">
                <div className="text-center mb-12">
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <MessageSquare className="w-5 h-5 text-elyon-blue" />
                    <h2 className="text-sm font-semibold text-elyon-blue uppercase tracking-wide">
                      FAQs
                    </h2>
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold text-elyon-navy">
                    Frequently Asked Questions
                  </h3>
                </div>

                <Accordion type="single" collapsible className="w-full">
                  {details.faqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="bg-white px-6 rounded-lg mb-2">
                      <AccordionTrigger className="text-left font-medium text-foreground hover:text-elyon-blue">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>
          </section>
        )}

        {/* CTA Section */}
        <section className="py-16 lg:py-20 bg-gradient-to-r from-elyon-blue to-elyon-navy">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Ready to Implement {useCase.title}?
              </h2>
              <p className="text-white/80 text-lg mb-8">
                Schedule a consultation with our solutions experts to discuss how {useCase.title.toLowerCase()} 
                can transform your operations.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-elyon-orange hover:bg-elyon-orange/90 text-white"
                >
                  <Link href="/contact">
                    Schedule Consultation
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  <Link href="/use-cases">Explore All Use Cases</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
