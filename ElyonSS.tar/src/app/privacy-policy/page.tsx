import { Metadata } from "next";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Shield,
  Database,
  Eye,
  Share2,
  Lock,
  Cookie,
  UserCheck,
  Mail,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Privacy Policy | Elyon Smart Solutions",
  description:
    "Learn how Elyon Smart Solutions collects, uses, and protects your personal information. Our privacy policy outlines our commitment to data security and your rights.",
  keywords: [
    "privacy policy",
    "data protection",
    "Elyon Smart Solutions",
    "information security",
    "GDPR compliance",
  ],
};

const sections = [
  {
    id: "information-we-collect",
    title: "Information We Collect",
    icon: Database,
    content: `We collect information you provide directly to us, such as when you fill out a contact form, subscribe to our newsletter, request a consultation, or communicate with us via email or other channels. This information may include your name, email address, phone number, company name, job title, and any other information you choose to provide.

We also collect information automatically when you visit our website, including your IP address, browser type, operating system, referring URLs, information about how you interact with our website, and other device and usage information. This data helps us understand how visitors use our site and improve user experience.

Additionally, we may receive information from third parties, such as business partners or publicly available sources, to enhance our services and better understand our market and customers.`,
  },
  {
    id: "how-we-use",
    title: "How We Use Your Information",
    icon: Eye,
    content: `We use the information we collect for various business purposes, including providing, maintaining, and improving our services. This encompasses responding to your inquiries, processing transactions, sending you technical notices and support messages, and communicating with you about products, services, and events.

We also use your information to monitor and analyze trends, usage, and activities in connection with our services. This helps us identify potential issues, improve our website and services, and develop new features and functionalities.

Furthermore, we use collected data to detect, investigate, and prevent fraudulent transactions, abuse, and other illegal activities. We may also use your information for other purposes with your consent or as otherwise permitted by applicable law.`,
  },
  {
    id: "information-sharing",
    title: "Information Sharing",
    icon: Share2,
    content: `We do not sell, rent, or trade your personal information to third parties. We may share your information only in limited circumstances, such as with service providers who perform services on our behalf, including website hosting, data analysis, payment processing, and customer service.

We may also share your information with business partners with whom we jointly offer products or services, or when we believe disclosure is necessary to comply with applicable law, regulation, legal process, or governmental request.

In the event of a merger, acquisition, or sale of assets, your information may be transferred as part of that transaction. We will notify you via email or prominent notice on our website of any change in ownership or use of your personal information.`,
  },
  {
    id: "data-security",
    title: "Data Security",
    icon: Lock,
    content: `We implement appropriate technical and organizational measures to protect the security of your personal information, including encryption of data in transit and at rest, access controls, and regular security assessments. However, please be aware that no method of transmission over the Internet or method of electronic storage is 100% secure.

We regularly review and update our security practices to address new threats and vulnerabilities. Our team is trained on data protection best practices, and we conduct periodic security audits to ensure compliance with our policies and procedures.

We maintain data retention policies that limit how long we keep your personal information, and we securely dispose of data that is no longer needed for the purposes for which it was collected or as required by law.`,
  },
  {
    id: "cookies",
    title: "Cookies and Tracking Technologies",
    icon: Cookie,
    content: `We use cookies and similar tracking technologies to collect and store information about your preferences and activity on our website. Cookies are small data files stored on your device that help us improve your experience and understand how you interact with our services.

We use both session cookies (which expire when you close your browser) and persistent cookies (which stay on your device until deleted). These cookies serve various purposes, including remembering your preferences, analyzing website traffic, and providing personalized content.

You can control cookies through your browser settings and other tools. However, disabling cookies may limit your ability to use certain features of our website. We also use third-party analytics tools, such as Google Analytics, to understand website usage patterns.`,
  },
  {
    id: "your-rights",
    title: "Your Rights",
    icon: UserCheck,
    content: `You have the right to access, correct, or delete your personal information. You may also have the right to object to or restrict the processing of your data, or to request the transfer of your data to another service provider, depending on your location and applicable laws.

To exercise any of these rights, please contact us at info@elyon.one. We will respond to your request within a reasonable timeframe and in accordance with applicable law. We may need to verify your identity before processing your request.

If you believe our processing of your personal information infringes upon your rights, you have the right to lodge a complaint with a supervisory authority in your jurisdiction. We encourage you to contact us first so we can address your concerns directly.`,
  },
  {
    id: "contact",
    title: "Contact Information",
    icon: Mail,
    content: `If you have any questions or concerns about this Privacy Policy or our data practices, please contact us using the information below:

Email: info@elyon.one
Address: 3rd Floor, Door No 1-60/8/A &B, KNR Square, Gachibowli, Kondapur, Hyderabad, Telangana - 500032

We are committed to addressing any questions or concerns you may have about our privacy practices. We will make reasonable efforts to respond to your inquiry within 30 days of receipt.`,
  },
];

export default function PrivacyPolicyPage() {
  const lastUpdated = "January 15, 2026";

  return (
    <>
      <Header />
      <main className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-white">
        {/* Hero Section */}
        <section className="relative pt-32 pb-16 lg:pt-40 lg:pb-20 overflow-hidden">
          {/* Background Decorations */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-elyon-blue/5 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-elyon-navy/5 rounded-full blur-3xl" />
          </div>

          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge
                variant="outline"
                className="mb-6 border-elyon-blue/30 text-elyon-blue"
              >
                <Shield className="w-3 h-3 mr-1" />
                Legal Document
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-elyon-navy mb-4">
                Privacy Policy
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                Last updated: {lastUpdated}
              </p>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                At Elyon Smart Solutions, we are committed to protecting your
                privacy and ensuring the security of your personal information.
                This policy outlines how we collect, use, and safeguard your
                data.
              </p>
            </div>
          </div>
        </section>

        {/* Table of Contents */}
        <section className="py-8 lg:py-12">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <Card className="border-slate-200 bg-white/80 backdrop-blur-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-elyon-navy">
                    Table of Contents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <nav className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {sections.map((section, index) => (
                      <a
                        key={section.id}
                        href={`#${section.id}`}
                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-100 transition-colors group"
                      >
                        <span className="flex items-center justify-center w-7 h-7 rounded-full bg-elyon-blue/10 text-elyon-blue text-sm font-medium group-hover:bg-elyon-blue group-hover:text-white transition-colors">
                          {index + 1}
                        </span>
                        <span className="text-sm font-medium text-slate-700 group-hover:text-elyon-blue transition-colors">
                          {section.title}
                        </span>
                      </a>
                    ))}
                  </nav>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Policy Sections */}
        <section className="py-8 lg:py-12 flex-1">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-4xl mx-auto space-y-8">
              {sections.map((section, index) => (
                <Card
                  key={section.id}
                  id={section.id}
                  className="border-slate-200 bg-white/80 backdrop-blur-sm scroll-mt-24"
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-elyon-blue to-elyon-navy text-white">
                        <section.icon className="w-6 h-6" />
                      </div>
                      <CardTitle className="text-xl text-elyon-navy">
                        {section.title}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-slate-600 leading-relaxed space-y-4">
                      {section.content.split("\n\n").map((paragraph, pIndex) => (
                        <p key={pIndex}>{paragraph}</p>
                      ))}
                    </div>
                  </CardContent>
                  {index < sections.length - 1 && (
                    <Separator className="mt-4" />
                  )}
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Additional Notice */}
        <section className="py-8 lg:py-12">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <Card className="border-elyon-blue/20 bg-elyon-blue/5">
                <CardContent className="p-6">
                  <p className="text-sm text-slate-600 leading-relaxed">
                    <strong className="text-elyon-navy">Changes to This Policy: </strong>
                    We may update this Privacy Policy from time to time. We will
                    notify you of any changes by posting the new Privacy Policy on
                    this page and updating the "Last updated" date at the top. We
                    encourage you to review this Privacy Policy periodically for
                    any changes. Your continued use of our services after the
                    posting of revised Privacy Policy means that you accept and
                    agree to the changes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
