import type { Config } from "tailwindcss";
import tailwindcssAnimate from "tailwindcss-animate";

const config: Config = {
    darkMode: "class",
    content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
        extend: {
                colors: {
                        background: 'hsl(var(--background))',
                        foreground: 'hsl(var(--foreground))',
                        card: {
                                DEFAULT: 'hsl(var(--card))',
                                foreground: 'hsl(var(--card-foreground))'
                        },
                        popover: {
                                DEFAULT: 'hsl(var(--popover))',
                                foreground: 'hsl(var(--popover-foreground))'
                        },
                        primary: {
                                DEFAULT: 'hsl(var(--primary))',
                                foreground: 'hsl(var(--primary-foreground))'
                        },
                        secondary: {
                                DEFAULT: 'hsl(var(--secondary))',
                                foreground: 'hsl(var(--secondary-foreground))'
                        },
                        muted: {
                                DEFAULT: 'hsl(var(--muted))',
                                foreground: 'hsl(var(--muted-foreground))'
                        },
                        accent: {
                                DEFAULT: 'hsl(var(--accent))',
                                foreground: 'hsl(var(--accent-foreground))'
                        },
                        destructive: {
                                DEFAULT: 'hsl(var(--destructive))',
                                foreground: 'hsl(var(--destructive-foreground))'
                        },
                        border: 'hsl(var(--border))',
                        input: 'hsl(var(--input))',
                        ring: 'hsl(var(--ring))',
                        chart: {
                                '1': 'hsl(var(--chart-1))',
                                '2': 'hsl(var(--chart-2))',
                                '3': 'hsl(var(--chart-3))',
                                '4': 'hsl(var(--chart-4))',
                                '5': 'hsl(var(--chart-5))'
                        },
                        // Elyon Brand Colors
                        elyon: {
                                blue: '#0066cc',
                                'blue-light': '#3d8bd4',
                                'blue-dark': '#0052a3',
                                navy: '#1a237e',
                                'navy-light': '#2a3a9e',
                                'navy-dark': '#0f1254',
                                orange: '#FF6A3A',
                                'orange-light': '#ff8a60',
                                'orange-dark': '#e55a2b',
                                green: '#34A853',
                                'green-light': '#4cba6e',
                                'green-dark': '#2b8a45',
                        }
                },
                borderRadius: {
                        lg: 'var(--radius)',
                        md: 'calc(var(--radius) - 2px)',
                        sm: 'calc(var(--radius) - 4px)'
                },
                animation: {
                        'float': 'float 6s ease-in-out infinite',
                        'float-slow': 'float 8s ease-in-out infinite',
                        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
                        'shimmer': 'shimmer 2s infinite',
                        'bounce-slow': 'bounce-slow 3s ease-in-out infinite',
                        'spin-slow': 'spin-slow 20s linear infinite',
                },
                keyframes: {
                        float: {
                                '0%, 100%': { transform: 'translateY(0px)' },
                                '50%': { transform: 'translateY(-20px)' },
                        },
                        'pulse-glow': {
                                '0%, 100%': { boxShadow: '0 0 20px rgba(0, 102, 204, 0.3)' },
                                '50%': { boxShadow: '0 0 40px rgba(0, 102, 204, 0.6)' },
                        },
                        shimmer: {
                                '0%': { backgroundPosition: '-200% 0' },
                                '100%': { backgroundPosition: '200% 0' },
                        },
                        'bounce-slow': {
                                '0%, 100%': { transform: 'translateY(0)' },
                                '50%': { transform: 'translateY(-10px)' },
                        },
                        'spin-slow': {
                                'from': { transform: 'rotate(0deg)' },
                                'to': { transform: 'rotate(360deg)' },
                        },
                },
                backgroundImage: {
                        'gradient-blue-orange': 'linear-gradient(107.76deg, #0066cc 13.31%, #FF6A3A 79.26%)',
                        'gradient-green-blue': 'linear-gradient(119.91deg, #34A853 6.39%, #0066cc 84.36%)',
                        'gradient-orange-yellow': 'linear-gradient(139deg, #FF6A3A 20%, #FBBC05 90%)',
                        'gradient-pink-blue': 'linear-gradient(93.99deg, #FE3360 0%, #6186EE 61%, #72ABFC 100%)',
                        'gradient-dark': 'linear-gradient(180deg, #0a0a0f 0%, #1a1a2e 50%, #16213e 100%)',
                },
        }
  },
  plugins: [tailwindcssAnimate],
};
export default config;
