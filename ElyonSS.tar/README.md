# Elyon Smart Solutions

Smart Automation, IoT, AI & Systems Integration - Modern enterprise website built with Next.js 16.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## 📁 Project Structure

```
├── src/
│   ├── app/                 # Next.js App Router pages
│   │   ├── api/            # API routes
│   │   ├── solutions/      # Solutions pages
│   │   ├── industries/     # Industries pages
│   │   ├── case-studies/   # Case studies pages
│   │   └── ...
│   ├── components/         # React components
│   │   ├── ui/            # shadcn/ui components
│   │   └── layout/        # Layout components
│   └── lib/               # Utilities and content
├── prisma/                 # Database schema
├── public/                 # Static assets
└── docker-compose.yml      # Docker configuration
```

## 🛠 Tech Stack

- **Framework**: Next.js 16 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **Database**: Prisma ORM (SQLite/PostgreSQL)
- **Animations**: Framer Motion
- **Icons**: Lucide React

## 🌐 Deployment

### Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

### Docker

```bash
# Build and run
docker-compose up -d
```

### PM2 (VPS)

```bash
# Start with PM2
pm2 start ecosystem.config.js --env production
```

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment guides.

## 📋 Environment Variables

Copy `.env.example` to `.env` and configure:

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | Database connection string |
| `NEXTAUTH_SECRET` | Authentication secret |
| `NEXT_PUBLIC_APP_URL` | Public URL of your app |

## 📄 License

MIT License - © 2024 Elyon Smart Solutions
