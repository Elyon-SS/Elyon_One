/**
 * PM2 Ecosystem Configuration
 * 
 * Usage:
 *   Development: pm2 start ecosystem.config.js
 *   Production:  pm2 start ecosystem.config.js --env production
 * 
 * Commands:
 *   pm2 start ecosystem.config.js    - Start the application
 *   pm2 stop all                     - Stop all processes
 *   pm2 restart all                  - Restart all processes
 *   pm2 logs                         - View logs
 *   pm2 monit                        - Monitor processes
 *   pm2 save                         - Save process list
 *   pm2 startup                      - Generate startup script
 */

module.exports = {
  apps: [
    {
      name: 'elyon-smart-solutions',
      script: 'node_modules/next/dist/bin/next',
      args: 'start',
      
      // Process Management
      instances: 'max',
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      
      // Environment Variables
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      
      // Logging
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      
      // Graceful Shutdown
      kill_timeout: 5000,
      wait_ready: true,
      listen_timeout: 10000,
      
      // Restart Policy
      exp_backoff_restart_delay: 100,
      max_restarts: 10,
      min_uptime: '10s',
      restart_delay: 1000,
    },
  ],
  
  // Deployment Configuration (for remote servers)
  deploy: {
    production: {
      user: 'deploy',
      host: ['your-server-ip'],
      ref: 'origin/main',
      repo: 'git@github.com:your-username/elyon-smart-solutions.git',
      path: '/var/www/elyon-smart-solutions',
      'pre-deploy-local': '',
      'post-deploy': 'npm ci && npm run build && pm2 reload ecosystem.config.js --env production',
      'pre-setup': 'apt-get install git -y',
      ssh_options: 'ForwardAgent=yes',
    },
    
    staging: {
      user: 'deploy',
      host: ['staging-server-ip'],
      ref: 'origin/develop',
      repo: 'git@github.com:your-username/elyon-smart-solutions.git',
      path: '/var/www/elyon-smart-solutions-staging',
      'post-deploy': 'npm ci && npm run build && pm2 reload ecosystem.config.js --env production',
    },
  },
};
