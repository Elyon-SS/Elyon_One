import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Enable React strict mode
  reactStrictMode: true,
  
  // Output standalone for Docker/self-hosted deployments
  output: "standalone",
  
  // Allowed dev origins for cross-origin requests
  allowedDevOrigins: ["localhost", "21.0.8.16", "*.preview.com"],
  
  // TypeScript configuration
  typescript: {
    ignoreBuildErrors: false,
  },
  
  // Image optimization configuration
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
    unoptimized: process.env.DISABLE_IMAGE_OPTIMIZATION === "true",
  },
  
  // Environment variables exposed to the browser
  env: {
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || "https://elyon.one",
  },
  
  // Security headers
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
  
  // URL redirects
  async redirects() {
    return [
      { source: "/home", destination: "/", permanent: true },
      { source: "/contact-us", destination: "/contact", permanent: true },
    ];
  },
  
  // Experimental features for Next.js 16
  experimental: {
    serverActions: {
      allowedOrigins: ["elyon.one", "*.elyon.one", "localhost:3000"],
    },
  },
  
  // Turbopack config for Next.js 16
  turbopack: {},
  
  // Security: hide Next.js version
  poweredByHeader: false,
  
  // Enable compression
  compress: true,
  
  // Generate ETags for caching
  generateEtags: true,
  
  // Consistent URL handling
  trailingSlash: false,
};

export default nextConfig;
